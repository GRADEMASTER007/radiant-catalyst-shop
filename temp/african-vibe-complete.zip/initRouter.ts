import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { createAdminUser, getAdminUserByUsername } from "./db";
import { TRPCError } from "@trpc/server";

export const initRouter = router({
  createAdminUser: publicProcedure
    .input(z.object({
      username: z.string(),
      password: z.string(),
      email: z.string().email(),
    }))
    .mutation(async ({ input }) => {
      try {
        // Check if user already exists
        const existing = await getAdminUserByUsername(input.username);
        if (existing) {
          throw new TRPCError({
            code: "CONFLICT",
            message: "Admin user already exists",
          });
        }

        // Create new admin user
        await createAdminUser(input.username, input.password, input.email);

        return {
          success: true,
          message: "Admin user created successfully",
        };
      } catch (error) {
        console.error("Error creating admin user:", error);
        throw error;
      }
    }),

  checkAdminExists: publicProcedure
    .query(async () => {
      try {
        const admin = await getAdminUserByUsername("admin");
        return {
          exists: !!admin,
          username: admin?.username || null,
          email: admin?.email || null,
        };
      } catch (error) {
        console.error("Error checking admin:", error);
        return {
          exists: false,
          username: null,
          email: null,
        };
      }
    }),
});
