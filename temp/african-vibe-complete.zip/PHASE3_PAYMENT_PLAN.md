# PHASE 3: PAYMENT GATEWAY INTEGRATION PLAN

## Executive Summary

This document provides a comprehensive implementation plan for integrating PayFast and Yoco payment gateways into the Dragon Fruit SA e-commerce platform. The integration will support both ZAR and USD currencies, with full checkout flow, order management, and admin dashboards.

**Estimated Duration:** 40-50 hours
**Complexity Level:** High
**Risk Level:** Medium (payment processing requires careful security implementation)

---

## 1. DATABASE SCHEMA UPDATES

### 1.1 New Tables

#### `orders` Table
```sql
CREATE TABLE orders (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  order_number VARCHAR(50) UNIQUE NOT NULL,
  status ENUM('pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded') DEFAULT 'pending',
  
  -- Pricing
  subtotal_zar DECIMAL(10, 2) NOT NULL,
  subtotal_usd DECIMAL(10, 2) NOT NULL,
  shipping_cost_zar DECIMAL(10, 2) NOT NULL,
  shipping_cost_usd DECIMAL(10, 2) NOT NULL,
  tax_zar DECIMAL(10, 2) DEFAULT 0,
  tax_usd DECIMAL(10, 2) DEFAULT 0,
  total_zar DECIMAL(10, 2) NOT NULL,
  total_usd DECIMAL(10, 2) NOT NULL,
  
  -- Currency
  currency ENUM('ZAR', 'USD') DEFAULT 'ZAR',
  exchange_rate DECIMAL(10, 4),
  
  -- Shipping
  shipping_method VARCHAR(50),
  shipping_address_id BIGINT,
  tracking_number VARCHAR(100),
  
  -- Payment
  payment_method ENUM('payfast', 'yoco') NOT NULL,
  payment_id VARCHAR(100),
  payment_status VARCHAR(50),
  
  -- Timestamps
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  paid_at TIMESTAMP,
  shipped_at TIMESTAMP,
  delivered_at TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (shipping_address_id) REFERENCES addresses(id),
  INDEX (order_number),
  INDEX (user_id),
  INDEX (status),
  INDEX (payment_method)
);
```

#### `order_items` Table
```sql
CREATE TABLE order_items (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  order_id BIGINT NOT NULL,
  product_id BIGINT NOT NULL,
  quantity INT NOT NULL,
  price_zar DECIMAL(10, 2) NOT NULL,
  price_usd DECIMAL(10, 2) NOT NULL,
  subtotal_zar DECIMAL(10, 2) NOT NULL,
  subtotal_usd DECIMAL(10, 2) NOT NULL,
  
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id),
  INDEX (order_id)
);
```

#### `payments` Table
```sql
CREATE TABLE payments (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  order_id BIGINT NOT NULL UNIQUE,
  payment_method ENUM('payfast', 'yoco') NOT NULL,
  payment_id VARCHAR(100) UNIQUE,
  
  -- PayFast specific
  payfast_merchant_id VARCHAR(50),
  payfast_transaction_id VARCHAR(100),
  payfast_signature VARCHAR(255),
  
  -- Yoco specific
  yoco_payment_intent_id VARCHAR(100),
  yoco_charge_id VARCHAR(100),
  
  amount_zar DECIMAL(10, 2),
  amount_usd DECIMAL(10, 2),
  currency ENUM('ZAR', 'USD'),
  
  status ENUM('pending', 'processing', 'completed', 'failed', 'cancelled', 'refunded') DEFAULT 'pending',
  error_message TEXT,
  
  -- Refund tracking
  refund_amount_zar DECIMAL(10, 2),
  refund_amount_usd DECIMAL(10, 2),
  refund_reason VARCHAR(255),
  refund_status ENUM('pending', 'completed', 'failed'),
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  completed_at TIMESTAMP,
  
  FOREIGN KEY (order_id) REFERENCES orders(id),
  INDEX (payment_method),
  INDEX (status),
  INDEX (payment_id)
);
```

#### `payment_webhooks` Table
```sql
CREATE TABLE payment_webhooks (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  payment_method ENUM('payfast', 'yoco') NOT NULL,
  webhook_id VARCHAR(100),
  event_type VARCHAR(100),
  payload JSON,
  processed BOOLEAN DEFAULT FALSE,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP,
  
  INDEX (webhook_id),
  INDEX (processed)
);
```

#### `shipping_addresses` Table
```sql
CREATE TABLE addresses (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  type ENUM('billing', 'shipping') DEFAULT 'shipping',
  
  full_name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  
  street_address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL,
  state_province VARCHAR(100),
  postal_code VARCHAR(20) NOT NULL,
  country VARCHAR(100) NOT NULL,
  
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX (user_id)
);
```

---

## 2. BACKEND SERVICES

### 2.1 File Structure

```
server/
├── services/
│   ├── payfast.ts          # PayFast payment service
│   ├── yoco.ts             # Yoco payment service
│   ├── payment-processor.ts # Unified payment processor
│   └── order-manager.ts    # Order management logic
├── routers/
│   ├── payment.router.ts   # Payment tRPC endpoints
│   ├── order.router.ts     # Order tRPC endpoints
│   └── checkout.router.ts  # Checkout flow endpoints
├── webhooks/
│   ├── payfast.webhook.ts  # PayFast ITN handler
│   └── yoco.webhook.ts     # Yoco webhook handler
└── email/
    ├── payment-confirmation.ts
    ├── order-confirmation.ts
    └── refund-notification.ts
```

### 2.2 PayFast Service (`server/services/payfast.ts`)

**Key Functions:**
- `generatePaymentForm()` - Create secure payment form
- `validateSignature()` - Verify MD5 signature
- `processITN()` - Handle Instant Transaction Notification
- `initiateRefund()` - Process refund request
- `getTransactionStatus()` - Query transaction status
- `reconcileTransactions()` - Daily reconciliation

**Security Measures:**
- MD5 signature validation on all requests
- Webhook signature verification
- PCI DSS compliance
- SSL/TLS encryption
- Secure credential storage

### 2.3 Yoco Service (`server/services/yoco.ts`)

**Key Functions:**
- `createPaymentIntent()` - Create payment intent
- `tokenizeCard()` - Secure card tokenization
- `processPayment()` - Process payment
- `handleWebhook()` - Process webhook events
- `initiateRefund()` - Process refund
- `getPaymentDetails()` - Retrieve payment info
- `setupRecurringPayment()` - Subscription support

**Security Measures:**
- Never store card details (tokenization only)
- 3D Secure support
- Fraud detection integration
- Webhook signature verification
- PCI DSS compliance

### 2.4 Payment Processor (`server/services/payment-processor.ts`)

**Unified Interface:**
```typescript
interface PaymentProcessor {
  processPayment(order: Order, paymentMethod: 'payfast' | 'yoco'): Promise<PaymentResult>;
  handleWebhook(method: string, payload: any): Promise<void>;
  processRefund(payment: Payment, reason: string): Promise<RefundResult>;
  getPaymentStatus(paymentId: string): Promise<PaymentStatus>;
}
```

---

## 3. tRPC ROUTERS & ENDPOINTS

### 3.1 Payment Router

```typescript
// Create payment intent
payment.createIntent({
  orderId: string;
  method: 'payfast' | 'yoco';
  currency: 'ZAR' | 'USD';
}) => PaymentIntent

// Process payment
payment.process({
  intentId: string;
  cardToken?: string; // For Yoco
}) => PaymentResult

// Get payment status
payment.getStatus(paymentId: string) => PaymentStatus

// Refund payment
payment.refund({
  paymentId: string;
  amount?: number;
  reason: string;
}) => RefundResult

// Get payment history
payment.getHistory({
  userId: string;
  limit?: number;
  offset?: number;
}) => Payment[]

// Admin: Get all payments
admin.payment.getAll({
  status?: string;
  method?: string;
  dateFrom?: Date;
  dateTo?: Date;
}) => Payment[]

// Admin: Process refund
admin.payment.processRefund({
  paymentId: string;
  amount: number;
  reason: string;
}) => RefundResult
```

### 3.2 Order Router

```typescript
// Create order
order.create({
  items: OrderItem[];
  shippingAddress: Address;
  shippingMethod: string;
  currency: 'ZAR' | 'USD';
}) => Order

// Get order
order.get(orderId: string) => Order

// Get user orders
order.getUserOrders({
  userId: string;
  status?: string;
}) => Order[]

// Update order status
admin.order.updateStatus({
  orderId: string;
  status: OrderStatus;
}) => Order

// Get order analytics
admin.order.getAnalytics({
  dateFrom: Date;
  dateTo: Date;
}) => OrderAnalytics
```

### 3.3 Checkout Router

```typescript
// Initialize checkout
checkout.initialize({
  items: CartItem[];
  currency: 'ZAR' | 'USD';
}) => CheckoutSession

// Get checkout data
checkout.getSession(sessionId: string) => CheckoutSession

// Update shipping method
checkout.updateShipping({
  sessionId: string;
  shippingMethod: string;
}) => CheckoutSession

// Get shipping options
checkout.getShippingOptions({
  postalCode: string;
  country: string;
}) => ShippingOption[]

// Get currency conversion
checkout.getExchangeRate() => ExchangeRate

// Finalize checkout
checkout.finalize({
  sessionId: string;
  shippingAddressId: string;
  paymentMethod: 'payfast' | 'yoco';
}) => Order
```

---

## 4. FRONTEND COMPONENTS

### 4.1 Checkout Flow Pages

**Cart Page** (`client/src/pages/Cart.tsx`)
- Display cart items with prices (ZAR/USD)
- Item quantity adjustment
- Remove items
- Apply coupon codes
- Proceed to checkout button
- Continue shopping link

**Shipping Information** (`client/src/pages/CheckoutShipping.tsx`)
- Address form (billing/shipping)
- Save address option
- Use previous address option
- Postal code lookup
- Country/state selector

**Shipping Method Selection** (`client/src/pages/CheckoutShipping.tsx`)
- Display available shipping methods
- Show shipping costs (ZAR/USD)
- Estimated delivery times
- PUDO locker options (Phase 2)
- Select shipping method

**Payment Method Selection** (`client/src/pages/CheckoutPayment.tsx`)
- PayFast option
- Yoco option
- Currency selector (ZAR/USD)
- Order summary
- Security badges

**PayFast Checkout** (`client/src/components/PayFastCheckout.tsx`)
- Redirect to PayFast hosted page
- Handle return URLs
- Display payment status

**Yoco Checkout** (`client/src/components/YocoCheckout.tsx`)
- Inline checkout form
- Card input fields
- 3D Secure handling
- Mobile wallet buttons
- Payment processing status

**Order Confirmation** (`client/src/pages/OrderConfirmation.tsx`)
- Order number
- Order summary
- Payment confirmation
- Shipping details
- Tracking information
- Download invoice

### 4.2 Admin Payment Dashboard

**Payment Dashboard** (`client/src/pages/admin/PaymentDashboard.tsx`)
- Revenue overview (ZAR/USD)
- Payment method breakdown
- Transaction status distribution
- Recent transactions table
- Refund requests
- Dispute management

**Transaction Details** (`client/src/pages/admin/TransactionDetails.tsx`)
- Full transaction information
- Payment method details
- Customer information
- Order items
- Refund history
- Communication log

---

## 5. SECURITY IMPLEMENTATION

### 5.1 PCI DSS Compliance

- **No card storage** - Use tokenization only
- **SSL/TLS** - All payment pages HTTPS
- **Secure transmission** - Encrypted payment data
- **Access control** - Role-based payment access
- **Audit logging** - All payment operations logged
- **Regular testing** - Security vulnerability scans

### 5.2 Webhook Security

**PayFast ITN Verification:**
```typescript
function verifyPayFastSignature(data: any, signature: string): boolean {
  const fields = [
    'amount', 'item_name', 'item_description', 'custom_int1', 
    'custom_int2', 'custom_int3', 'custom_int4', 'custom_int5',
    'custom_str1', 'custom_str2', 'custom_str3', 'custom_str4',
    'custom_str5', 'name_first', 'name_last', 'email_address',
    'merchant_id'
  ];
  
  let stringToSign = '';
  fields.forEach(field => {
    if (data[field]) stringToSign += data[field];
  });
  
  const passphrase = process.env.PAYFAST_PASSPHRASE;
  stringToSign += passphrase;
  
  const md5Signature = crypto.createHash('md5').update(stringToSign).digest('hex');
  return md5Signature === signature;
}
```

**Yoco Webhook Verification:**
```typescript
function verifyYocoSignature(payload: string, signature: string): boolean {
  const hmac = crypto
    .createHmac('sha256', process.env.YOCO_WEBHOOK_SECRET)
    .update(payload)
    .digest('hex');
  return hmac === signature;
}
```

### 5.3 Error Handling

- **Sensitive data masking** - Never log card details
- **Generic error messages** - Don't expose system details
- **Retry logic** - Automatic retry for transient failures
- **Dead letter queue** - Failed webhooks stored for manual review
- **Monitoring alerts** - Alert on payment failures

---

## 6. TESTING STRATEGY

### 6.1 Unit Tests

**PayFast Service Tests:**
- Signature generation and validation
- Payment form creation
- ITN processing
- Refund initiation

**Yoco Service Tests:**
- Payment intent creation
- Card tokenization
- Webhook handling
- Refund processing

### 6.2 Integration Tests

- End-to-end checkout flow
- Payment processing with both gateways
- Webhook handling
- Order creation and status updates
- Email notifications
- Currency conversion

### 6.3 Manual Testing

**Test Credentials:**
- PayFast test mode
- Yoco test API keys
- Test card numbers (4242 4242 4242 4242)

**Test Scenarios:**
- Successful payment
- Failed payment
- Cancelled payment
- Refund request
- Webhook retry
- Currency conversion

---

## 7. IMPLEMENTATION TIMELINE

### Week 1: Backend Setup (15 hours)
- Database schema creation and migration
- PayFast service implementation
- Yoco service implementation
- Payment processor service
- tRPC routers

### Week 2: Frontend & Integration (15 hours)
- Checkout flow pages
- Payment components
- Admin dashboard
- Email templates
- Webhook handlers

### Week 3: Testing & Deployment (10 hours)
- Unit tests
- Integration tests
- Manual testing
- Security audit
- Deployment preparation

### Week 4: Production Launch (10 hours)
- Production deployment
- Monitoring setup
- Support documentation
- Team training
- Post-launch monitoring

---

## 8. DEPLOYMENT CHECKLIST

- [ ] Database migrations applied
- [ ] Environment variables configured
- [ ] SSL/TLS certificates installed
- [ ] Webhook URLs configured in payment gateways
- [ ] Email templates tested
- [ ] Admin dashboard tested
- [ ] Payment flow tested end-to-end
- [ ] Security audit completed
- [ ] Monitoring and alerts configured
- [ ] Documentation updated
- [ ] Team trained
- [ ] Backup and recovery tested
- [ ] Rollback plan documented

---

## 9. ESTIMATED COSTS

**PayFast:**
- Transaction fee: 2.2% + R0.50 per transaction
- Monthly fee: R0 (free)

**Yoco:**
- Card transactions: 1.5% + R0.50
- Mobile wallet: 1.5% + R0.50
- Monthly fee: R0 (free)

**Estimated Monthly Volume:**
- 100 transactions = ~R2,000 - R3,000 in fees

---

## 10. RISK MITIGATION

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|-----------|
| Payment gateway downtime | Low | High | Implement fallback gateway, queue failed payments |
| Webhook delivery failure | Medium | Medium | Implement retry logic, dead letter queue |
| Card fraud | Low | High | Implement 3D Secure, fraud detection |
| PCI DSS non-compliance | Low | Critical | Regular audits, tokenization only |
| Currency conversion errors | Low | Medium | Use reliable exchange rate API, audit logs |

---

## 11. SUCCESS METRICS

- Payment success rate: >98%
- Webhook delivery success: >99%
- Average payment processing time: <5 seconds
- Customer satisfaction: >4.5/5
- Zero PCI DSS violations
- Zero fraudulent transactions

---

## CONCLUSION

This Phase 3 implementation provides a robust, secure, and scalable payment gateway integration for the Dragon Fruit SA e-commerce platform. The dual-gateway approach ensures high availability and customer choice, while comprehensive security measures protect both the business and customers.

**Next Steps:**
1. Review and approve this plan
2. Begin database schema implementation
3. Start backend service development
4. Parallel frontend development
5. Comprehensive testing
6. Production deployment

---

**Document Version:** 1.0
**Last Updated:** January 20, 2026
**Status:** Ready for Implementation
