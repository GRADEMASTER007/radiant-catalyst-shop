# Yoco tRPC Endpoints - Detailed Specification

## Overview

This document provides detailed specifications for all Yoco-related tRPC endpoints that will be implemented in Phase 3. These endpoints handle payment processing, webhook handling, refunds, and payment management through the Yoco payment gateway.

**Yoco Credentials:**
- API Key: `yoco_live_1be907c4ffe80376_3f05d1d6503c605b73555b677b80697f`
- Public Key: `pk_live_b21ac3bd1WM6WRY3f9f4`
- Secret Key: `sk_live_87380fcbgEgAEJa48704613a39ec`

---

## 1. PAYMENT CREATION & PROCESSING

### 1.1 `payment.createYocoIntent`

**Purpose:** Create a Yoco payment intent for checkout

**Input:**
```typescript
{
  orderId: string;           // Order ID from database
  amount: number;            // Amount in cents (e.g., 10000 = R100.00)
  currency: 'ZAR' | 'USD';   // Currency code
  description: string;       // Payment description
  metadata?: {
    userId: string;
    orderNumber: string;
    items: string;           // JSON stringified items
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  paymentIntentId: string;   // Yoco payment intent ID
  clientSecret: string;      // Client secret for frontend
  amount: number;
  currency: string;
  status: 'pending' | 'processing';
  createdAt: Date;
  expiresAt: Date;
  error?: string;
}
```

**Implementation Notes:**
- Store `paymentIntentId` and `clientSecret` in database
- Set expiration to 30 minutes
- Include order metadata for reconciliation
- Handle currency conversion if needed

---

### 1.2 `payment.processYocoPayment`

**Purpose:** Process a Yoco payment with card token

**Input:**
```typescript
{
  paymentIntentId: string;   // From createYocoIntent
  cardToken: string;         // Tokenized card from Yoco.js
  threeDSecure?: {
    enabled: boolean;
    returnUrl: string;
  };
  metadata?: {
    ipAddress: string;
    userAgent: string;
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  chargeId: string;          // Yoco charge ID
  status: 'succeeded' | 'processing' | 'failed';
  amount: number;
  currency: string;
  receiptUrl?: string;
  error?: string;
  errorCode?: string;
  errorMessage?: string;
}
```

**Implementation Notes:**
- Validate card token before processing
- Implement 3D Secure if required
- Log all payment attempts
- Update order status based on result
- Send confirmation email on success

---

### 1.3 `payment.getYocoPaymentStatus`

**Purpose:** Get current status of a Yoco payment

**Input:**
```typescript
{
  chargeId: string;          // Yoco charge ID
  paymentIntentId?: string;  // Alternative lookup
}
```

**Output:**
```typescript
{
  chargeId: string;
  status: 'succeeded' | 'processing' | 'failed' | 'pending';
  amount: number;
  currency: string;
  cardBrand: string;         // 'visa', 'mastercard', etc.
  cardLast4: string;         // Last 4 digits
  createdAt: Date;
  updatedAt: Date;
  receiptUrl?: string;
  metadata?: any;
}
```

**Implementation Notes:**
- Cache results for 5 minutes
- Handle rate limiting (100 requests/minute)
- Return detailed status for admin dashboard

---

## 2. PAYMENT CONFIRMATION & WEBHOOKS

### 2.1 `payment.confirmYocoPayment`

**Purpose:** Confirm a Yoco payment after webhook verification

**Input:**
```typescript
{
  chargeId: string;
  webhookSignature: string;  // From Yoco webhook
  webhookPayload: any;       // Full webhook payload
}
```

**Output:**
```typescript
{
  success: boolean;
  orderId: string;
  orderStatus: 'paid' | 'processing';
  confirmationNumber: string;
  receiptUrl: string;
  error?: string;
}
```

**Implementation Notes:**
- Verify webhook signature using HMAC-SHA256
- Idempotent operation (safe to call multiple times)
- Update order status to 'paid'
- Send order confirmation email
- Trigger fulfillment workflow

---

### 2.2 `payment.handleYocoWebhook`

**Purpose:** Handle incoming Yoco webhook events

**Input:**
```typescript
{
  eventType: string;         // 'charge.succeeded', 'charge.failed', etc.
  chargeId: string;
  status: string;
  amount: number;
  currency: string;
  metadata: any;
  timestamp: number;
  signature: string;         // Webhook signature
}
```

**Output:**
```typescript
{
  success: boolean;
  processed: boolean;
  eventId: string;
  error?: string;
}
```

**Supported Events:**
- `charge.succeeded` - Payment successful
- `charge.failed` - Payment failed
- `charge.pending` - Payment pending (3D Secure)
- `charge.expired` - Payment intent expired
- `charge.refunded` - Refund processed
- `charge.dispute_created` - Dispute filed

**Implementation Notes:**
- Verify signature on all webhooks
- Store webhook payload in database
- Implement retry logic for failed processing
- Log all webhook events
- Alert admin on disputes

---

## 3. REFUNDS & REVERSALS

### 3.1 `payment.initiateYocoRefund`

**Purpose:** Initiate a refund for a Yoco payment

**Input:**
```typescript
{
  chargeId: string;
  amount?: number;           // Partial refund in cents (omit for full)
  reason: 'customer_request' | 'duplicate' | 'fraudulent' | 'other';
  description?: string;      // Refund reason details
  metadata?: {
    orderId: string;
    refundInitiatedBy: string;
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  refundId: string;
  chargeId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'succeeded' | 'failed';
  createdAt: Date;
  error?: string;
}
```

**Implementation Notes:**
- Validate refund amount doesn't exceed original charge
- Check refund eligibility (within 90 days)
- Create refund record in database
- Send refund notification to customer
- Update order status to 'refunded'

---

### 3.2 `payment.getYocoRefundStatus`

**Purpose:** Get status of a Yoco refund

**Input:**
```typescript
{
  refundId: string;
  chargeId?: string;
}
```

**Output:**
```typescript
{
  refundId: string;
  chargeId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'succeeded' | 'failed';
  reason: string;
  createdAt: Date;
  completedAt?: Date;
  error?: string;
}
```

**Implementation Notes:**
- Poll Yoco API for latest status
- Cache results for 10 minutes
- Handle refund failures gracefully

---

## 4. PAYMENT HISTORY & ANALYTICS

### 4.1 `payment.getYocoPaymentHistory`

**Purpose:** Get user's Yoco payment history

**Input:**
```typescript
{
  userId: string;
  limit?: number;            // Default: 20, Max: 100
  offset?: number;           // Default: 0
  status?: 'succeeded' | 'failed' | 'pending';
  dateFrom?: Date;
  dateTo?: Date;
}
```

**Output:**
```typescript
{
  payments: Array<{
    chargeId: string;
    orderId: string;
    amount: number;
    currency: string;
    status: string;
    cardBrand: string;
    cardLast4: string;
    createdAt: Date;
    receiptUrl?: string;
  }>;
  total: number;
  limit: number;
  offset: number;
}
```

**Implementation Notes:**
- Paginate results for performance
- Never return full card numbers
- Include receipt URLs for customer
- Filter by date range for analytics

---

### 4.2 `admin.payment.getYocoAnalytics`

**Purpose:** Get Yoco payment analytics for admin dashboard

**Input:**
```typescript
{
  dateFrom: Date;
  dateTo: Date;
  groupBy?: 'day' | 'week' | 'month';
  currency?: 'ZAR' | 'USD' | 'all';
}
```

**Output:**
```typescript
{
  totalTransactions: number;
  totalAmount: {
    zar: number;
    usd: number;
  };
  successRate: number;        // Percentage
  averageTransactionValue: number;
  transactionsByStatus: {
    succeeded: number;
    failed: number;
    pending: number;
  };
  transactionsByCardBrand: {
    visa: number;
    mastercard: number;
    amex: number;
    other: number;
  };
  dailyBreakdown?: Array<{
    date: Date;
    transactions: number;
    amount: number;
    successRate: number;
  }>;
  topCountries?: Array<{
    country: string;
    transactions: number;
    amount: number;
  }>;
}
```

**Implementation Notes:**
- Cache results for 1 hour
- Generate daily reports
- Export to CSV functionality
- Alert on anomalies

---

## 5. CARD TOKENIZATION

### 5.1 `payment.createYocoCardToken`

**Purpose:** Create a reusable card token for future payments

**Input:**
```typescript
{
  cardNumber: string;
  expiryMonth: number;       // 1-12
  expiryYear: number;        // 4-digit year
  cvv: string;
  cardholderName: string;
  saveForFuture?: boolean;   // Save as default payment method
}
```

**Output:**
```typescript
{
  success: boolean;
  tokenId: string;           // Reusable token
  cardBrand: string;
  cardLast4: string;
  expiryMonth: number;
  expiryYear: number;
  error?: string;
}
```

**Implementation Notes:**
- Never store raw card data
- Use Yoco.js for tokenization on frontend
- Store token securely in database
- Encrypt token in transit

---

### 5.2 `payment.listYocoCardTokens`

**Purpose:** Get user's saved payment methods

**Input:**
```typescript
{
  userId: string;
}
```

**Output:**
```typescript
{
  cards: Array<{
    tokenId: string;
    cardBrand: string;
    cardLast4: string;
    expiryMonth: number;
    expiryYear: number;
    isDefault: boolean;
    createdAt: Date;
  }>;
}
```

**Implementation Notes:**
- Return masked card data only
- Show default card first
- Allow deletion of saved cards

---

## 6. SUBSCRIPTION & RECURRING PAYMENTS

### 6.1 `payment.createYocoSubscription`

**Purpose:** Set up recurring Yoco payments

**Input:**
```typescript
{
  userId: string;
  cardTokenId: string;       // From createYocoCardToken
  amount: number;            // In cents
  currency: 'ZAR' | 'USD';
  frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
  startDate: Date;
  endDate?: Date;
  description: string;
  metadata?: any;
}
```

**Output:**
```typescript
{
  success: boolean;
  subscriptionId: string;
  status: 'active' | 'paused' | 'cancelled';
  nextBillingDate: Date;
  error?: string;
}
```

**Implementation Notes:**
- Store subscription details in database
- Schedule recurring charges
- Handle failed payments with retry
- Send billing notifications

---

### 6.2 `payment.updateYocoSubscription`

**Purpose:** Update subscription details

**Input:**
```typescript
{
  subscriptionId: string;
  amount?: number;
  frequency?: string;
  endDate?: Date;
  status?: 'active' | 'paused' | 'cancelled';
}
```

**Output:**
```typescript
{
  success: boolean;
  subscriptionId: string;
  updatedFields: string[];
  error?: string;
}
```

---

## 7. MOBILE WALLET INTEGRATION

### 7.1 `payment.createYocoMobileWalletPayment`

**Purpose:** Process Apple Pay / Google Pay payments

**Input:**
```typescript
{
  paymentIntentId: string;
  walletType: 'apple_pay' | 'google_pay';
  paymentToken: string;      // From wallet provider
  metadata?: any;
}
```

**Output:**
```typescript
{
  success: boolean;
  chargeId: string;
  status: 'succeeded' | 'processing' | 'failed';
  walletType: string;
  error?: string;
}
```

**Implementation Notes:**
- Validate wallet tokens
- Handle wallet-specific errors
- Log wallet transactions separately
- Support for both iOS and Android

---

## 8. DISPUTE & CHARGEBACK HANDLING

### 8.1 `admin.payment.getYocoDisputes`

**Purpose:** Get list of payment disputes

**Input:**
```typescript
{
  status?: 'open' | 'won' | 'lost' | 'resolved';
  dateFrom?: Date;
  dateTo?: Date;
  limit?: number;
  offset?: number;
}
```

**Output:**
```typescript
{
  disputes: Array<{
    disputeId: string;
    chargeId: string;
    orderId: string;
    amount: number;
    currency: string;
    status: string;
    reason: string;
    createdAt: Date;
    dueDate: Date;
    evidence?: string;
  }>;
  total: number;
}
```

---

### 8.2 `admin.payment.submitYocoDisputeEvidence`

**Purpose:** Submit evidence for a dispute

**Input:**
```typescript
{
  disputeId: string;
  evidence: {
    description: string;
    documents: string[];     // File URLs
    invoiceUrl?: string;
    shippingProof?: string;
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  disputeId: string;
  status: 'evidence_submitted';
  error?: string;
}
```

---

## 9. ERROR HANDLING

### Common Yoco Error Codes

| Code | Meaning | Action |
|------|---------|--------|
| `card_declined` | Card was declined | Retry with different card |
| `expired_card` | Card has expired | Update card details |
| `incorrect_cvc` | CVC is incorrect | Retry with correct CVC |
| `processing_error` | Yoco processing error | Retry after 5 seconds |
| `rate_limit` | Too many requests | Implement exponential backoff |
| `authentication_error` | Invalid credentials | Check API keys |
| `invalid_request_error` | Invalid parameters | Validate input data |

---

## 10. SECURITY CONSIDERATIONS

### 10.1 Webhook Signature Verification

```typescript
function verifyYocoSignature(payload: string, signature: string): boolean {
  const hmac = crypto
    .createHmac('sha256', process.env.YOCO_WEBHOOK_SECRET)
    .update(payload)
    .digest('hex');
  return hmac === signature;
}
```

### 10.2 PCI DSS Compliance

- ✅ Never store raw card data
- ✅ Use tokenization for all cards
- ✅ Encrypt data in transit (TLS 1.2+)
- ✅ Implement access controls
- ✅ Regular security audits
- ✅ Log all payment operations

### 10.3 Rate Limiting

- Implement rate limiting: 100 requests/minute per user
- Exponential backoff for retries
- Queue failed requests for retry

---

## 11. IMPLEMENTATION CHECKLIST

- [ ] Database schema created
- [ ] Yoco service implemented
- [ ] All tRPC endpoints created
- [ ] Webhook handler implemented
- [ ] Error handling tested
- [ ] Security audit completed
- [ ] Rate limiting implemented
- [ ] Logging configured
- [ ] Email templates created
- [ ] Admin dashboard built
- [ ] Customer notifications sent
- [ ] Documentation updated
- [ ] Team trained
- [ ] Production deployment tested

---

## 12. TESTING CHECKLIST

### Unit Tests
- [ ] Payment intent creation
- [ ] Card tokenization
- [ ] Refund processing
- [ ] Webhook verification
- [ ] Error handling

### Integration Tests
- [ ] End-to-end payment flow
- [ ] Webhook delivery
- [ ] Refund workflow
- [ ] Subscription management
- [ ] Mobile wallet payments

### Manual Tests
- [ ] Test card: 4111 1111 1111 1111
- [ ] 3D Secure flow
- [ ] Refund processing
- [ ] Dispute handling
- [ ] Mobile wallet (if available)

---

## 13. DEPLOYMENT CHECKLIST

- [ ] Yoco API keys configured
- [ ] Webhook URLs registered
- [ ] SSL/TLS certificates installed
- [ ] Database migrations applied
- [ ] Email service configured
- [ ] Monitoring alerts set up
- [ ] Backup procedures tested
- [ ] Rollback plan documented
- [ ] Team trained
- [ ] Support documentation ready
- [ ] Go-live approval obtained

---

## SUMMARY

This specification covers 13 major tRPC endpoints for Yoco integration, organized into 8 functional areas:

1. **Payment Creation** (3 endpoints)
2. **Webhooks** (2 endpoints)
3. **Refunds** (2 endpoints)
4. **History & Analytics** (2 endpoints)
5. **Tokenization** (2 endpoints)
6. **Subscriptions** (2 endpoints)
7. **Mobile Wallets** (1 endpoint)
8. **Disputes** (2 endpoints)

**Total: 16 tRPC endpoints**

All endpoints include comprehensive error handling, security measures, and logging for production-ready implementation.

---

**Document Version:** 1.0
**Last Updated:** January 20, 2026
**Status:** Ready for Implementation
**Yoco API Version:** v1
