/**
 * Shipping tRPC Router
 * Exposes Courier Guy and PUDO shipping services
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { courierGuyService } from "./services/courier-guy";
import { pudoService } from "./services/pudo";

export const shippingRouter = router({
  /**
   * Get Courier Guy quotes
   */
  getCourierGuyQuotes: publicProcedure
    .input(
      z.object({
        fromAddress: z.string(),
        fromCity: z.string(),
        fromProvince: z.string(),
        fromPostalCode: z.string(),
        toAddress: z.string(),
        toCity: z.string(),
        toProvince: z.string(),
        toPostalCode: z.string(),
        weight: z.number().positive(),
        length: z.number().optional(),
        width: z.number().optional(),
        height: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      try {
        const quotes = await courierGuyService.getQuotes({
          from: {
            address: input.fromAddress,
            city: input.fromCity,
            province: input.fromProvince,
            postalCode: input.fromPostalCode,
          },
          to: {
            address: input.toAddress,
            city: input.toCity,
            province: input.toProvince,
            postalCode: input.toPostalCode,
          },
          weight: input.weight,
          dimensions:
            input.length && input.width && input.height
              ? {
                  length: input.length,
                  width: input.width,
                  height: input.height,
                }
              : undefined,
        });

        return { success: true, quotes };
      } catch (error) {
        console.error("Courier Guy quotes error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Quote retrieval failed",
        };
      }
    }),

  /**
   * Create Courier Guy shipment
   */
  createCourierGuyShipment: publicProcedure
    .input(
      z.object({
        fromAddress: z.string(),
        fromCity: z.string(),
        fromProvince: z.string(),
        fromPostalCode: z.string(),
        toAddress: z.string(),
        toCity: z.string(),
        toProvince: z.string(),
        toPostalCode: z.string(),
        weight: z.number().positive(),
        serviceType: z.string(),
        reference: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const shipment = await courierGuyService.createShipment(
          {
            address: input.fromAddress,
            city: input.fromCity,
            province: input.fromProvince,
            postalCode: input.fromPostalCode,
          },
          {
            address: input.toAddress,
            city: input.toCity,
            province: input.toProvince,
            postalCode: input.toPostalCode,
          },
          input.weight,
          input.serviceType,
          input.reference
        );

        return { success: true, shipment };
      } catch (error) {
        console.error("Courier Guy shipment error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Shipment creation failed",
        };
      }
    }),

  /**
   * Track Courier Guy shipment
   */
  trackCourierGuyShipment: publicProcedure
    .input(z.object({ trackingNumber: z.string() }))
    .query(async ({ input }) => {
      try {
        const tracking = await courierGuyService.trackShipment(
          input.trackingNumber
        );
        return { success: true, tracking };
      } catch (error) {
        console.error("Courier Guy tracking error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Tracking failed",
        };
      }
    }),

  /**
   * Find PUDO locations nearby
   */
  findPUDOLocations: publicProcedure
    .input(
      z.object({
        latitude: z.number(),
        longitude: z.number(),
        radiusKm: z.number().optional(),
      })
    )
    .query(async ({ input }) => {
      try {
        const locations = await pudoService.findNearbyLocations(
          input.latitude,
          input.longitude,
          input.radiusKm
        );
        return { success: true, locations };
      } catch (error) {
        console.error("PUDO location search error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Location search failed",
        };
      }
    }),

  /**
   * Find PUDO locations by postal code
   */
  findPUDOByPostalCode: publicProcedure
    .input(z.object({ postalCode: z.string() }))
    .query(async ({ input }) => {
      try {
        const locations = await pudoService.findLocationsByPostalCode(
          input.postalCode
        );
        return { success: true, locations };
      } catch (error) {
        console.error("PUDO postal code search error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Location search failed",
        };
      }
    }),

  /**
   * Create PUDO shipment
   */
  createPUDOShipment: publicProcedure
    .input(
      z.object({
        locationId: z.string(),
        weight: z.number().positive(),
        reference: z.string(),
        recipientName: z.string(),
        recipientEmail: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const shipment = await pudoService.createShipment(
          input.locationId,
          input.weight,
          input.reference,
          input.recipientName,
          input.recipientEmail
        );
        return { success: true, shipment };
      } catch (error) {
        console.error("PUDO shipment error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Shipment creation failed",
        };
      }
    }),

  /**
   * Track PUDO shipment
   */
  trackPUDOShipment: publicProcedure
    .input(z.object({ trackingNumber: z.string() }))
    .query(async ({ input }) => {
      try {
        const tracking = await pudoService.trackShipment(input.trackingNumber);
        return { success: true, tracking };
      } catch (error) {
        console.error("PUDO tracking error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Tracking failed",
        };
      }
    }),

  /**
   * Get PUDO shipping cost
   */
  getPUDOShippingCost: publicProcedure
    .input(
      z.object({
        fromPostalCode: z.string(),
        toPostalCode: z.string(),
        weight: z.number().positive(),
      })
    )
    .query(async ({ input }) => {
      try {
        const cost = await pudoService.getShippingCost(
          input.fromPostalCode,
          input.toPostalCode,
          input.weight
        );
        return { success: true, cost };
      } catch (error) {
        console.error("PUDO cost calculation error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Cost calculation failed",
        };
      }
    }),

  /**
   * Cancel shipment
   */
  cancelShipment: publicProcedure
    .input(
      z.object({
        trackingNumber: z.string(),
        provider: z.enum(["courier_guy", "pudo"]),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (input.provider === "courier_guy") {
          return await courierGuyService.cancelShipment(input.trackingNumber);
        } else {
          return await pudoService.cancelShipment(input.trackingNumber);
        }
      } catch (error) {
        console.error("Shipment cancellation error:", error);
        return {
          success: false,
          message: error instanceof Error ? error.message : "Cancellation failed",
        };
      }
    }),
});
