/**
 * AI Configuration File
 * Defines all AI services, models, and routing logic
 * Supports: Ollama Cloud, Ollama Local, OpenRouter, Kilo Code
 */

export const AI_CONFIG = {
  // Ollama Cloud (Primary - Best Quality)
  ollama_cloud: {
    baseURL: "https://ollama.com/api",
    apiKey: "cebbc97e307d4e4d9b8a28d8e7b4d32d.SHRF1ZEiQEeRGK6vU4rLMvC4",
    models: {
      customer_support: "llama3.2:70b",
      content_generation: "mistral:latest",
      code_generation: "codellama:70b",
      image_analysis: "llama3.2-vision:latest",
      seo_optimization: "mixtral:latest",
    },
    timeout: 30000,
    maxRetries: 3,
  },

  // Ollama Local (Fallback - Fast & Free)
  ollama_local: {
    baseURL: "http://localhost:11434/api",
    apiKey: null, // No auth for localhost
    models: {
      quick_queries: "llama3.2:3b",
      faq_responses: "phi3:mini",
      data_processing: "gemma2:2b",
      testing: "llama3.2:1b",
    },
    timeout: 10000,
    maxRetries: 2,
  },

  // OpenRouter (Backup - Complex Tasks)
  openrouter: {
    baseURL: "https://openrouter.ai/api/v1",
    apiKey: "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",
    models: {
      complex_reasoning: "anthropic/claude-3.5-sonnet",
      backup_general: "meta-llama/llama-3.1-70b-instruct",
      code_generation: "deepseek/deepseek-coder-33b-instruct",
      creative_writing: "openai/gpt-4-turbo",
    },
    timeout: 45000,
    maxRetries: 3,
  },

  // Kilo Code MCP (Advanced Development)
  kilocode: {
    baseURL: "https://api.kilocode.com",
    apiKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbnYiOiJwcm9kdWN0aW9uIiwia2lsb1VzZXJJZCI6ImQwM2ZkODQxLTc5YzItNDJhMi1hNWViLWQwNjY1M2EwYmUzNCIsImFwaVRva2VuUGVwcGVyIjpudWxsLCJ2ZXJzaW9uIjozLCJpYXQiOjE3NjgzMTU3NzksImV4cCI6MTkyNjEwMzc3OX0.TTXbtmyaY-M8mc8P8YmENWz_9mTjflyVDgNwKa1yJ8s",
    timeout: 30000,
    maxRetries: 2,
  },

  // Intelligent Routing Logic
  routing: {
    strategy: "cost_optimized", // or "quality_first" or "speed_first"
    dailyBudget: 50, // USD
    costPerCloudQuery: 0.002, // Approximate
    costPerLocalQuery: 0, // Free
    priorityOrder: ["ollama_cloud", "ollama_local", "openrouter"],
    fallbackChain: true,
  },
};

export type AIService = keyof typeof AI_CONFIG;
export type AIConfig = typeof AI_CONFIG;
