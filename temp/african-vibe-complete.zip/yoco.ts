/**
 * Yoco Payment Service
 * Real integration with Yoco payment gateway
 * NO MOCKS - PRODUCTION READY
 */

import { CREDENTIALS } from "../config/credentials";

interface YocoCheckoutData {
  orderId: string;
  amount: number;
  description: string;
  customerName: string;
  customerEmail: string;
  returnUrl: string;
  metadata?: Record<string, any>;
}

interface YocoPaymentIntent {
  id: string;
  amount: number;
  currency: string;
  status: string;
  created: number;
  metadata: Record<string, any>;
}

class YocoService {
  private apiKey: string;
  private publicKey: string;
  private secretKey: string;
  private baseURL: string;

  constructor() {
    this.apiKey = CREDENTIALS.yoco.apiKey;
    this.publicKey = CREDENTIALS.yoco.publicKey;
    this.secretKey = CREDENTIALS.yoco.secretKey;
    this.baseURL = CREDENTIALS.yoco.baseURL;
  }

  /**
   * Create payment intent
   */
  async createPaymentIntent(
    data: YocoCheckoutData
  ): Promise<{ intentId: string; clientSecret: string; amount: number }> {
    try {
      const response = await fetch(`${this.baseURL}/v1/payment_intents`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.secretKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount: data.amount,
          currency: "ZAR",
          description: data.description,
          metadata: {
            orderId: data.orderId,
            customerName: data.customerName,
            customerEmail: data.customerEmail,
            ...data.metadata,
          },
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Yoco API error: ${error.message}`);
      }

      const intent: YocoPaymentIntent = await response.json();

      return {
        intentId: intent.id,
        clientSecret: intent.id, // Yoco uses ID as secret
        amount: intent.amount,
      };
    } catch (error) {
      console.error("Yoco payment intent error:", error);
      throw error;
    }
  }

  /**
   * Confirm payment
   */
  async confirmPayment(
    intentId: string,
    paymentMethodId: string
  ): Promise<{ success: boolean; status: string; transactionId?: string }> {
    try {
      const response = await fetch(
        `${this.baseURL}/v1/payment_intents/${intentId}/confirm`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${this.secretKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            payment_method: paymentMethodId,
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Yoco confirmation error: ${error.message}`);
      }

      const result: YocoPaymentIntent = await response.json();

      return {
        success: result.status === "succeeded",
        status: result.status,
        transactionId: result.id,
      };
    } catch (error) {
      console.error("Yoco payment confirmation error:", error);
      return {
        success: false,
        status: "failed",
      };
    }
  }

  /**
   * Get payment status
   */
  async getPaymentStatus(
    intentId: string
  ): Promise<{ status: string; amount: number; currency: string }> {
    try {
      const response = await fetch(`${this.baseURL}/v1/payment_intents/${intentId}`, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${this.secretKey}`,
        },
      });

      if (!response.ok) {
        throw new Error("Failed to get payment status");
      }

      const intent: YocoPaymentIntent = await response.json();

      return {
        status: intent.status,
        amount: intent.amount,
        currency: intent.currency,
      };
    } catch (error) {
      console.error("Error getting payment status:", error);
      throw error;
    }
  }

  /**
   * Refund payment
   */
  async refundPayment(
    transactionId: string,
    amount: number,
    reason: string
  ): Promise<{ success: boolean; message: string; refundId?: string }> {
    try {
      const response = await fetch(`${this.baseURL}/v1/refunds`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.secretKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          payment_intent_id: transactionId,
          amount: amount,
          reason: reason,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Yoco refund error: ${error.message}`);
      }

      const refund = await response.json();

      return {
        success: true,
        message: "Refund processed successfully",
        refundId: refund.id,
      };
    } catch (error) {
      console.error("Refund error:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Refund failed",
      };
    }
  }

  /**
   * Verify webhook signature
   */
  verifyWebhookSignature(
    payload: string,
    signature: string
  ): boolean {
    try {
      const crypto = require("crypto");
      const expectedSignature = crypto
        .createHmac("sha256", this.secretKey)
        .update(payload)
        .digest("hex");

      return signature === expectedSignature;
    } catch (error) {
      console.error("Webhook verification error:", error);
      return false;
    }
  }

  /**
   * Get public key for frontend
   */
  getPublicKey(): string {
    return this.publicKey;
  }
}

export const yocoService = new YocoService();
