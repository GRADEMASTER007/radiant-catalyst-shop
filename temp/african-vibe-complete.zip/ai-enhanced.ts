/**
 * Enhanced AI Service Router
 * Intelligent routing between Ollama Cloud, Ollama Local, OpenRouter, Kilo Code, and SerpAPI
 * Supports cost tracking, budget alerts, and automatic fallback chains
 */

import axios from "axios";

export interface AIServiceConfig {
  ollama_cloud_url: string;
  ollama_cloud_key: string;
  ollama_local_url: string;
  openrouter_url: string;
  openrouter_key: string;
  kilo_code_jwt: string;
  serpapi_key: string;
}

export interface AIQuery {
  prompt: string;
  taskType:
    | "content"
    | "code"
    | "design"
    | "analytics"
    | "search"
    | "image_analysis";
  complexity: "simple" | "medium" | "complex";
  model?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface AIResponse {
  success: boolean;
  content: string;
  model: string;
  service: "ollama_cloud" | "ollama_local" | "openrouter" | "kilo_code";
  cost: number;
  tokensUsed: number;
  executionTime: number;
  error?: string;
}

export interface ServiceHealth {
  service: string;
  status: "healthy" | "degraded" | "down";
  lastCheck: Date;
  responseTime: number;
}

export class EnhancedAIRouter {
  private config: AIServiceConfig;
  private costTracking: Map<string, number> = new Map();
  private serviceHealth: Map<string, ServiceHealth> = new Map();
  private budgetLimit: number = 100; // USD
  private monthlySpent: number = 0;

  constructor(config: AIServiceConfig) {
    this.config = config;
    this.initializeServiceHealth();
  }

  private initializeServiceHealth() {
    const services = [
      "ollama_cloud",
      "ollama_local",
      "openrouter",
      "kilo_code",
      "serpapi",
    ];
    services.forEach((service) => {
      this.serviceHealth.set(service, {
        service,
        status: "healthy",
        lastCheck: new Date(),
        responseTime: 0,
      });
    });
  }

  /**
   * Intelligent routing based on task type and complexity
   */
  async route(query: AIQuery): Promise<AIResponse> {
    const startTime = Date.now();

    try {
      // Check budget
      if (this.monthlySpent >= this.budgetLimit) {
        return await this.useLocalModel(query);
      }

      // Route based on task type and complexity
      let response: AIResponse | null = null;

      switch (query.taskType) {
        case "content":
          response = await this.routeContentGeneration(query);
          break;
        case "code":
          response = await this.routeCodeGeneration(query);
          break;
        case "design":
          response = await this.routeDesignAssistance(query);
          break;
        case "analytics":
          response = await this.routeAnalytics(query);
          break;
        case "search":
          response = await this.routeSearch(query);
          break;
        case "image_analysis":
          response = await this.routeImageAnalysis(query);
          break;
        default:
          response = await this.useOpenRouter(query);
      }

      if (response) {
        response.executionTime = Date.now() - startTime;
        this.trackCost(response);
        return response;
      }

      throw new Error("All AI services failed");
    } catch (error) {
      return {
        success: false,
        content: "",
        model: "error",
        service: "openrouter",
        cost: 0,
        tokensUsed: 0,
        executionTime: Date.now() - startTime,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }

  /**
   * Route content generation (product descriptions, blog posts, SEO)
   */
  private async routeContentGeneration(query: AIQuery): Promise<AIResponse> {
    // For simple content, use local model (fast and free)
    if (query.complexity === "simple") {
      return await this.useLocalModel(query);
    }

    // For medium/complex content, try cloud models
    if (query.complexity === "medium") {
      return (
        (await this.useOllamaCloud(query)) ||
        (await this.useOpenRouter(query)) ||
        (await this.useLocalModel(query))
      );
    }

    // For complex content, use OpenRouter's best models
    return (
      (await this.useOpenRouter(query)) ||
      (await this.useOllamaCloud(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Route code generation and debugging
   */
  private async routeCodeGeneration(query: AIQuery): Promise<AIResponse> {
    // Try Kilo Code first (specialized for code)
    const kiloResponse = await this.useKiloCode(query);
    if (kiloResponse) return kiloResponse;

    // Fall back to OpenRouter
    return (
      (await this.useOpenRouter(query)) ||
      (await this.useOllamaCloud(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Route design and UI assistance
   */
  private async routeDesignAssistance(query: AIQuery): Promise<AIResponse> {
    // Use OpenRouter for design (has vision models)
    return (
      (await this.useOpenRouter(query)) ||
      (await this.useOllamaCloud(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Route analytics and reporting
   */
  private async routeAnalytics(query: AIQuery): Promise<AIResponse> {
    // Use OpenRouter for analytics (complex reasoning)
    return (
      (await this.useOpenRouter(query)) ||
      (await this.useOllamaCloud(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Route search and research tasks
   */
  private async routeSearch(query: AIQuery): Promise<AIResponse> {
    // Use SerpAPI for search
    return (
      (await this.useSerpAPI(query)) ||
      (await this.useOpenRouter(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Route image analysis
   */
  private async routeImageAnalysis(query: AIQuery): Promise<AIResponse> {
    // Use OpenRouter for image analysis
    return (
      (await this.useOpenRouter(query)) ||
      (await this.useOllamaCloud(query)) ||
      (await this.useLocalModel(query))
    );
  }

  /**
   * Use Ollama Cloud (production quality, costs money)
   */
  private async useOllamaCloud(query: AIQuery): Promise<AIResponse | null> {
    try {
      const startTime = Date.now();
      const response = await axios.post(
        `${this.config.ollama_cloud_url}/chat/completions`,
        {
          model: query.model || "mistral",
          messages: [{ role: "user", content: query.prompt }],
          temperature: query.temperature || 0.7,
          max_tokens: query.maxTokens || 2000,
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.ollama_cloud_key}`,
            "Content-Type": "application/json",
          },
          timeout: 30000,
        }
      );

      const responseTime = Date.now() - startTime;
      this.updateServiceHealth("ollama_cloud", "healthy", responseTime);

      return {
        success: true,
        content: response.data.choices[0].message.content,
        model: response.data.model,
        service: "ollama_cloud",
        cost: this.calculateOllamaCost(response.data.usage),
        tokensUsed: response.data.usage.total_tokens,
        executionTime: responseTime,
      };
    } catch (error) {
      console.error("Ollama Cloud error:", error);
      this.updateServiceHealth("ollama_cloud", "degraded", 0);
      return null;
    }
  }

  /**
   * Use Ollama Local (free and fast)
   */
  private async useLocalModel(query: AIQuery): Promise<AIResponse> {
    try {
      const startTime = Date.now();
      const response = await axios.post(
        `${this.config.ollama_local_url}/chat/completions`,
        {
          model: query.model || "mistral",
          messages: [{ role: "user", content: query.prompt }],
          temperature: query.temperature || 0.7,
          stream: false,
        },
        {
          timeout: 60000,
        }
      );

      const responseTime = Date.now() - startTime;
      this.updateServiceHealth("ollama_local", "healthy", responseTime);

      return {
        success: true,
        content: response.data.message.content,
        model: response.data.model,
        service: "ollama_local",
        cost: 0, // Local model is free
        tokensUsed: 0,
        executionTime: responseTime,
      };
    } catch (error) {
      console.error("Ollama Local error:", error);
      this.updateServiceHealth("ollama_local", "degraded", 0);
      throw error;
    }
  }

  /**
   * Use OpenRouter (backup, various models)
   */
  private async useOpenRouter(query: AIQuery): Promise<AIResponse | null> {
    try {
      const startTime = Date.now();

      const modelMap: Record<string, string> = {
        nemotron: "nvidia/nemotron-3-nano-30b-a3b:free",
        mistral: "mistralai/devstral-2512:free",
        qwen: "qwen/qwen3-next-80b-a3b-instruct:free",
        deepseek: "deepseek/deepseek-r1-0528:free",
        llama: "meta-llama/llama-3.2-3b-instruct:free",
      };

      const model = query.model
        ? modelMap[query.model] || query.model
        : "mistralai/devstral-2512:free";

      const response = await axios.post(
        `${this.config.openrouter_url}/chat/completions`,
        {
          model,
          messages: [{ role: "user", content: query.prompt }],
          temperature: query.temperature || 0.7,
          max_tokens: query.maxTokens || 2000,
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.openrouter_key}`,
            "HTTP-Referer": "https://dragonfruitsa.com",
            "X-Title": "Dragon Fruit SA",
          },
          timeout: 30000,
        }
      );

      const responseTime = Date.now() - startTime;
      this.updateServiceHealth("openrouter", "healthy", responseTime);

      return {
        success: true,
        content: response.data.choices[0].message.content,
        model: response.data.model,
        service: "openrouter",
        cost: this.calculateOpenRouterCost(response.data),
        tokensUsed: response.data.usage.total_tokens,
        executionTime: responseTime,
      };
    } catch (error) {
      console.error("OpenRouter error:", error);
      this.updateServiceHealth("openrouter", "degraded", 0);
      return null;
    }
  }

  /**
   * Use Kilo Code (specialized for code)
   */
  private async useKiloCode(query: AIQuery): Promise<AIResponse | null> {
    try {
      const startTime = Date.now();
      const response = await axios.post(
        "https://api.kilo.dev/v1/chat/completions",
        {
          messages: [{ role: "user", content: query.prompt }],
          temperature: query.temperature || 0.7,
          max_tokens: query.maxTokens || 2000,
        },
        {
          headers: {
            Authorization: `Bearer ${this.config.kilo_code_jwt}`,
            "Content-Type": "application/json",
          },
          timeout: 30000,
        }
      );

      const responseTime = Date.now() - startTime;
      this.updateServiceHealth("kilo_code", "healthy", responseTime);

      return {
        success: true,
        content: response.data.choices[0].message.content,
        model: "kilo-code",
        service: "kilo_code",
        cost: 0, // Kilo Code is included
        tokensUsed: response.data.usage.total_tokens,
        executionTime: responseTime,
      };
    } catch (error) {
      console.error("Kilo Code error:", error);
      this.updateServiceHealth("kilo_code", "degraded", 0);
      return null;
    }
  }

  /**
   * Use SerpAPI for search
   */
  private async useSerpAPI(query: AIQuery): Promise<AIResponse | null> {
    try {
      const startTime = Date.now();
      const response = await axios.get("https://serpapi.com/search", {
        params: {
          q: query.prompt,
          api_key: this.config.serpapi_key,
          engine: "google",
          num: 10,
        },
        timeout: 10000,
      });

      const responseTime = Date.now() - startTime;
      this.updateServiceHealth("serpapi", "healthy", responseTime);

      const results = response.data.organic_results
        ?.slice(0, 5)
        .map(
          (r: any) =>
            `${r.title}\n${r.snippet}\nURL: ${r.link}`
        )
        .join("\n\n");

      return {
        success: true,
        content: results || "No results found",
        model: "serpapi",
        service: "openrouter", // Report as openrouter for compatibility
        cost: 0.005, // SerpAPI costs
        tokensUsed: 0,
        executionTime: responseTime,
      };
    } catch (error) {
      console.error("SerpAPI error:", error);
      this.updateServiceHealth("serpapi", "degraded", 0);
      return null;
    }
  }

  /**
   * Calculate Ollama Cloud cost
   */
  private calculateOllamaCost(usage: any): number {
    // Ollama Cloud pricing (example)
    const inputCost = (usage.prompt_tokens / 1000000) * 0.15;
    const outputCost = (usage.completion_tokens / 1000000) * 0.6;
    return inputCost + outputCost;
  }

  /**
   * Calculate OpenRouter cost
   */
  private calculateOpenRouterCost(response: any): number {
    // OpenRouter pricing varies by model
    // Free models cost 0
    if (response.model.includes(":free")) {
      return 0;
    }
    // Paid models (example pricing)
    const inputCost = (response.usage.prompt_tokens / 1000000) * 0.5;
    const outputCost = (response.usage.completion_tokens / 1000000) * 1.5;
    return inputCost + outputCost;
  }

  /**
   * Track costs
   */
  private trackCost(response: AIResponse) {
    const key = `${response.service}_${new Date().toISOString().split("T")[0]}`;
    const current = this.costTracking.get(key) || 0;
    this.costTracking.set(key, current + response.cost);
    this.monthlySpent += response.cost;

    if (this.monthlySpent > this.budgetLimit * 0.8) {
      console.warn(
        `⚠️ Budget alert: ${(this.monthlySpent / this.budgetLimit * 100).toFixed(1)}% of monthly budget used`
      );
    }
  }

  /**
   * Update service health
   */
  private updateServiceHealth(
    service: string,
    status: "healthy" | "degraded" | "down",
    responseTime: number
  ) {
    this.serviceHealth.set(service, {
      service,
      status,
      lastCheck: new Date(),
      responseTime,
    });
  }

  /**
   * Get service health
   */
  getServiceHealth(): ServiceHealth[] {
    return Array.from(this.serviceHealth.values());
  }

  /**
   * Get cost tracking
   */
  getCostTracking() {
    return {
      monthlySpent: this.monthlySpent,
      budgetLimit: this.budgetLimit,
      percentUsed: (this.monthlySpent / this.budgetLimit) * 100,
      dailyCosts: Object.fromEntries(this.costTracking),
    };
  }

  /**
   * Set budget limit
   */
  setBudgetLimit(limit: number) {
    this.budgetLimit = limit;
  }

  /**
   * Reset monthly spending
   */
  resetMonthlySpending() {
    this.monthlySpent = 0;
    this.costTracking.clear();
  }
}

export const createAIRouter = (config: AIServiceConfig) => {
  return new EnhancedAIRouter(config);
};
