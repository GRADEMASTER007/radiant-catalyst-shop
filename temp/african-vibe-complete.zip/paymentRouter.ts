/**
 * Payment tRPC Router
 * Exposes PayFast and Yoco payment services
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { payfastService } from "./services/payfast";
import { yocoService } from "./services/yoco";

export const paymentRouter = router({
  /**
   * Get PayFast checkout URL
   */
  getPayFastCheckout: publicProcedure
    .input(
      z.object({
        orderId: z.string(),
        amount: z.number().positive(),
        description: z.string(),
        customerName: z.string(),
        customerEmail: z.string().email(),
        returnUrl: z.string().url(),
        cancelUrl: z.string().url(),
        notifyUrl: z.string().url(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const checkoutUrl = payfastService.generateCheckoutUrl({
          orderId: input.orderId,
          amount: input.amount,
          description: input.description,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          returnUrl: input.returnUrl,
          cancelUrl: input.cancelUrl,
          notifyUrl: input.notifyUrl,
          itemName: "Order",
          itemDescription: input.description,
        });

        return {
          success: true,
          checkoutUrl,
          provider: "payfast",
        };
      } catch (error) {
        console.error("PayFast checkout error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Checkout failed",
        };
      }
    }),

  /**
   * Verify PayFast payment
   */
  verifyPayFastPayment: publicProcedure
    .input(
      z.object({
        paymentId: z.string(),
        amount: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await payfastService.verifyPayment(
          input.paymentId,
          input.amount
        );
        return result;
      } catch (error) {
        console.error("PayFast verification error:", error);
        return {
          verified: false,
          status: "error",
          message: error instanceof Error ? error.message : "Verification failed",
        };
      }
    }),

  /**
   * Create Yoco payment intent
   */
  createYocoIntent: publicProcedure
    .input(
      z.object({
        orderId: z.string(),
        amount: z.number().positive(),
        description: z.string(),
        customerName: z.string(),
        customerEmail: z.string().email(),
        returnUrl: z.string().url(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const intent = await yocoService.createPaymentIntent({
          orderId: input.orderId,
          amount: input.amount,
          description: input.description,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          returnUrl: input.returnUrl,
        });

        return {
          success: true,
          intentId: intent.intentId,
          clientSecret: intent.clientSecret,
          amount: intent.amount,
          provider: "yoco",
          publicKey: yocoService.getPublicKey(),
        };
      } catch (error) {
        console.error("Yoco intent creation error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Intent creation failed",
        };
      }
    }),

  /**
   * Confirm Yoco payment
   */
  confirmYocoPayment: publicProcedure
    .input(
      z.object({
        intentId: z.string(),
        paymentMethodId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await yocoService.confirmPayment(
          input.intentId,
          input.paymentMethodId
        );
        return result;
      } catch (error) {
        console.error("Yoco confirmation error:", error);
        return {
          success: false,
          status: "failed",
          error: error instanceof Error ? error.message : "Confirmation failed",
        };
      }
    }),

  /**
   * Get payment status
   */
  getPaymentStatus: publicProcedure
    .input(
      z.object({
        paymentId: z.string(),
        provider: z.enum(["payfast", "yoco"]),
      })
    )
    .query(async ({ input }) => {
      try {
        if (input.provider === "payfast") {
          return await payfastService.getPaymentStatus(input.paymentId);
        } else {
          return await yocoService.getPaymentStatus(input.paymentId);
        }
      } catch (error) {
        console.error("Payment status error:", error);
        return {
          status: "error",
          amount: 0,
          currency: "ZAR",
          error: error instanceof Error ? error.message : "Status check failed",
        };
      }
    }),

  /**
   * Refund payment
   */
  refundPayment: publicProcedure
    .input(
      z.object({
        transactionId: z.string(),
        amount: z.number().positive(),
        reason: z.string(),
        provider: z.enum(["payfast", "yoco"]),
      })
    )
    .mutation(async ({ input }) => {
      try {
        if (input.provider === "payfast") {
          return await payfastService.refundPayment(
            input.transactionId,
            input.amount,
            input.reason
          );
        } else {
          return await yocoService.refundPayment(
            input.transactionId,
            input.amount,
            input.reason
          );
        }
      } catch (error) {
        console.error("Refund error:", error);
        return {
          success: false,
          message: error instanceof Error ? error.message : "Refund failed",
        };
      }
    }),
});
