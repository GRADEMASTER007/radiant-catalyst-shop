# PayFast tRPC Endpoints - Detailed Specification

## Overview

This document provides detailed specifications for all PayFast-related tRPC endpoints that will be implemented in Phase 3. These endpoints handle payment form generation, ITN (Instant Transaction Notification) webhook processing, refunds, and payment management through the PayFast payment gateway.

**PayFast Credentials:**
- Merchant ID: `11071120`
- API Key: `p6fi9ewdjk1js`
- Passphrase: `abCd15ab92g12`
- Debug Email: `waterkefirsa@gmail.com`
- Test Mode: Available for development

---

## 1. PAYMENT FORM GENERATION

### 1.1 `payment.generatePayFastForm`

**Purpose:** Generate a secure PayFast payment form for checkout

**Input:**
```typescript
{
  orderId: string;           // Order ID from database
  amount: number;            // Amount in ZAR (e.g., 100.00)
  itemName: string;          // Product/order name
  itemDescription?: string;  // Order description
  customInt1?: number;       // Custom field 1 (e.g., user ID)
  customInt2?: number;       // Custom field 2
  customInt3?: number;       // Custom field 3
  customInt4?: number;       // Custom field 4
  customInt5?: number;       // Custom field 5
  customStr1?: string;       // Custom field 1 (string)
  customStr2?: string;       // Custom field 2 (string)
  customStr3?: string;       // Custom field 3 (string)
  customStr4?: string;       // Custom field 4 (string)
  customStr5?: string;       // Custom field 5 (string)
  nameFirst: string;         // Customer first name
  nameLast: string;          // Customer last name
  emailAddress: string;      // Customer email
  cellNumber?: string;       // Customer phone
  returnUrl: string;         // Success return URL
  cancelUrl: string;         // Cancellation URL
  notifyUrl: string;         // ITN webhook URL
  testMode?: boolean;        // Test mode toggle
}
```

**Output:**
```typescript
{
  success: boolean;
  formHtml: string;          // HTML form to render
  formData: {
    merchant_id: string;
    merchant_key: string;
    return_url: string;
    cancel_url: string;
    notify_url: string;
    name_first: string;
    name_last: string;
    email_address: string;
    cell_number?: string;
    m_payment_id: string;    // Order ID
    amount: string;
    item_name: string;
    item_description?: string;
    custom_int1?: number;
    custom_int2?: number;
    custom_int3?: number;
    custom_int4?: number;
    custom_int5?: number;
    custom_str1?: string;
    custom_str2?: string;
    custom_str3?: string;
    custom_str4?: string;
    custom_str5?: string;
    signature: string;       // MD5 signature
  };
  redirectUrl?: string;      // Direct redirect URL (optional)
  error?: string;
}
```

**Implementation Notes:**
- Generate MD5 signature for form security
- Include all custom fields for order tracking
- Return either HTML form or redirect URL
- Store form data in database for audit trail
- Set test mode based on environment

---

### 1.2 `payment.getPayFastFormSignature`

**Purpose:** Generate MD5 signature for PayFast form validation

**Input:**
```typescript
{
  merchantId: string;
  merchantKey: string;
  returnUrl: string;
  cancelUrl: string;
  notifyUrl: string;
  nameFirst: string;
  nameLast: string;
  emailAddress: string;
  mPaymentId: string;
  amount: number;
  itemName: string;
  itemDescription?: string;
  customFields?: {
    [key: string]: string | number;
  };
  passphrase: string;
}
```

**Output:**
```typescript
{
  signature: string;         // MD5 hash
  signatureString: string;   // String used for signature
}
```

**Implementation Notes:**
- Follow PayFast signature algorithm exactly
- Include passphrase in signature
- Signature is case-sensitive
- Used for form validation and ITN verification

---

## 2. PAYMENT PROCESSING & CONFIRMATION

### 2.1 `payment.processPayFastPayment`

**Purpose:** Process PayFast payment after customer submission

**Input:**
```typescript
{
  orderId: string;
  amount: number;
  paymentMethod: 'payfast';
  currency: 'ZAR';
  metadata?: {
    userId: string;
    customerEmail: string;
    itemCount: number;
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  paymentId: string;         // PayFast payment ID
  formUrl: string;           // URL to redirect customer to
  status: 'pending' | 'processing';
  createdAt: Date;
  expiresAt: Date;
  error?: string;
}
```

**Implementation Notes:**
- Create payment record in database
- Generate secure form
- Return redirect URL for customer
- Set 30-minute expiration
- Log payment initiation

---

### 2.2 `payment.confirmPayFastPayment`

**Purpose:** Confirm PayFast payment after ITN webhook

**Input:**
```typescript
{
  mPaymentId: string;        // Order ID from PayFast
  paymentStatus: string;     // 'COMPLETE', 'FAILED', 'PENDING'
  paymentId: string;         // PayFast transaction ID
  paymentAmount: number;
  paymentCurrency: string;
  paymentDate: string;
  signature: string;         // ITN signature
  itnData: any;              // Full ITN payload
}
```

**Output:**
```typescript
{
  success: boolean;
  orderId: string;
  orderStatus: 'paid' | 'failed' | 'pending';
  confirmationNumber: string;
  receiptUrl?: string;
  error?: string;
}
```

**Implementation Notes:**
- Verify ITN signature
- Idempotent operation (safe to call multiple times)
- Update order status based on payment status
- Send confirmation email
- Trigger fulfillment workflow

---

### 2.3 `payment.getPayFastPaymentStatus`

**Purpose:** Get current status of a PayFast payment

**Input:**
```typescript
{
  paymentId: string;         // PayFast transaction ID
  orderId?: string;          // Alternative lookup
}
```

**Output:**
```typescript
{
  paymentId: string;
  orderId: string;
  status: 'COMPLETE' | 'FAILED' | 'PENDING' | 'CANCELLED';
  amount: number;
  currency: string;
  paymentDate?: Date;
  paymentMethod: string;
  merchantId: string;
  createdAt: Date;
  updatedAt: Date;
  metadata?: any;
}
```

**Implementation Notes:**
- Query database first
- Fall back to PayFast API if needed
- Cache results for 5 minutes
- Handle rate limiting

---

## 3. ITN WEBHOOK HANDLING

### 3.1 `payment.handlePayFastITN`

**Purpose:** Handle PayFast Instant Transaction Notification (ITN) webhook

**Input:**
```typescript
{
  m_payment_id: string;      // Order ID
  pf_payment_id: string;     // PayFast transaction ID
  payment_status: string;    // 'COMPLETE', 'FAILED', 'PENDING'
  item_name: string;
  item_description?: string;
  amount_gross: number;
  amount_fee: number;
  amount_net: number;
  custom_int1?: number;
  custom_int2?: number;
  custom_int3?: number;
  custom_int4?: number;
  custom_int5?: number;
  custom_str1?: string;
  custom_str2?: string;
  custom_str3?: string;
  custom_str4?: string;
  custom_str5?: string;
  name_first: string;
  name_last: string;
  email_address: string;
  merchant_id: string;
  signature: string;         // ITN signature
  // ... other PayFast fields
}
```

**Output:**
```typescript
{
  success: boolean;
  processed: boolean;
  orderId: string;
  paymentStatus: string;
  error?: string;
  message: string;
}
```

**Supported Payment Statuses:**
- `COMPLETE` - Payment successful
- `FAILED` - Payment failed
- `PENDING` - Payment pending
- `CANCELLED` - Payment cancelled

**Implementation Notes:**
- Verify ITN signature using MD5
- Verify merchant ID matches
- Verify amount matches order total
- Idempotent processing (check if already processed)
- Store ITN payload in database
- Send confirmation back to PayFast
- Implement retry logic for failed processing
- Log all ITN events

---

### 3.2 `payment.verifyPayFastSignature`

**Purpose:** Verify PayFast ITN signature

**Input:**
```typescript
{
  itnData: {
    [key: string]: any;
  };
  signature: string;         // Signature from PayFast
  passphrase?: string;       // Optional passphrase
}
```

**Output:**
```typescript
{
  valid: boolean;
  calculatedSignature: string;
  providedSignature: string;
  error?: string;
}
```

**Implementation Notes:**
- Follow PayFast signature algorithm
- Include passphrase if configured
- Case-sensitive comparison
- Log signature mismatches

---

### 3.3 `payment.resendPayFastITN`

**Purpose:** Request PayFast to resend ITN for a transaction

**Input:**
```typescript
{
  paymentId: string;         // PayFast transaction ID
  reason?: string;           // Reason for resend
}
```

**Output:**
```typescript
{
  success: boolean;
  message: string;
  error?: string;
}
```

**Implementation Notes:**
- Use PayFast API to request resend
- Implement rate limiting
- Log resend requests
- Handle API errors gracefully

---

## 4. REFUNDS & DISPUTES

### 4.1 `payment.initiatePayFastRefund`

**Purpose:** Initiate a refund for a PayFast payment

**Input:**
```typescript
{
  paymentId: string;         // PayFast transaction ID
  amount?: number;           // Partial refund in ZAR (omit for full)
  reason: 'customer_request' | 'duplicate' | 'fraudulent' | 'other';
  description?: string;      // Refund reason details
  metadata?: {
    orderId: string;
    refundInitiatedBy: string;
  };
}
```

**Output:**
```typescript
{
  success: boolean;
  refundId: string;
  paymentId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  createdAt: Date;
  error?: string;
}
```

**Implementation Notes:**
- Validate refund amount doesn't exceed original
- Check refund eligibility (within 90 days)
- Create refund record in database
- Send refund notification to customer
- Update order status to 'refunded'
- Contact PayFast support for processing

---

### 4.2 `payment.getPayFastRefundStatus`

**Purpose:** Get status of a PayFast refund

**Input:**
```typescript
{
  refundId: string;
  paymentId?: string;
}
```

**Output:**
```typescript
{
  refundId: string;
  paymentId: string;
  amount: number;
  currency: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  reason: string;
  createdAt: Date;
  completedAt?: Date;
  error?: string;
}
```

**Implementation Notes:**
- Query database for refund status
- Contact PayFast for updates if needed
- Cache results for 10 minutes
- Handle refund failures gracefully

---

### 4.3 `admin.payment.getPayFastDisputes`

**Purpose:** Get list of PayFast payment disputes

**Input:**
```typescript
{
  status?: 'open' | 'resolved' | 'won' | 'lost';
  dateFrom?: Date;
  dateTo?: Date;
  limit?: number;
  offset?: number;
}
```

**Output:**
```typescript
{
  disputes: Array<{
    disputeId: string;
    paymentId: string;
    orderId: string;
    amount: number;
    reason: string;
    status: string;
    createdAt: Date;
    dueDate: Date;
    evidence?: string;
  }>;
  total: number;
  limit: number;
  offset: number;
}
```

**Implementation Notes:**
- Query PayFast API for disputes
- Store dispute data in database
- Alert admin on new disputes
- Track dispute resolution

---

## 5. PAYMENT HISTORY & ANALYTICS

### 5.1 `payment.getPayFastPaymentHistory`

**Purpose:** Get user's PayFast payment history

**Input:**
```typescript
{
  userId: string;
  limit?: number;            // Default: 20, Max: 100
  offset?: number;           // Default: 0
  status?: 'COMPLETE' | 'FAILED' | 'PENDING';
  dateFrom?: Date;
  dateTo?: Date;
}
```

**Output:**
```typescript
{
  payments: Array<{
    paymentId: string;
    orderId: string;
    amount: number;
    currency: string;
    status: string;
    paymentDate: Date;
    receiptUrl?: string;
  }>;
  total: number;
  limit: number;
  offset: number;
}
```

**Implementation Notes:**
- Paginate results for performance
- Filter by date range
- Include receipt URLs
- Sort by date descending

---

### 5.2 `admin.payment.getPayFastAnalytics`

**Purpose:** Get PayFast payment analytics for admin dashboard

**Input:**
```typescript
{
  dateFrom: Date;
  dateTo: Date;
  groupBy?: 'day' | 'week' | 'month';
}
```

**Output:**
```typescript
{
  totalTransactions: number;
  totalAmount: number;        // In ZAR
  successRate: number;        // Percentage
  averageTransactionValue: number;
  transactionsByStatus: {
    COMPLETE: number;
    FAILED: number;
    PENDING: number;
  };
  failureReasons?: {
    [reason: string]: number;
  };
  dailyBreakdown?: Array<{
    date: Date;
    transactions: number;
    amount: number;
    successRate: number;
  }>;
  refundStats?: {
    totalRefunds: number;
    totalRefundAmount: number;
    averageRefundAmount: number;
  };
}
```

**Implementation Notes:**
- Cache results for 1 hour
- Generate daily reports
- Export to CSV functionality
- Alert on anomalies

---

### 5.3 `admin.payment.getPayFastReconciliation`

**Purpose:** Get PayFast transaction reconciliation report

**Input:**
```typescript
{
  dateFrom: Date;
  dateTo: Date;
  includeRefunds?: boolean;
}
```

**Output:**
```typescript
{
  period: {
    from: Date;
    to: Date;
  };
  summary: {
    totalTransactions: number;
    totalAmount: number;
    totalFees: number;
    netAmount: number;
  };
  transactions: Array<{
    paymentId: string;
    orderId: string;
    amount: number;
    fee: number;
    net: number;
    status: string;
    date: Date;
  }>;
  discrepancies?: Array<{
    type: string;
    description: string;
    amount: number;
  }>;
}
```

**Implementation Notes:**
- Query both database and PayFast API
- Identify discrepancies
- Generate audit trail
- Export for accounting

---

## 6. TRANSACTION MANAGEMENT

### 6.1 `admin.payment.getPayFastTransaction`

**Purpose:** Get detailed PayFast transaction information

**Input:**
```typescript
{
  paymentId: string;
}
```

**Output:**
```typescript
{
  paymentId: string;
  orderId: string;
  status: string;
  amount: number;
  fee: number;
  net: number;
  currency: string;
  paymentDate: Date;
  customerName: string;
  customerEmail: string;
  itemName: string;
  itemDescription?: string;
  customFields: {
    [key: string]: any;
  };
  refunds?: Array<{
    refundId: string;
    amount: number;
    date: Date;
    status: string;
  }>;
  metadata?: any;
}
```

---

### 6.2 `admin.payment.updatePayFastTransactionStatus`

**Purpose:** Manually update PayFast transaction status (admin only)

**Input:**
```typescript
{
  paymentId: string;
  status: 'COMPLETE' | 'FAILED' | 'PENDING' | 'CANCELLED';
  reason?: string;
  notes?: string;
}
```

**Output:**
```typescript
{
  success: boolean;
  paymentId: string;
  newStatus: string;
  previousStatus: string;
  error?: string;
}
```

**Implementation Notes:**
- Admin only operation
- Log status changes
- Send notifications to customer
- Update order status accordingly

---

## 7. TEST MODE & DEBUGGING

### 7.1 `payment.testPayFastConnection`

**Purpose:** Test PayFast API connection and credentials

**Input:**
```typescript
{
  testMode?: boolean;
}
```

**Output:**
```typescript
{
  connected: boolean;
  merchantId: string;
  merchantKey: string;
  apiVersion: string;
  testMode: boolean;
  error?: string;
}
```

**Implementation Notes:**
- Verify credentials
- Test API connectivity
- Check merchant status
- Return API version

---

### 7.2 `payment.generatePayFastTestPayment`

**Purpose:** Generate a test payment form for development

**Input:**
```typescript
{
  amount?: number;           // Default: 100.00 ZAR
  orderId?: string;
  testMode: true;
}
```

**Output:**
```typescript
{
  success: boolean;
  formHtml: string;
  testCredentials: {
    testCard: string;
    testAmount: number;
    testEmail: string;
  };
  redirectUrl: string;
}
```

**Implementation Notes:**
- Use test merchant credentials
- Return test card details
- Generate test form
- Include test email address

---

## 8. SECURITY & COMPLIANCE

### 8.1 Security Measures

**MD5 Signature Verification:**
```typescript
function generatePayFastSignature(data: any, passphrase: string): string {
  const fields = [
    'amount', 'item_name', 'item_description', 'custom_int1', 
    'custom_int2', 'custom_int3', 'custom_int4', 'custom_int5',
    'custom_str1', 'custom_str2', 'custom_str3', 'custom_str4',
    'custom_str5', 'name_first', 'name_last', 'email_address',
    'merchant_id'
  ];
  
  let stringToSign = '';
  fields.forEach(field => {
    if (data[field]) stringToSign += data[field];
  });
  
  stringToSign += passphrase;
  
  return crypto.createHash('md5').update(stringToSign).digest('hex');
}
```

### 8.2 PCI DSS Compliance

- ✅ Never store raw card data
- ✅ Use PayFast hosted payment page
- ✅ Encrypt data in transit (TLS 1.2+)
- ✅ Implement access controls
- ✅ Regular security audits
- ✅ Log all payment operations
- ✅ Mask sensitive data in logs

### 8.3 Error Handling

- Sensitive data masking - Never log card details
- Generic error messages - Don't expose system details
- Retry logic - Automatic retry for transient failures
- Dead letter queue - Failed webhooks stored for manual review
- Monitoring alerts - Alert on payment failures

---

## 9. ERROR CODES & HANDLING

### Common PayFast Error Codes

| Code | Message | Action |
|------|---------|--------|
| 0 | Success | Process payment |
| 1 | General error | Retry or contact support |
| 2 | Insufficient funds | Customer needs to add funds |
| 3 | Transaction declined | Retry with different card |
| 4 | Invalid card | Customer needs valid card |
| 5 | Expired card | Customer needs new card |
| 6 | Invalid amount | Verify order amount |
| 7 | Invalid merchant | Check merchant credentials |
| 8 | Invalid transaction | Verify transaction details |

---

## 10. IMPLEMENTATION CHECKLIST

- [ ] Database schema created
- [ ] PayFast service implemented
- [ ] All tRPC endpoints created
- [ ] ITN webhook handler implemented
- [ ] Signature verification tested
- [ ] Error handling tested
- [ ] Security audit completed
- [ ] Rate limiting implemented
- [ ] Logging configured
- [ ] Email templates created
- [ ] Admin dashboard built
- [ ] Customer notifications sent
- [ ] Documentation updated
- [ ] Team trained
- [ ] Test mode verified
- [ ] Production deployment tested

---

## 11. TESTING CHECKLIST

### Unit Tests
- [ ] Signature generation and validation
- [ ] Payment form creation
- [ ] ITN processing
- [ ] Refund initiation
- [ ] Error handling

### Integration Tests
- [ ] End-to-end payment flow
- [ ] ITN webhook delivery
- [ ] Refund workflow
- [ ] Reconciliation reports
- [ ] Test mode payments

### Manual Tests
- [ ] Test payment form
- [ ] Test ITN webhook
- [ ] Test refund request
- [ ] Test reconciliation
- [ ] Test error scenarios

---

## 12. DEPLOYMENT CHECKLIST

- [ ] PayFast credentials configured
- [ ] ITN webhook URL registered
- [ ] SSL/TLS certificates installed
- [ ] Database migrations applied
- [ ] Email service configured
- [ ] Monitoring alerts set up
- [ ] Backup procedures tested
- [ ] Rollback plan documented
- [ ] Team trained
- [ ] Support documentation ready
- [ ] Go-live approval obtained

---

## SUMMARY

This specification covers 18 major tRPC endpoints for PayFast integration, organized into 8 functional areas:

1. **Payment Form Generation** (2 endpoints)
2. **Payment Processing** (3 endpoints)
3. **ITN Webhook Handling** (3 endpoints)
4. **Refunds & Disputes** (3 endpoints)
5. **History & Analytics** (3 endpoints)
6. **Transaction Management** (2 endpoints)
7. **Test Mode & Debugging** (2 endpoints)
8. **Security & Compliance** (Integrated throughout)

**Total: 18 tRPC endpoints**

All endpoints include comprehensive error handling, security measures, and logging for production-ready implementation.

---

**Document Version:** 1.0
**Last Updated:** January 20, 2026
**Status:** Ready for Implementation
**PayFast API Version:** v1
**Merchant ID:** 11071120
