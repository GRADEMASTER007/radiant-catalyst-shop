# Dragon Fruit SA - E-Commerce Platform Setup Guide

## Project Overview

This is a comprehensive e-commerce platform built with React 19, Express, tRPC, and MySQL. It includes:

- **Admin Panel** with AI-powered prompt interface
- **OpenRouter AI Integration** with multiple model selection
- **Ollama Cloud Models** for AI assistance
- **Payment Processing** (PayFast, Yoco)
- **Live Shipping Tracking** (Courier Guy, PUDO)
- **WhatsApp Integration**
- **Multi-currency Support** (ZAR/USD)
- **SEO Optimization** with SerpAPI
- **Product Management**
- **Order Management**
- **Blog System**

## Quick Start

### 1. Installation

```bash
cd /home/ubuntu/african-vibe-ecommerce-template
pnpm install
```

### 2. Environment Setup

Create a `.env.local` file with the following variables:

```env
# Database
DATABASE_URL=your_mysql_connection_string

# OAuth
VITE_APP_ID=your_manus_app_id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im

# AI APIs
VITE_OPENROUTER_API_KEY=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
OLLAMA_API_KEY=cebbc97e307d4e4d9b8a28d8e7b4d32d.SHRF1ZEiQEeRGK6vU4rLMvC4

# Payment Gateways
PAYFAST_MERCHANT_ID=11071120
PAYFAST_MERCHANT_KEY=p6fi9ewdjk1js
PAYFAST_PASSPHRASE=abCd15ab92g12

YOCO_API_KEY=yoco_live_1be907c4ffe80376_3f05d1d6503c605b73555b677b80697f
YOCO_PUBLIC_KEY=pk_live_b21ac3bd1WM6WRY3f9f4
YOCO_SECRET_KEY=sk_live_87380fcbgEgAEJa48704613a39ec

# Shipping
COURIER_GUY_API_KEY=e28f9909fa734d0a8ce9641c8db68c9f
PUDO_API_KEY=51577192|tCQuvbHTuSMgUYgb1Bqh5IEG48DbXXkHF6yBGQYN02422ea5

# Email
EMAIL_SMTP_HOST=mail.proagrisa.co.za
EMAIL_SMTP_PORT=465
EMAIL_SMTP_USER=orders@proagrisa.co.za
EMAIL_SMTP_PASSWORD=Kyknet.01
EMAIL_FROM=orders@proagrisa.co.za

# SEO
SERPAPI_API_KEY=c1ff1791c17d28baf2c8d4dde29b12ef6064a3f19a3c55dee939f6512378aa04

# GitHub
GITHUB_TOKEN=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
```

### 3. Database Setup

Push the database schema:

```bash
pnpm db:push
```

### 4. Initialize Admin User

```bash
node scripts/init-admin.mjs
```

This creates an admin user with:
- **Username:** admin
- **Password:** Kyknet.01
- **Email:** admin@proagrisa.co.za

### 5. Start Development Server

```bash
pnpm dev
```

The server will start on `http://localhost:3000` (or next available port if 3000 is busy).

## Accessing the Application

### Homepage
- **URL:** `http://localhost:3000`
- Features: Product showcase, AI assistant chat, contact information

### Admin Panel
- **URL:** `http://localhost:3000/admin/login`
- **Username:** admin
- **Password:** Kyknet.01

### Admin Dashboard Features

#### AI Prompt Interface
- Select from 11 OpenRouter AI models
- Enter prompts up to 1000 words
- Get AI-generated content for:
  - Product descriptions
  - SEO metadata
  - Blog posts
  - Code generation
  - Business improvements

#### Available Models
1. Nvidia Nemotron 3 Nano
2. Mistral Devstral 2512
3. Qwen 3 Next 80B
4. OpenAI GPT OSS 120B
5. Qwen 3 Coder
6. Kimi K2
7. DeepSeek R1T2 Chimera
8. DeepSeek R1 0528
9. Qwen 3 4B
10. Llama 3.2 3B
11. Qwen 2.5 VL 7B

## Contact Information

**Reception & Assistant**
- Phone: +1 351 777 2848
- After-Hours: 083 447 4639

**WhatsApp Support**
- +27 83 447 4639
- +1 555 708 3482

**Email**
- admin@proagrisa.co.za

## Project Structure

```
client/
  src/
    pages/
      Home.tsx              - Homepage with banner and AI assistant
      AdminLogin.tsx        - Admin login page
      AdminDashboard.tsx    - Admin panel with AI prompt interface
    components/
      ui/                   - shadcn/ui components
    lib/
      trpc.ts              - tRPC client configuration
    App.tsx                - Main app router
server/
  adminRouter.ts           - Admin authentication routes
  db.ts                    - Database operations
  routers.ts               - Main tRPC router
  _core/
    index.ts               - Express server setup
    context.ts             - tRPC context
    oauth.ts               - OAuth configuration
drizzle/
  schema.ts                - Database schema
  migrations/              - Database migrations
```

## Key Features

### 1. Admin Authentication
- Local username/password authentication
- Session-based with 7-day expiration
- Secure password hashing with bcrypt

### 2. AI Integration
- OpenRouter API with 11 free models
- Ollama Cloud Models support
- Real-time AI responses
- Copy response to clipboard

### 3. Payment Processing
- PayFast integration for South African market
- Yoco as secondary payment option
- Real-time ZAR to USD conversion
- Transaction tracking

### 4. Shipping & Tracking
- Courier Guy integration
- PUDO locker support
- Live tracking updates
- Estimated delivery times

### 5. Email System
- SMTP configuration for automated emails
- Order confirmations
- Payment receipts
- Shipping notifications
- Delivery confirmations

### 6. Product Management
- Product upload interface
- Image management with optimization
- Multi-language support
- SEO fields per product
- Inventory tracking

### 7. SEO Optimization
- XML sitemaps
- Structured data (Schema.org)
- Meta tags optimization
- Canonical URLs
- International hreflang tags

## API Endpoints

### Admin Routes
- `POST /api/trpc/admin.login` - Admin login
- `POST /api/trpc/admin.logout` - Admin logout
- `GET /api/trpc/admin.me` - Get current admin user

### System Routes
- `GET /api/trpc/system.health` - Health check
- `POST /api/trpc/system.notifyOwner` - Send owner notification

## Testing

### Test Admin Login
1. Go to `http://localhost:3000/admin/login`
2. Enter username: `admin`
3. Enter password: `Kyknet.01`
4. Click Login

### Test AI Prompt
1. After login, go to Admin Dashboard
2. Select an AI model from the dropdown
3. Enter a prompt (e.g., "Generate 5 product descriptions for dragon fruit")
4. Click "Send Prompt"
5. Wait for AI response

### Test Payment Integration
- Use PayFast test mode with test merchant credentials
- Use Yoco test mode with test API keys

## Troubleshooting

### Admin Login Not Working
- Check if admin user was created: `node scripts/init-admin.mjs`
- Verify database connection
- Check browser console for errors

### AI Prompt Returns Error
- Verify OpenRouter API key is set correctly
- Check if model name is correct
- Ensure internet connection is working

### Database Connection Issues
- Verify DATABASE_URL is correct
- Check MySQL server is running
- Ensure database user has proper permissions

## Build & Deployment

### Production Build
```bash
pnpm build
```

### Start Production Server
```bash
NODE_ENV=production pnpm start
```

## Support

For issues or questions:
- Email: admin@proagrisa.co.za
- WhatsApp: +27 83 447 4639
- Phone: +1 351 777 2848

## License

All rights reserved © 2024 Dragon Fruit SA
