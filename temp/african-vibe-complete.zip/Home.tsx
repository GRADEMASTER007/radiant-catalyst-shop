import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, Phone, Mail, MapPin, Zap, Leaf, Beaker } from "lucide-react";

export default function Home() {
  const [aiMessage, setAiMessage] = useState("");

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-white">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-purple-600">Dragon Fruit SA</div>
          <div className="flex items-center gap-4">
            <Link href="/admin/login">
              <Button variant="outline" size="sm">Admin</Button>
            </Link>
            <Button size="sm" className="bg-purple-600 hover:bg-purple-700">Shop Now</Button>
          </div>
        </div>
      </nav>

      {/* Movie Banner Section */}
      <section className="relative h-96 bg-gradient-to-r from-purple-900 via-purple-800 to-purple-900 overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml,...')] animate-pulse"></div>
        </div>
        <div className="relative h-full flex items-center justify-center">
          <div className="text-center text-white space-y-4">
            <h1 className="text-5xl font-bold">Premium Dragon Fruit & African Products</h1>
            <p className="text-xl text-purple-100">Fresh, Organic, Sustainably Sourced</p>
            <Button size="lg" className="bg-white text-purple-900 hover:bg-gray-100">
              Explore Products
            </Button>
          </div>
        </div>
      </section>

      {/* AI Assistant Chat */}
      <section className="py-12 bg-white">
        <div className="max-w-2xl mx-auto px-4">
          <Card className="border-2 border-purple-200">
            <CardContent className="p-6">
              <h2 className="text-2xl font-bold mb-4">AI Shopping Assistant</h2>
              <p className="text-gray-600 mb-4">Ask me anything about our products, shipping, or services!</p>
              <div className="space-y-3">
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-700">{aiMessage || "Hello! I'm your AI assistant. How can I help you today?"}</p>
                </div>
                <input
                  type="text"
                  placeholder="Type your question..."
                  value={aiMessage}
                  onChange={(e) => setAiMessage(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
                />
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Send Message</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Product Categories */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Beaker, title: "Scientific Uses", desc: "Research & Development" },
              { icon: Leaf, title: "Food Industry", desc: "Culinary & Processing" },
              { icon: Zap, title: "Health Benefits", desc: "Nutritional & Wellness" },
            ].map((cat, i) => (
              <Card key={i} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6 text-center">
                  <cat.icon className="w-12 h-12 mx-auto mb-4 text-purple-600" />
                  <h3 className="font-bold text-lg mb-2">{cat.title}</h3>
                  <p className="text-gray-600 text-sm">{cat.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Contact Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <Phone className="w-6 h-6 text-purple-600 mt-1" />
                <div>
                  <h3 className="font-bold mb-2">Reception & Assistant</h3>
                  <p className="text-gray-600">Phone: +1 351 777 2848</p>
                  <p className="text-gray-600">After-Hours: 083 447 4639</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <MessageCircle className="w-6 h-6 text-purple-600 mt-1" />
                <div>
                  <h3 className="font-bold mb-2">WhatsApp Support</h3>
                  <p className="text-gray-600">+27 83 447 4639</p>
                  <p className="text-gray-600">+1 555 708 3482</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Mail className="w-6 h-6 text-purple-600 mt-1" />
                <div>
                  <h3 className="font-bold mb-2">Email</h3>
                  <p className="text-gray-600">admin@proagrisa.co.za</p>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="font-bold text-lg">Quick Links</h3>
              <ul className="space-y-2">
                <li><Link href="/shop"><Button variant="link">Shop Products</Button></Link></li>
                <li><Link href="/tracking"><Button variant="link">Track Order</Button></Link></li>
                <li><Link href="/about"><Button variant="link">About Us</Button></Link></li>
                <li><Link href="/blog"><Button variant="link">Blog</Button></Link></li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>&copy; 2024 Dragon Fruit SA. All rights reserved.</p>
          <p className="text-gray-400 text-sm mt-2">Premium African Products & Fresh Dragon Fruit</p>
        </div>
      </footer>
    </div>
  );
}
