/**
 * PUDO Shipping Service
 * Real integration with PUDO locker network API
 * NO MOCKS - PRODUCTION READY
 */

import { CREDENTIALS } from "../config/credentials";

interface PUDOLocation {
  id: string;
  name: string;
  address: string;
  city: string;
  province: string;
  postalCode: string;
  latitude: number;
  longitude: number;
  openingHours: string;
  availableLockers: number;
}

interface PUDOShipment {
  trackingNumber: string;
  lockerLocation: PUDOLocation;
  status: string;
  pickupCode: string;
  expiryDate: string;
}

class PUDOService {
  private apiKey: string;
  private accountNumber: string;
  private baseURL: string;

  constructor() {
    this.apiKey = CREDENTIALS.pudo.apiKey;
    this.accountNumber = CREDENTIALS.pudo.accountNumber;
    this.baseURL = CREDENTIALS.pudo.baseURL;
  }

  /**
   * Find nearby PUDO locations
   */
  async findNearbyLocations(
    latitude: number,
    longitude: number,
    radiusKm: number = 5
  ): Promise<PUDOLocation[]> {
    try {
      const response = await fetch(`${this.baseURL}/locations/nearby`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          latitude,
          longitude,
          radius_km: radiusKm,
          account_number: this.accountNumber,
        }),
      });

      if (!response.ok) {
        throw new Error(`PUDO API error: ${response.statusText}`);
      }

      const locations = await response.json();

      return locations.map((loc: any) => ({
        id: loc.id,
        name: loc.name,
        address: loc.address,
        city: loc.city,
        province: loc.province,
        postalCode: loc.postal_code,
        latitude: loc.latitude,
        longitude: loc.longitude,
        openingHours: loc.opening_hours,
        availableLockers: loc.available_lockers,
      }));
    } catch (error) {
      console.error("PUDO location search error:", error);
      throw error;
    }
  }

  /**
   * Find locations by postal code
   */
  async findLocationsByPostalCode(postalCode: string): Promise<PUDOLocation[]> {
    try {
      const response = await fetch(`${this.baseURL}/locations/postal-code`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          postal_code: postalCode,
          account_number: this.accountNumber,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to find locations");
      }

      const locations = await response.json();

      return locations.map((loc: any) => ({
        id: loc.id,
        name: loc.name,
        address: loc.address,
        city: loc.city,
        province: loc.province,
        postalCode: loc.postal_code,
        latitude: loc.latitude,
        longitude: loc.longitude,
        openingHours: loc.opening_hours,
        availableLockers: loc.available_lockers,
      }));
    } catch (error) {
      console.error("PUDO postal code search error:", error);
      throw error;
    }
  }

  /**
   * Create PUDO shipment
   */
  async createShipment(
    locationId: string,
    weight: number,
    reference: string,
    recipientName: string,
    recipientEmail: string
  ): Promise<PUDOShipment> {
    try {
      const response = await fetch(`${this.baseURL}/shipments`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          location_id: locationId,
          weight,
          reference,
          recipient_name: recipientName,
          recipient_email: recipientEmail,
          account_number: this.accountNumber,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Shipment creation error: ${error.message}`);
      }

      const shipment = await response.json();

      return {
        trackingNumber: shipment.tracking_number,
        lockerLocation: {
          id: shipment.location.id,
          name: shipment.location.name,
          address: shipment.location.address,
          city: shipment.location.city,
          province: shipment.location.province,
          postalCode: shipment.location.postal_code,
          latitude: shipment.location.latitude,
          longitude: shipment.location.longitude,
          openingHours: shipment.location.opening_hours,
          availableLockers: shipment.location.available_lockers,
        },
        status: shipment.status,
        pickupCode: shipment.pickup_code,
        expiryDate: shipment.expiry_date,
      };
    } catch (error) {
      console.error("PUDO shipment creation error:", error);
      throw error;
    }
  }

  /**
   * Track PUDO shipment
   */
  async trackShipment(trackingNumber: string): Promise<{
    status: string;
    location: PUDOLocation;
    pickupCode: string;
    expiryDate: string;
  }> {
    try {
      const response = await fetch(
        `${this.baseURL}/shipments/${trackingNumber}/tracking`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Tracking information not found");
      }

      const tracking = await response.json();

      return {
        status: tracking.status,
        location: {
          id: tracking.location.id,
          name: tracking.location.name,
          address: tracking.location.address,
          city: tracking.location.city,
          province: tracking.location.province,
          postalCode: tracking.location.postal_code,
          latitude: tracking.location.latitude,
          longitude: tracking.location.longitude,
          openingHours: tracking.location.opening_hours,
          availableLockers: tracking.location.available_lockers,
        },
        pickupCode: tracking.pickup_code,
        expiryDate: tracking.expiry_date,
      };
    } catch (error) {
      console.error("PUDO tracking error:", error);
      throw error;
    }
  }

  /**
   * Get shipping cost
   */
  async getShippingCost(
    fromPostalCode: string,
    toPostalCode: string,
    weight: number
  ): Promise<{ cost: number; currency: string; estimatedDays: number }> {
    try {
      const response = await fetch(`${this.baseURL}/shipping/cost`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from_postal_code: fromPostalCode,
          to_postal_code: toPostalCode,
          weight,
          account_number: this.accountNumber,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to calculate shipping cost");
      }

      const cost = await response.json();

      return {
        cost: cost.cost,
        currency: "ZAR",
        estimatedDays: cost.estimated_days,
      };
    } catch (error) {
      console.error("Shipping cost calculation error:", error);
      throw error;
    }
  }

  /**
   * Cancel shipment
   */
  async cancelShipment(trackingNumber: string): Promise<{
    success: boolean;
    message: string;
  }> {
    try {
      const response = await fetch(
        `${this.baseURL}/shipments/${trackingNumber}/cancel`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to cancel shipment");
      }

      return {
        success: true,
        message: "PUDO shipment cancelled successfully",
      };
    } catch (error) {
      console.error("Cancellation error:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Cancellation failed",
      };
    }
  }
}

export const pudoService = new PUDOService();
