/**
 * AI tRPC Router
 * Provides type-safe API endpoints for AI operations
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { aiRouter } from "./services/ai-router";

export const aiTRPCRouter = router({
  /**
   * Query AI with automatic service selection
   */
  query: publicProcedure
    .input(
      z.object({
        prompt: z.string().min(1).max(10000),
        taskType: z
          .enum(["general", "code", "content", "seo", "image", "debug"])
          .optional(),
        complexity: z.enum(["low", "medium", "high"]).optional(),
        urgency: z.enum(["low", "normal", "high"]).optional(),
        maxCost: z.number().optional(),
        preferredModel: z.string().optional(),
        temperature: z.number().min(0).max(1).default(0.7),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await aiRouter.query(input);
        return response;
      } catch (error) {
        console.error("AI Query Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "AI query failed"
        );
      }
    }),

  /**
   * Get current AI usage statistics
   */
  getStats: publicProcedure.query(() => {
    return aiRouter.getStats();
  }),

  /**
   * Test AI connection to specific service
   */
  testService: publicProcedure
    .input(
      z.object({
        service: z.enum([
          "ollama_cloud",
          "ollama_local",
          "openrouter",
          "kilocode",
        ]),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await aiRouter.query({
          prompt: "Say 'AI service working' in 5 words or less.",
          taskType: "general",
          complexity: "low",
          urgency: "high",
          preferredModel: undefined,
        });

        return {
          success: true,
          service: input.service,
          response: response.response,
          responseTime: response.responseTime,
        };
      } catch (error) {
        return {
          success: false,
          service: input.service,
          error: error instanceof Error ? error.message : "Unknown error",
        };
      }
    }),

  /**
   * Generate content with AI
   */
  generateContent: publicProcedure
    .input(
      z.object({
        contentType: z.enum([
          "product_description",
          "seo_meta",
          "blog_post",
          "social_media",
          "email",
        ]),
        topic: z.string(),
        tone: z
          .enum(["professional", "casual", "friendly", "technical"])
          .optional(),
        length: z.enum(["short", "medium", "long"]).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const prompts: Record<string, string> = {
        product_description: `Write a compelling product description for: ${input.topic}. Include benefits, features, and call-to-action.`,
        seo_meta: `Generate SEO-optimized meta title and description for: ${input.topic}. Include relevant keywords.`,
        blog_post: `Write a comprehensive blog post about: ${input.topic}. Include introduction, main points, and conclusion.`,
        social_media: `Create engaging social media posts about: ${input.topic}. Include hashtags and emojis.`,
        email: `Write a professional email about: ${input.topic}. Include subject line and body.`,
      };

      const prompt = prompts[input.contentType];

      const response = await aiRouter.query({
        prompt,
        taskType: "content",
        complexity: input.length === "long" ? "high" : "medium",
        temperature: input.tone === "casual" ? 0.8 : 0.5,
      });

      return response;
    }),

  /**
   * Generate code with AI
   */
  generateCode: publicProcedure
    .input(
      z.object({
        description: z.string(),
        language: z
          .enum(["javascript", "typescript", "python", "sql", "html", "css"])
          .optional(),
        includeComments: z.boolean().optional(),
        includeTests: z.boolean().optional(),
      })
    )
    .mutation(async ({ input }) => {
      let prompt = `Generate ${input.language || "JavaScript"} code for: ${input.description}`;

      if (input.includeComments) {
        prompt += " Include detailed comments explaining the code.";
      }

      if (input.includeTests) {
        prompt += " Include unit tests.";
      }

      const response = await aiRouter.query({
        prompt,
        taskType: "code",
        complexity: "high",
        preferredModel: undefined,
      });

      return response;
    }),

  /**
   * Optimize SEO with AI
   */
  optimizeSEO: publicProcedure
    .input(
      z.object({
        content: z.string(),
        keywords: z.array(z.string()).optional(),
        targetAudience: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      let prompt = `Optimize this content for SEO:\n\n${input.content}`;

      if (input.keywords && input.keywords.length > 0) {
        prompt += `\n\nTarget keywords: ${input.keywords.join(", ")}`;
      }

      if (input.targetAudience) {
        prompt += `\n\nTarget audience: ${input.targetAudience}`;
      }

      prompt +=
        "\n\nProvide optimized content with improved keywords, structure, and readability.";

      const response = await aiRouter.query({
        prompt,
        taskType: "seo",
        complexity: "medium",
      });

      return response;
    }),

  /**
   * Debug code with AI
   */
  debugCode: publicProcedure
    .input(
      z.object({
        code: z.string(),
        error: z.string(),
        language: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const prompt = `Debug this ${input.language || "code"}:\n\nCode:\n${input.code}\n\nError:\n${input.error}\n\nProvide a detailed explanation of the issue and how to fix it.`;

      const response = await aiRouter.query({
        prompt,
        taskType: "debug",
        complexity: "high",
        urgency: "high",
      });

      return response;
    }),

  /**
   * Analyze image with AI
   */
  analyzeImage: publicProcedure
    .input(
      z.object({
        imageUrl: z.string().url(),
        analysisType: z.enum([
          "description",
          "objects",
          "text",
          "sentiment",
          "quality",
        ]),
      })
    )
    .mutation(async ({ input }) => {
      const prompts: Record<string, string> = {
        description: `Describe this image in detail: ${input.imageUrl}`,
        objects: `List all objects and elements in this image: ${input.imageUrl}`,
        text: `Extract and transcribe all text from this image: ${input.imageUrl}`,
        sentiment: `Analyze the emotional tone and sentiment of this image: ${input.imageUrl}`,
        quality: `Evaluate the quality, composition, and technical aspects of this image: ${input.imageUrl}`,
      };

      const prompt = prompts[input.analysisType];

      const response = await aiRouter.query({
        prompt,
        taskType: "image",
        complexity: "medium",
      });

      return response;
    }),
});
