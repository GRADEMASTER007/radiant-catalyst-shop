import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { verifyAdminPassword, createAdminSession, getAdminSessionByToken, deleteAdminSession } from "./db";
import { TRPCError } from "@trpc/server";

export const adminRouter = router({
  login: publicProcedure
    .input(z.object({
      username: z.string().min(1),
      password: z.string().min(1),
    }))
    .mutation(async ({ input, ctx }) => {
      try {
        // Verify credentials
        const adminUser = await verifyAdminPassword(input.username, input.password);
        if (!adminUser) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: "Invalid username or password",
          });
        }

        // Create session
        const { sessionToken, expiresAt } = await createAdminSession(adminUser.id);

        // Set session cookie
        ctx.res.cookie("admin_session", sessionToken, {
          httpOnly: true,
          secure: process.env.NODE_ENV === "production",
          sameSite: "lax",
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        });

        return {
          success: true,
          admin: {
            id: adminUser.id,
            username: adminUser.username,
            email: adminUser.email,
            role: adminUser.role,
          },
        };
      } catch (error) {
        console.error("Admin login error:", error);
        throw error;
      }
    }),

  logout: publicProcedure
    .mutation(async ({ ctx }) => {
      const sessionToken = ctx.req.cookies?.admin_session;
      if (sessionToken) {
        await deleteAdminSession(sessionToken);
      }
      
      ctx.res.clearCookie("admin_session");
      return { success: true };
    }),

  me: publicProcedure
    .query(async ({ ctx }) => {
      const sessionToken = ctx.req.cookies?.admin_session;
      if (!sessionToken) {
        return null;
      }

      try {
        const session = await getAdminSessionByToken(sessionToken);
        if (!session) {
          ctx.res.clearCookie("admin_session");
          return null;
        }

        return {
          id: session.adminUser?.id,
          username: session.adminUser?.username,
          email: session.adminUser?.email,
          role: session.adminUser?.role,
        };
      } catch (error) {
        console.error("Error getting admin session:", error);
        return null;
      }
    }),
});
