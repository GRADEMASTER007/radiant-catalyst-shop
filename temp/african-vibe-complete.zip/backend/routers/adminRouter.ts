/**
 * Admin Router
 * Handles admin authentication and operations
 */

import { router, publicProcedure, protectedProcedure } from '../trpc';
import { z } from 'zod';
import * as dbOps from '../db';

export const adminRouter = router({
  /**
   * Admin Login
   */
  login: publicProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input }) => {
      try {
        const admin = await dbOps.authenticateAdmin(input.username, input.password);

        if (!admin) {
          return {
            success: false,
            error: 'Invalid username or password',
          };
        }

        const sessionId = await dbOps.createAdminSession(admin.id);

        return {
          success: true,
          sessionId,
          admin: {
            id: admin.id,
            username: admin.username,
            email: admin.email,
          },
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Login failed',
        };
      }
    }),

  /**
   * Admin Logout
   */
  logout: protectedProcedure.mutation(async ({ ctx }) => {
    // In production, invalidate session in database
    return { success: true };
  }),

  /**
   * Get Admin Profile
   */
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    return {
      adminId: ctx.adminId,
      sessionId: ctx.sessionId,
    };
  }),

  /**
   * Initialize Admin User (first-time setup)
   */
  initializeAdmin: publicProcedure.mutation(async () => {
    try {
      const admin = await dbOps.initializeAdminUser();
      return {
        success: true,
        message: 'Admin user initialized',
        admin: {
          id: admin.id,
          username: admin.username,
          email: admin.email,
        },
      };
    } catch (error) {
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Initialization failed',
      };
    }
  }),
});

export default adminRouter;
