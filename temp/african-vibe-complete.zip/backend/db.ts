/**
 * Database Operations
 * Handles all database queries and operations
 */

import { db } from './schema';
import { users, adminUsers, adminSessions, aiQueries } from './schema';
import { eq, desc } from 'drizzle-orm';
import crypto from 'crypto';

/**
 * Admin Authentication
 */
export async function authenticateAdmin(username: string, password: string) {
  const admin = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.username, username))
    .limit(1);

  if (!admin.length) return null;

  const adminUser = admin[0];
  const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

  if (adminUser.passwordHash !== hashedPassword) {
    return null;
  }

  return adminUser;
}

/**
 * Create Admin Session
 */
export async function createAdminSession(adminId: string) {
  const sessionId = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

  await db.insert(adminSessions).values({
    id: crypto.randomUUID(),
    adminId,
    sessionId,
    expiresAt,
    createdAt: new Date(),
  });

  return sessionId;
}

/**
 * Verify Admin Session
 */
export async function verifyAdminSession(sessionId: string) {
  const session = await db
    .select()
    .from(adminSessions)
    .where(eq(adminSessions.sessionId, sessionId))
    .limit(1);

  if (!session.length) return null;

  const adminSession = session[0];

  if (new Date() > adminSession.expiresAt) {
    return null; // Session expired
  }

  return adminSession;
}

/**
 * Log AI Query
 */
export async function logAIQuery(
  adminId: string,
  prompt: string,
  response: string,
  model: string,
  provider: string,
  tokensUsed: number,
  costUSD: number
) {
  await db.insert(aiQueries).values({
    id: crypto.randomUUID(),
    adminId,
    prompt,
    response,
    model,
    provider,
    tokensUsed,
    costUSD,
    createdAt: new Date(),
  });
}

/**
 * Get AI Query History
 */
export async function getAIQueryHistory(adminId: string, limit: number = 50) {
  return await db
    .select()
    .from(aiQueries)
    .where(eq(aiQueries.adminId, adminId))
    .orderBy(desc(aiQueries.createdAt))
    .limit(limit);
}

/**
 * Get Total AI Costs
 */
export async function getTotalAICosts(adminId: string) {
  const result = await db
    .select()
    .from(aiQueries)
    .where(eq(aiQueries.adminId, adminId));

  return result.reduce((sum, query) => sum + query.costUSD, 0);
}

/**
 * Create User
 */
export async function createUser(email: string, name: string) {
  const user = {
    id: crypto.randomUUID(),
    email,
    name,
    createdAt: new Date(),
  };

  await db.insert(users).values(user);
  return user;
}

/**
 * Get User by Email
 */
export async function getUserByEmail(email: string) {
  const result = await db
    .select()
    .from(users)
    .where(eq(users.email, email))
    .limit(1);

  return result[0] || null;
}

/**
 * Initialize Admin User (if not exists)
 */
export async function initializeAdminUser() {
  const existingAdmin = await db
    .select()
    .from(adminUsers)
    .where(eq(adminUsers.username, 'admin'))
    .limit(1);

  if (existingAdmin.length > 0) {
    return existingAdmin[0];
  }

  const passwordHash = crypto.createHash('sha256').update('Kyknet.01').digest('hex');

  const newAdmin = {
    id: crypto.randomUUID(),
    username: 'admin',
    passwordHash,
    email: 'admin@proagrisa.co.za',
    createdAt: new Date(),
  };

  await db.insert(adminUsers).values(newAdmin);
  return newAdmin;
}

export default {
  authenticateAdmin,
  createAdminSession,
  verifyAdminSession,
  logAIQuery,
  getAIQueryHistory,
  getTotalAICosts,
  createUser,
  getUserByEmail,
  initializeAdminUser,
};
