/**
 * tRPC Configuration
 * Base router and middleware setup
 */

import { initTRPC } from '@trpc/server';
import { z } from 'zod';

interface Context {
  adminId?: string;
  sessionId?: string;
}

const t = initTRPC.context<Context>().create();

export const router = t.router;
export const publicProcedure = t.procedure;

/**
 * Protected Procedure - Requires Admin Authentication
 */
export const protectedProcedure = t.procedure.use(async (opts) => {
  const { ctx } = opts;

  if (!ctx.adminId || !ctx.sessionId) {
    throw new Error('Unauthorized: Admin session required');
  }

  return opts.next({
    ctx: {
      ...ctx,
      adminId: ctx.adminId,
      sessionId: ctx.sessionId,
    },
  });
});

/**
 * Admin Router - Base for all admin operations
 */
export const adminRouter = router({
  login: publicProcedure
    .input(z.object({ username: z.string(), password: z.string() }))
    .mutation(async ({ input }) => {
      // Implementation in adminRouter.ts
      return { success: false };
    }),

  logout: protectedProcedure.mutation(async ({ ctx }) => {
    // Implementation in adminRouter.ts
    return { success: true };
  }),

  getProfile: protectedProcedure.query(async ({ ctx }) => {
    // Implementation in adminRouter.ts
    return { adminId: ctx.adminId };
  }),
});

export default t;
