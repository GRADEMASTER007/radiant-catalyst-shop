/**
 * Database Schema
 * Defines all tables and relationships
 */

import { drizzle } from 'drizzle-orm/mysql2';
import {
  mysqlTable,
  varchar,
  text,
  timestamp,
  int,
  decimal,
  boolean,
  enum as mysqlEnum,
} from 'drizzle-orm/mysql-core';

// Initialize database connection
export const db = drizzle(process.env.DATABASE_URL!);

/**
 * Users Table
 */
export const users = mysqlTable('users', {
  id: varchar('id', { length: 36 }).primaryKey(),
  email: varchar('email', { length: 255 }).unique().notNull(),
  name: varchar('name', { length: 255 }).notNull(),
  phone: varchar('phone', { length: 20 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').onUpdateNow(),
});

/**
 * Admin Users Table
 */
export const adminUsers = mysqlTable('admin_users', {
  id: varchar('id', { length: 36 }).primaryKey(),
  username: varchar('username', { length: 255 }).unique().notNull(),
  passwordHash: varchar('password_hash', { length: 255 }).notNull(),
  email: varchar('email', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').onUpdateNow(),
});

/**
 * Admin Sessions Table
 */
export const adminSessions = mysqlTable('admin_sessions', {
  id: varchar('id', { length: 36 }).primaryKey(),
  adminId: varchar('admin_id', { length: 36 }).notNull(),
  sessionId: varchar('session_id', { length: 255 }).unique().notNull(),
  expiresAt: timestamp('expires_at').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

/**
 * AI Queries Table
 */
export const aiQueries = mysqlTable('ai_queries', {
  id: varchar('id', { length: 36 }).primaryKey(),
  adminId: varchar('admin_id', { length: 36 }).notNull(),
  prompt: text('prompt').notNull(),
  response: text('response').notNull(),
  model: varchar('model', { length: 255 }).notNull(),
  provider: varchar('provider', { length: 255 }).notNull(),
  tokensUsed: int('tokens_used').default(0),
  costUSD: decimal('cost_usd', { precision: 10, scale: 4 }).default('0'),
  createdAt: timestamp('created_at').defaultNow(),
});

/**
 * Products Table
 */
export const products = mysqlTable('products', {
  id: varchar('id', { length: 36 }).primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  description: text('description'),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
  priceUSD: decimal('price_usd', { precision: 10, scale: 2 }),
  category: varchar('category', { length: 255 }).notNull(),
  sku: varchar('sku', { length: 255 }).unique(),
  weight: decimal('weight', { precision: 8, scale: 3 }), // kg
  dimensions: varchar('dimensions', { length: 255 }), // L x W x H cm
  stock: int('stock').default(0),
  published: boolean('published').default(false),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').onUpdateNow(),
});

/**
 * Orders Table
 */
export const orders = mysqlTable('orders', {
  id: varchar('id', { length: 36 }).primaryKey(),
  userId: varchar('user_id', { length: 36 }).notNull(),
  status: mysqlEnum('status', ['pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled']).default('pending'),
  totalAmount: decimal('total_amount', { precision: 10, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).default('ZAR'),
  shippingAddress: text('shipping_address').notNull(),
  shippingMethod: varchar('shipping_method', { length: 255 }),
  trackingNumber: varchar('tracking_number', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').onUpdateNow(),
});

/**
 * Order Items Table
 */
export const orderItems = mysqlTable('order_items', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orderId: varchar('order_id', { length: 36 }).notNull(),
  productId: varchar('product_id', { length: 36 }).notNull(),
  quantity: int('quantity').notNull(),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

/**
 * Payments Table
 */
export const payments = mysqlTable('payments', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orderId: varchar('order_id', { length: 36 }).notNull(),
  amount: decimal('amount', { precision: 10, scale: 2 }).notNull(),
  currency: varchar('currency', { length: 3 }).default('ZAR'),
  gateway: mysqlEnum('gateway', ['payfast', 'yoco']).notNull(),
  transactionId: varchar('transaction_id', { length: 255 }).unique(),
  status: mysqlEnum('status', ['pending', 'completed', 'failed', 'refunded']).default('pending'),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').onUpdateNow(),
});

/**
 * Shipping Tracking Table
 */
export const shippingTracking = mysqlTable('shipping_tracking', {
  id: varchar('id', { length: 36 }).primaryKey(),
  orderId: varchar('order_id', { length: 36 }).notNull(),
  provider: mysqlEnum('provider', ['courier-guy', 'pudo']).notNull(),
  trackingNumber: varchar('tracking_number', { length: 255 }).notNull(),
  status: varchar('status', { length: 255 }).default('pending'),
  lastUpdate: timestamp('last_update').defaultNow(),
  createdAt: timestamp('created_at').defaultNow(),
});

/**
 * Email Logs Table
 */
export const emailLogs = mysqlTable('email_logs', {
  id: varchar('id', { length: 36 }).primaryKey(),
  to: varchar('to', { length: 255 }).notNull(),
  subject: varchar('subject', { length: 255 }).notNull(),
  type: varchar('type', { length: 255 }).notNull(), // order, payment, shipping, etc
  status: mysqlEnum('status', ['sent', 'failed', 'bounced']).default('sent'),
  createdAt: timestamp('created_at').defaultNow(),
});

export type User = typeof users.$inferSelect;
export type AdminUser = typeof adminUsers.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Payment = typeof payments.$inferSelect;
