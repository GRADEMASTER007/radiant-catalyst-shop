import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Copy, Zap, Loader2, AlertCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";

const QUICK_PROMPTS = [
  {
    title: "PayFast Integration",
    description: "Generate complete PayFast payment gateway code with webhook handling",
    prompt: "Generate a complete PayFast payment gateway integration for an e-commerce platform. Include: 1) Payment form component, 2) Backend webhook handler, 3) Error handling and logging, 4) Transaction verification, 5) Success/failure callbacks. Use TypeScript and include security best practices.",
  },
  {
    title: "Product Schema",
    description: "Create database schema for e-commerce products with all fields",
    prompt: "Design a comprehensive database schema for an e-commerce product catalog. Include: 1) Product table with all necessary fields, 2) Category relationships, 3) Inventory tracking, 4) Pricing (ZAR/USD), 5) SEO fields, 6) Images and media, 7) Variants and options, 8) Reviews and ratings. Use Drizzle ORM syntax.",
  },
  {
    title: "Email Service",
    description: "Build email service for orders@proagrisa.co.za with templates",
    prompt: "Create a complete email service for orders@proagrisa.co.za. Include: 1) Order confirmation emails, 2) Payment receipts, 3) Shipping notifications, 4) Delivery confirmations, 5) Abandoned cart reminders, 6) HTML email templates, 7) SMTP configuration, 8) Error handling and retry logic.",
  },
  {
    title: "Shipping Calculator",
    description: "Create shipping cost calculator for Courier Guy and PUDO",
    prompt: "Build a shipping cost calculator that integrates with Courier Guy and PUDO. Include: 1) Weight and dimension-based calculations, 2) Zone-based pricing, 3) Real-time API integration, 4) Fallback pricing, 5) Multi-currency support (ZAR/USD), 6) Estimated delivery times, 7) Tracking number generation.",
  },
  {
    title: "Currency Converter",
    description: "Build real-time ZAR to USD converter with caching",
    prompt: "Implement a real-time currency converter for ZAR to USD. Include: 1) Real-time exchange rate API integration, 2) Caching mechanism (5-minute TTL), 3) Fallback rates, 4) Error handling, 5) Conversion history tracking, 6) Admin dashboard for rate monitoring, 7) Automatic daily rate updates.",
  },
  {
    title: "SEO Meta Generator",
    description: "Generate SEO-optimized meta tags for product pages",
    prompt: "Create an AI-powered SEO meta tag generator for product pages. Include: 1) Dynamic meta title generation (50-60 chars), 2) Meta description (150-160 chars), 3) Open Graph tags, 4) Twitter Card tags, 5) Schema.org structured data, 6) Keyword optimization, 7) Readability scoring, 8) Admin interface for customization.",
  },
];

export default function AdminAI() {
  const [selectedService, setSelectedService] = useState("ollama_cloud");
  const [prompt, setPrompt] = useState("");
  const [response, setResponse] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");
  const [stats, setStats] = useState({
    cloudQueries: 0,
    localQueries: 0,
    totalCost: "$0.00",
    avgResponse: "0ms",
  });
  const responseRef = useRef<HTMLDivElement>(null);

  const aiQuery = trpc.ai.query.useMutation();
  const getStats = trpc.ai.getStats.useQuery();

  useEffect(() => {
    if (getStats.data) {
      setStats({
        cloudQueries: getStats.data.queryCount.ollama_cloud,
        localQueries: getStats.data.queryCount.ollama_local,
        totalCost: `$${getStats.data.dailyCost.toFixed(2)}`,
        avgResponse: `${Math.round(getStats.data.avgResponseTime)}ms`,
      });
    }
  }, [getStats.data]);

  const handleSubmit = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt");
      return;
    }

    setIsLoading(true);
    setError("");
    setResponse("");

    try {
      const result = await aiQuery.mutateAsync({
        prompt,
        taskType: detectTaskType(prompt),
        temperature,
      });

      setResponse(result.response);
      setStats((prev) => ({
        ...prev,
        cloudQueries:
          result.service === "ollama_cloud"
            ? prev.cloudQueries + 1
            : prev.cloudQueries,
        localQueries:
          result.service === "ollama_local"
            ? prev.localQueries + 1
            : prev.localQueries,
        totalCost: `$${(parseFloat(prev.totalCost) + result.cost).toFixed(2)}`,
      }));

      // Scroll to response
      setTimeout(() => {
        responseRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to get AI response"
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickPrompt = (quickPrompt: typeof QUICK_PROMPTS[0]) => {
    setPrompt(quickPrompt.prompt);
    setTemperature(0.7);
  };

  const detectTaskType = (text: string) => {
    const lower = text.toLowerCase();
    if (lower.includes("code") || lower.includes("function"))
      return "code";
    if (lower.includes("product") || lower.includes("description"))
      return "content";
    if (lower.includes("seo") || lower.includes("keyword")) return "seo";
    if (lower.includes("image")) return "image";
    return "general";
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(response);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2 mb-8">
          <h1 className="text-4xl font-bold text-purple-900">🤖 AI Development Assistant</h1>
          <p className="text-gray-600">Use AI to build, code, and enhance your e-commerce platform</p>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Input */}
          <div className="lg:col-span-2 space-y-6">
            {/* Service Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Select AI Service
                </CardTitle>
                <CardDescription>Choose which AI service to use</CardDescription>
              </CardHeader>
              <CardContent>
                <Select value={selectedService} onValueChange={setSelectedService}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ollama_cloud">
                      ☁️ Ollama Cloud (Best Quality)
                    </SelectItem>
                    <SelectItem value="ollama_local">
                      ⚡ Ollama Local (Fast & Free)
                    </SelectItem>
                    <SelectItem value="openrouter">
                      🔄 OpenRouter (Complex Tasks)
                    </SelectItem>
                    <SelectItem value="auto">
                      🎯 Auto Select (Smart Routing)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </CardContent>
            </Card>

            {/* Prompt Input */}
            <Card>
              <CardHeader>
                <CardTitle>Your Prompt (Max 1000 words)</CardTitle>
                <CardDescription>
                  Describe what you want the AI to help you with
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value.slice(0, 10000))}
                  placeholder="Example: Generate a payment integration function for PayFast with error handling and webhook support..."
                  className="min-h-64 font-mono text-sm"
                />
                <div className="text-sm text-gray-500">
                  {prompt.length} / 10000 characters
                </div>
              </CardContent>
            </Card>

            {/* Temperature Control */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Creativity Level</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Slider
                    value={[temperature]}
                    onValueChange={(value) => setTemperature(value[0])}
                    min={0}
                    max={1}
                    step={0.1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>Conservative (0.0)</span>
                    <span className="font-bold text-purple-600">{temperature.toFixed(1)}</span>
                    <span>Creative (1.0)</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Controls */}
            <div className="flex gap-3">
              <Button
                onClick={handleSubmit}
                disabled={isLoading || !prompt.trim()}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Zap className="w-4 h-4 mr-2" />
                    Execute AI Task
                  </>
                )}
              </Button>
              <Button
                onClick={() => {
                  setPrompt("");
                  setResponse("");
                  setError("");
                }}
                variant="outline"
              >
                Clear
              </Button>
            </div>

            {/* Error Display */}
            {error && (
              <Card className="border-red-200 bg-red-50">
                <CardContent className="pt-6">
                  <div className="flex gap-3">
                    <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-semibold text-red-900">Error</h3>
                      <p className="text-red-700 text-sm">{error}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Right Column - Stats */}
          <div className="space-y-6">
            {/* Usage Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Usage Statistics (Today)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">
                      {stats.cloudQueries}
                    </div>
                    <div className="text-sm text-gray-600">Cloud Queries</div>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">
                      {stats.localQueries}
                    </div>
                    <div className="text-sm text-gray-600">Local Queries</div>
                  </div>
                  <div className="p-3 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600">
                      {stats.totalCost}
                    </div>
                    <div className="text-sm text-gray-600">Total Cost</div>
                  </div>
                  <div className="p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">
                      {stats.avgResponse}
                    </div>
                    <div className="text-sm text-gray-600">Avg Response Time</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Quick Prompts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Start Prompts</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {QUICK_PROMPTS.map((qp, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickPrompt(qp)}
                    className="w-full text-left p-3 bg-gray-50 hover:bg-purple-50 rounded-lg transition-colors border border-transparent hover:border-purple-200"
                  >
                    <div className="font-semibold text-sm text-purple-600">
                      {qp.title}
                    </div>
                    <div className="text-xs text-gray-600 mt-1">
                      {qp.description}
                    </div>
                  </button>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Response Area */}
        {response && (
          <Card ref={responseRef} className="border-purple-200 bg-purple-50">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>AI Response</CardTitle>
                <CardDescription>Generated content from AI</CardDescription>
              </div>
              <Button
                onClick={copyToClipboard}
                size="sm"
                variant="outline"
              >
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
            </CardHeader>
            <CardContent>
              <div className="bg-white p-6 rounded-lg border border-purple-200 font-mono text-sm whitespace-pre-wrap overflow-auto max-h-96">
                {response}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
