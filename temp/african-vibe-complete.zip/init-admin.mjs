import bcrypt from 'bcrypt';
import mysql from 'mysql2/promise';

const DB_CONFIG = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'ecommerce',
};

async function initializeAdmin() {
  try {
    const connection = await mysql.createConnection(DB_CONFIG);
    
    // Check if admin user exists
    const [existingAdmin] = await connection.execute(
      'SELECT * FROM admin_users WHERE username = ?',
      ['admin']
    );
    
    if (existingAdmin.length > 0) {
      console.log('✅ Admin user already exists');
      await connection.end();
      return;
    }
    
    // Create admin user
    const passwordHash = await bcrypt.hash('Kyknet.01', 10);
    
    await connection.execute(
      'INSERT INTO admin_users (username, passwordHash, email, role, isActive) VALUES (?, ?, ?, ?, ?)',
      ['admin', passwordHash, 'admin@proagrisa.co.za', 'admin', 1]
    );
    
    console.log('✅ Admin user created successfully');
    console.log('Username: admin');
    console.log('Password: Kyknet.01');
    console.log('Email: admin@proagrisa.co.za');
    
    await connection.end();
  } catch (error) {
    console.error('❌ Error initializing admin:', error.message);
    process.exit(1);
  }
}

initializeAdmin();
