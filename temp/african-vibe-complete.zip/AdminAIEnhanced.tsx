import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, Copy, Zap, Clock, DollarSign } from "lucide-react";

interface AIResponse {
  success: boolean;
  content: string;
  model: string;
  service: "ollama_cloud" | "ollama_local" | "openrouter" | "kilo_code";
  cost: number;
  tokensUsed: number;
  executionTime: number;
  error?: string;
}

interface PromptHistory {
  id: string;
  prompt: string;
  response: string;
  model: string;
  timestamp: Date;
  cost: number;
}

const QUICK_PROMPTS = {
  content: [
    {
      title: "Product Description",
      prompt:
        "Generate a compelling product description for: [PRODUCT_NAME]. Include benefits, features, and use cases. Make it SEO-friendly.",
    },
    {
      title: "Blog Post",
      prompt:
        "Write a 1500-word blog post about: [TOPIC]. Include introduction, main points, and conclusion. Use H2 and H3 headings.",
    },
    {
      title: "SEO Meta Tags",
      prompt:
        "Generate SEO meta title and description for: [PAGE_TITLE]. Title max 60 chars, description max 160 chars.",
    },
  ],
  code: [
    {
      title: "Bug Fix",
      prompt:
        "Debug this code and explain the issue:\n\n[PASTE_CODE]\n\nProvide the fixed version.",
    },
    {
      title: "Code Review",
      prompt:
        "Review this code for best practices, performance, and security:\n\n[PASTE_CODE]\n\nProvide specific recommendations.",
    },
    {
      title: "Generate Component",
      prompt:
        "Generate a React component for: [COMPONENT_DESCRIPTION]. Include TypeScript types and proper error handling.",
    },
  ],
  design: [
    {
      title: "Layout Suggestion",
      prompt:
        "Suggest a modern CSS layout for: [DESCRIPTION]. Provide Tailwind CSS classes.",
    },
    {
      title: "Color Palette",
      prompt:
        "Generate a professional color palette for: [BRAND_DESCRIPTION]. Include hex codes and usage suggestions.",
    },
    {
      title: "UI Improvement",
      prompt:
        "Suggest UX improvements for: [CURRENT_UI_DESCRIPTION]. Focus on accessibility and user experience.",
    },
  ],
};

export default function AdminAIEnhanced() {
  const [prompt, setPrompt] = useState("");
  const [selectedModel, setSelectedModel] = useState("auto");
  const [selectedService, setSelectedService] = useState("auto");
  const [temperature, setTemperature] = useState(0.7);
  const [taskType, setTaskType] = useState<
    "content" | "code" | "design" | "analytics" | "search" | "image_analysis"
  >("content");
  const [complexity, setComplexity] = useState<"simple" | "medium" | "complex">(
    "medium"
  );
  const [response, setResponse] = useState<AIResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<PromptHistory[]>([]);
  const [favorites, setFavorites] = useState<PromptHistory[]>([]);
  const [totalCost, setTotalCost] = useState(0);
  const responseRef = useRef<HTMLDivElement>(null);

  const models = {
    auto: "Auto-select",
    nemotron: "NVIDIA Nemotron 3",
    mistral: "Mistral Devstral",
    qwen: "Qwen 3 80B",
    deepseek: "DeepSeek R1",
    llama: "Meta Llama 3.2",
  };

  const services = {
    auto: "Auto-route",
    ollama_cloud: "Ollama Cloud",
    ollama_local: "Ollama Local (Free)",
    openrouter: "OpenRouter",
    kilo_code: "Kilo Code",
  };

  const handleSubmit = async () => {
    if (!prompt.trim()) return;

    setLoading(true);
    try {
      // Call the AI router endpoint
      const res = await fetch("/api/trpc/ai.query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt,
          taskType,
          complexity,
          model: selectedModel === "auto" ? undefined : selectedModel,
          temperature,
        }),
      });

      const data = await res.json();

      if (data.result?.data) {
        const aiResponse = data.result.data as AIResponse;
        setResponse(aiResponse);
        setTotalCost((prev) => prev + aiResponse.cost);

        // Add to history
        const historyItem: PromptHistory = {
          id: Date.now().toString(),
          prompt,
          response: aiResponse.content,
          model: aiResponse.model,
          timestamp: new Date(),
          cost: aiResponse.cost,
        };
        setHistory((prev) => [historyItem, ...prev.slice(0, 49)]);
      }
    } catch (error) {
      console.error("AI query error:", error);
      setResponse({
        success: false,
        content: "Error querying AI service",
        model: "error",
        service: "openrouter",
        cost: 0,
        tokensUsed: 0,
        executionTime: 0,
        error: error instanceof Error ? error.message : "Unknown error",
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    if (response?.content) {
      navigator.clipboard.writeText(response.content);
      alert("Response copied to clipboard!");
    }
  };

  const applyChanges = () => {
    if (response?.content) {
      // This would integrate with the actual page/code editing system
      console.log("Applying changes:", response.content);
      alert("Changes applied! (This is a demo)");
    }
  };

  const addToFavorites = () => {
    if (response) {
      setFavorites((prev) => [
        ...prev,
        {
          id: Date.now().toString(),
          prompt,
          response: response.content,
          model: response.model,
          timestamp: new Date(),
          cost: response.cost,
        },
      ]);
      alert("Added to favorites!");
    }
  };

  const loadFavorite = (favorite: PromptHistory) => {
    setPrompt(favorite.prompt);
    setResponse({
      success: true,
      content: favorite.response,
      model: favorite.model,
      service: "openrouter",
      cost: favorite.cost,
      tokensUsed: 0,
      executionTime: 0,
    });
  };

  const insertQuickPrompt = (quickPrompt: (typeof QUICK_PROMPTS)["content"][0]) => {
    setPrompt((prev) => prev + "\n\n" + quickPrompt.prompt);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">
            🤖 AI Assistant Hub
          </h1>
          <p className="text-slate-300">
            Generate content, code, designs, and more with intelligent AI
            routing
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Input Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Configuration */}
            <Card className="p-6 bg-slate-800 border-slate-700">
              <h2 className="text-xl font-semibold text-white mb-4">
                Configuration
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Task Type
                  </label>
                  <Select value={taskType} onValueChange={setTaskType as any}>
                    <SelectTrigger className="bg-slate-700 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="content">Content</SelectItem>
                      <SelectItem value="code">Code</SelectItem>
                      <SelectItem value="design">Design</SelectItem>
                      <SelectItem value="analytics">Analytics</SelectItem>
                      <SelectItem value="search">Search</SelectItem>
                      <SelectItem value="image_analysis">
                        Image Analysis
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Complexity
                  </label>
                  <Select value={complexity} onValueChange={setComplexity as any}>
                    <SelectTrigger className="bg-slate-700 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="simple">Simple</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="complex">Complex</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Service
                  </label>
                  <Select
                    value={selectedService}
                    onValueChange={setSelectedService}
                  >
                    <SelectTrigger className="bg-slate-700 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(services).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          {value}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-2">
                    Model
                  </label>
                  <Select value={selectedModel} onValueChange={setSelectedModel}>
                    <SelectTrigger className="bg-slate-700 border-slate-600">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(models).map(([key, value]) => (
                        <SelectItem key={key} value={key}>
                          {value}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-4">
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Temperature (Creativity): {temperature.toFixed(1)}
                </label>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(parseFloat(e.target.value))}
                  className="w-full"
                />
              </div>
            </Card>

            {/* Prompt Input */}
            <Card className="p-6 bg-slate-800 border-slate-700">
              <h2 className="text-xl font-semibold text-white mb-4">
                Your Prompt (Max 1000 words)
              </h2>
              <Textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value.slice(0, 5000))}
                placeholder="Enter your prompt here... (up to 1000 words)"
                className="min-h-64 bg-slate-700 border-slate-600 text-white placeholder-slate-400"
              />
              <div className="mt-2 text-sm text-slate-400">
                {prompt.split(" ").length} words
              </div>

              <div className="mt-4 flex gap-2">
                <Button
                  onClick={handleSubmit}
                  disabled={loading || !prompt.trim()}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {loading ? "Processing..." : "🚀 Submit"}
                </Button>
                <Button
                  onClick={addToFavorites}
                  disabled={!response}
                  variant="outline"
                >
                  ⭐ Favorite
                </Button>
              </div>
            </Card>

            {/* Response */}
            {response && (
              <Card className="p-6 bg-slate-800 border-slate-700" ref={responseRef}>
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-semibold text-white">Response</h2>
                  {response.error && (
                    <Badge variant="destructive">
                      <AlertCircle className="w-4 h-4 mr-1" />
                      Error
                    </Badge>
                  )}
                </div>

                {response.error ? (
                  <div className="text-red-400">{response.error}</div>
                ) : (
                  <>
                    <div className="bg-slate-700 p-4 rounded-lg mb-4 max-h-96 overflow-y-auto">
                      <p className="text-slate-100 whitespace-pre-wrap">
                        {response.content}
                      </p>
                    </div>

                    <div className="grid grid-cols-4 gap-4 mb-4 text-sm">
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400">Model</div>
                        <div className="text-white font-semibold">
                          {response.model}
                        </div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          Time
                        </div>
                        <div className="text-white font-semibold">
                          {response.executionTime}ms
                        </div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 flex items-center">
                          <Zap className="w-4 h-4 mr-1" />
                          Tokens
                        </div>
                        <div className="text-white font-semibold">
                          {response.tokensUsed}
                        </div>
                      </div>
                      <div className="bg-slate-700 p-3 rounded">
                        <div className="text-slate-400 flex items-center">
                          <DollarSign className="w-4 h-4 mr-1" />
                          Cost
                        </div>
                        <div className="text-white font-semibold">
                          ${response.cost.toFixed(4)}
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        onClick={copyToClipboard}
                        variant="outline"
                        className="flex-1"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy
                      </Button>
                      <Button
                        onClick={applyChanges}
                        className="flex-1 bg-green-600 hover:bg-green-700"
                      >
                        ✅ Apply Changes
                      </Button>
                    </div>
                  </>
                )}
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Cost Tracking */}
            <Card className="p-6 bg-slate-800 border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <DollarSign className="w-5 h-5 mr-2" />
                Cost Tracking
              </h3>
              <div className="text-3xl font-bold text-green-400 mb-2">
                ${totalCost.toFixed(4)}
              </div>
              <p className="text-slate-400 text-sm">Total spent this session</p>
              <div className="mt-4 p-3 bg-slate-700 rounded text-sm text-slate-300">
                Budget: $100/month
              </div>
            </Card>

            {/* Quick Prompts */}
            <Card className="p-6 bg-slate-800 border-slate-700">
              <h3 className="text-lg font-semibold text-white mb-4">
                Quick Prompts
              </h3>
              <Tabs defaultValue="content" className="w-full">
                <TabsList className="grid w-full grid-cols-3 bg-slate-700">
                  <TabsTrigger value="content">Content</TabsTrigger>
                  <TabsTrigger value="code">Code</TabsTrigger>
                  <TabsTrigger value="design">Design</TabsTrigger>
                </TabsList>

                {Object.entries(QUICK_PROMPTS).map(([key, prompts]) => (
                  <TabsContent key={key} value={key} className="space-y-2">
                    {prompts.map((p, idx) => (
                      <Button
                        key={idx}
                        onClick={() => insertQuickPrompt(p)}
                        variant="outline"
                        className="w-full justify-start text-left h-auto py-2"
                      >
                        <span className="text-sm">{p.title}</span>
                      </Button>
                    ))}
                  </TabsContent>
                ))}
              </Tabs>
            </Card>

            {/* Favorites */}
            {favorites.length > 0 && (
              <Card className="p-6 bg-slate-800 border-slate-700">
                <h3 className="text-lg font-semibold text-white mb-4">
                  ⭐ Favorites
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {favorites.map((fav) => (
                    <Button
                      key={fav.id}
                      onClick={() => loadFavorite(fav)}
                      variant="outline"
                      className="w-full justify-start text-left h-auto py-2 text-xs"
                    >
                      <span className="truncate">{fav.prompt.slice(0, 50)}</span>
                    </Button>
                  ))}
                </div>
              </Card>
            )}

            {/* History */}
            {history.length > 0 && (
              <Card className="p-6 bg-slate-800 border-slate-700">
                <h3 className="text-lg font-semibold text-white mb-4">
                  📜 History
                </h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {history.map((item) => (
                    <Button
                      key={item.id}
                      onClick={() => loadFavorite(item)}
                      variant="outline"
                      className="w-full justify-start text-left h-auto py-2 text-xs"
                    >
                      <span className="truncate">{item.prompt.slice(0, 50)}</span>
                    </Button>
                  ))}
                </div>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
