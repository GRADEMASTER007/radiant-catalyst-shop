import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

// ============================================
// ADMIN USER OPERATIONS
// ============================================

export async function createAdminUser(username: string, password: string, email: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const bcrypt = require('bcrypt');
  const passwordHash = await bcrypt.hash(password, 10);
  const { adminUsers } = await import('../drizzle/schema');
  
  const result = await db.insert(adminUsers).values({
    username,
    passwordHash,
    email,
    role: "admin",
    isActive: true,
  });
  return result;
}

export async function getAdminUserByUsername(username: string) {
  const db = await getDb();
  if (!db) return null;
  
  const { adminUsers } = await import('../drizzle/schema');
  const user = await db.select().from(adminUsers).where(eq(adminUsers.username, username)).limit(1);
  return user.length > 0 ? user[0] : null;
}

export async function verifyAdminPassword(username: string, password: string) {
  const user = await getAdminUserByUsername(username);
  if (!user) return null;
  
  const bcrypt = require('bcrypt');
  const isValid = await bcrypt.compare(password, user.passwordHash);
  if (!isValid) return null;
  
  return user;
}

export async function createAdminSession(adminUserId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const { adminSessions } = await import('../drizzle/schema');
  const { nanoid } = require('nanoid');
  
  const sessionToken = nanoid(32);
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
  
  const result = await db.insert(adminSessions).values({
    adminUserId,
    sessionToken,
    expiresAt,
  });
  
  return { sessionToken, expiresAt };
}

export async function getAdminSessionByToken(sessionToken: string) {
  const db = await getDb();
  if (!db) return null;
  
  const { adminSessions } = await import('../drizzle/schema');
  const sessions = await db.select().from(adminSessions).where(eq(adminSessions.sessionToken, sessionToken)).limit(1);
  
  if (sessions.length === 0) return null;
  
  const session = sessions[0];
  if (session.expiresAt < new Date()) {
    return null;
  }
  
  return session;
}

export async function deleteAdminSession(sessionToken: string) {
  const db = await getDb();
  if (!db) return;
  
  const { adminSessions } = await import('../drizzle/schema');
  await db.delete(adminSessions).where(eq(adminSessions.sessionToken, sessionToken));
}
