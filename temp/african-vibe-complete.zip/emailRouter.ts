/**
 * Email tRPC Router
 * Exposes email service for order notifications and communications
 */

import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { emailService } from "./services/email";

export const emailRouter = router({
  /**
   * Send order confirmation email
   */
  sendOrderConfirmation: publicProcedure
    .input(
      z.object({
        customerEmail: z.string().email(),
        customerName: z.string(),
        orderId: z.string(),
        orderTotal: z.number(),
        items: z.array(
          z.object({
            name: z.string(),
            quantity: z.number(),
            price: z.number(),
          })
        ),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await emailService.sendOrderConfirmation(
          input.customerEmail,
          input.customerName,
          input.orderId,
          input.orderTotal,
          input.items
        );
        return result;
      } catch (error) {
        console.error("Order confirmation email error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Email sending failed",
        };
      }
    }),

  /**
   * Send payment receipt email
   */
  sendPaymentReceipt: publicProcedure
    .input(
      z.object({
        customerEmail: z.string().email(),
        customerName: z.string(),
        orderId: z.string(),
        amount: z.number(),
        paymentMethod: z.string(),
        transactionId: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await emailService.sendPaymentReceipt(
          input.customerEmail,
          input.customerName,
          input.orderId,
          input.amount,
          input.paymentMethod,
          input.transactionId
        );
        return result;
      } catch (error) {
        console.error("Payment receipt email error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Email sending failed",
        };
      }
    }),

  /**
   * Send shipping notification email
   */
  sendShippingNotification: publicProcedure
    .input(
      z.object({
        customerEmail: z.string().email(),
        customerName: z.string(),
        orderId: z.string(),
        trackingNumber: z.string(),
        carrier: z.string(),
        estimatedDelivery: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await emailService.sendShippingNotification(
          input.customerEmail,
          input.customerName,
          input.orderId,
          input.trackingNumber,
          input.carrier,
          input.estimatedDelivery
        );
        return result;
      } catch (error) {
        console.error("Shipping notification email error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Email sending failed",
        };
      }
    }),

  /**
   * Send delivery confirmation email
   */
  sendDeliveryConfirmation: publicProcedure
    .input(
      z.object({
        customerEmail: z.string().email(),
        customerName: z.string(),
        orderId: z.string(),
        trackingNumber: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await emailService.sendDeliveryConfirmation(
          input.customerEmail,
          input.customerName,
          input.orderId,
          input.trackingNumber
        );
        return result;
      } catch (error) {
        console.error("Delivery confirmation email error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Email sending failed",
        };
      }
    }),

  /**
   * Send contact form response email
   */
  sendContactFormResponse: publicProcedure
    .input(
      z.object({
        customerEmail: z.string().email(),
        customerName: z.string(),
        message: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const result = await emailService.sendContactFormResponse(
          input.customerEmail,
          input.customerName,
          input.message
        );
        return result;
      } catch (error) {
        console.error("Contact form response email error:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Email sending failed",
        };
      }
    }),

  /**
   * Test email connection
   */
  testConnection: publicProcedure.query(async () => {
    try {
      const result = await emailService.testConnection();
      return result;
    } catch (error) {
      console.error("Email connection test error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Connection test failed",
      };
    }
  }),
});
