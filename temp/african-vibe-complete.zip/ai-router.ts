/**
 * AI Router Service
 * Intelligently routes requests to the best AI service based on:
 * - Task type and complexity
 * - Cost optimization
 * - Response time requirements
 * - Daily budget constraints
 */

import { AI_CONFIG } from "../config/ai-config";

interface AIRequest {
  prompt: string;
  taskType?: "general" | "code" | "content" | "seo" | "image" | "debug";
  complexity?: "low" | "medium" | "high";
  urgency?: "low" | "normal" | "high";
  maxCost?: number | null;
  preferredModel?: string | null;
  temperature?: number;
}

interface AIResponse {
  success: boolean;
  service: string;
  response: string;
  cost: number;
  tokensUsed: number;
  responseTime: number;
  model: string;
}

class AIRouter {
  private dailyCost: number = 0;
  private queryCount: Record<string, number> = {
    ollama_cloud: 0,
    ollama_local: 0,
    openrouter: 0,
    kilocode: 0,
  };
  private responseTimes: number[] = [];

  constructor() {
    this.resetDailyTracking();
  }

  /**
   * Main routing function - intelligently selects best AI service
   */
  async query(request: AIRequest): Promise<AIResponse> {
    const {
      prompt,
      taskType = "general",
      complexity = "medium",
      urgency = "normal",
      maxCost = null,
      preferredModel = null,
      temperature = 0.7,
    } = request;

    // Determine best AI service
    const service = this.selectService(taskType, complexity, urgency, maxCost);

    try {
      const startTime = Date.now();
      const response = await this.sendRequest(
        service,
        prompt,
        preferredModel,
        temperature
      );
      const responseTime = Date.now() - startTime;

      this.trackUsage(service, response, responseTime);

      return {
        success: true,
        service,
        response: response.content,
        cost: response.cost,
        tokensUsed: response.tokensUsed,
        responseTime,
        model: response.model,
      };
    } catch (error) {
      console.error(`AI Service ${service} failed:`, error);
      return this.fallbackRequest(prompt, service, request);
    }
  }

  /**
   * Intelligently select the best AI service based on criteria
   */
  private selectService(
    taskType: string,
    complexity: string,
    urgency: string,
    maxCost: number | null
  ): string {
    // If over budget, use local
    if (this.dailyCost >= AI_CONFIG.routing.dailyBudget) {
      console.log("⚠️ Daily budget reached, using local AI");
      return "ollama_local";
    }

    // High urgency + low complexity = local (fast)
    if (urgency === "high" && complexity === "low") {
      return "ollama_local";
    }

    // High complexity = cloud (quality)
    if (complexity === "high") {
      return "ollama_cloud";
    }

    // Code generation = OpenRouter (best for coding)
    if (taskType === "code") {
      return "openrouter";
    }

    // Cost-sensitive = local
    if (maxCost === 0) {
      return "ollama_local";
    }

    // Default to cloud for production quality
    return "ollama_cloud";
  }

  /**
   * Send request to AI service
   */
  private async sendRequest(
    service: string,
    prompt: string,
    preferredModel: string | null,
    temperature: number
  ): Promise<{
    content: string;
    cost: number;
    tokensUsed: number;
    model: string;
  }> {
    const config = AI_CONFIG[service as keyof typeof AI_CONFIG];
    if (!config) {
      throw new Error(`Unknown AI service: ${service}`);
    }

    const model = preferredModel || this.getDefaultModel(service, prompt);

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
    };

    if (config.apiKey) {
      headers["Authorization"] = `Bearer ${config.apiKey}`;
    }

    const body = JSON.stringify({
      model,
      messages: [{ role: "user", content: prompt }],
      stream: false,
      temperature,
    });

    const response = await fetch(`${config.baseURL}/chat/completions`, {
      method: "POST",
      headers,
      body,
      signal: AbortSignal.timeout(config.timeout),
    });

    if (!response.ok) {
      throw new Error(
        `HTTP ${response.status}: ${response.statusText} from ${service}`
      );
    }

    const data = await response.json();

    // Extract response content
    const content =
      data.choices?.[0]?.message?.content ||
      data.message?.content ||
      JSON.stringify(data);

    // Calculate cost
    const tokensUsed = data.usage?.total_tokens || 1000;
    const cost =
      service === "ollama_local"
        ? 0
        : (tokensUsed / 1000) * AI_CONFIG.routing.costPerCloudQuery;

    return {
      content,
      cost,
      tokensUsed,
      model,
    };
  }

  /**
   * Fallback to next available AI service
   */
  private async fallbackRequest(
    prompt: string,
    failedService: string,
    request: AIRequest
  ): Promise<AIResponse> {
    const fallbackChain = AI_CONFIG.routing.priorityOrder.filter(
      (s) => s !== failedService
    );

    for (const service of fallbackChain) {
      try {
        console.log(`Falling back to ${service}...`);
        const response = await this.sendRequest(
          service,
          prompt,
          request.preferredModel || null,
          request.temperature || 0.7
        );
        this.trackUsage(service, response, 0, true);

        return {
          success: true,
          service,
          response: response.content,
          cost: response.cost,
          tokensUsed: response.tokensUsed,
          responseTime: 0,
          model: response.model,
        };
      } catch (error) {
        console.error(`Fallback ${service} also failed:`, error);
        continue;
      }
    }

    throw new Error("All AI services failed");
  }

  /**
   * Select default model based on prompt content
   */
  private getDefaultModel(service: string, prompt: string): string {
    const lower = prompt.toLowerCase();
    const config = AI_CONFIG[service as keyof typeof AI_CONFIG];

    if (!config || !("models" in config)) {
      return "default";
    }

    if (
      lower.includes("code") ||
      lower.includes("debug") ||
      lower.includes("function")
    ) {
      return config.models.code_generation || "default";
    }

    if (
      lower.includes("product") ||
      lower.includes("description") ||
      lower.includes("content")
    ) {
      return config.models.content_generation || "default";
    }

    if (lower.includes("seo") || lower.includes("keyword")) {
      return config.models.seo_optimization || "default";
    }

    if (lower.includes("image") || lower.includes("vision")) {
      return config.models.image_analysis || "default";
    }

    // Return first available model
    const models = Object.values(config.models);
    return models[0] || "default";
  }

  /**
   * Track usage for cost and performance monitoring
   */
  private trackUsage(
    service: string,
    response: { cost: number; tokensUsed: number },
    responseTime: number,
    isFallback: boolean = false
  ): void {
    this.queryCount[service]++;
    this.dailyCost += response.cost;
    this.responseTimes.push(responseTime);

    const avgTime =
      this.responseTimes.reduce((a, b) => a + b, 0) /
      this.responseTimes.length;

    console.log(
      `📊 AI Usage - Service: ${service}, Cost: $${this.dailyCost.toFixed(4)}, Queries: ${JSON.stringify(this.queryCount)}, Avg Response: ${Math.round(avgTime)}ms`
    );

    // Warn if approaching budget
    if (
      this.dailyCost >=
      AI_CONFIG.routing.dailyBudget * 0.8
    ) {
      console.warn(
        `⚠️ WARNING: 80% of daily AI budget used ($${this.dailyCost.toFixed(2)} / $${AI_CONFIG.routing.dailyBudget})`
      );
    }
  }

  /**
   * Reset daily tracking every 24 hours
   */
  private resetDailyTracking(): void {
    setInterval(() => {
      this.dailyCost = 0;
      this.queryCount = {
        ollama_cloud: 0,
        ollama_local: 0,
        openrouter: 0,
        kilocode: 0,
      };
      this.responseTimes = [];
      console.log("🔄 Daily AI usage tracking reset");
    }, 24 * 60 * 60 * 1000); // Every 24 hours
  }

  /**
   * Get current stats
   */
  getStats() {
    return {
      dailyCost: this.dailyCost,
      queryCount: this.queryCount,
      avgResponseTime:
        this.responseTimes.length > 0
          ? this.responseTimes.reduce((a, b) => a + b, 0) /
            this.responseTimes.length
          : 0,
      totalQueries: Object.values(this.queryCount).reduce((a, b) => a + b, 0),
    };
  }
}

export const aiRouter = new AIRouter();
