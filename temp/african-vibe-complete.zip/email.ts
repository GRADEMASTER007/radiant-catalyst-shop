/**
 * Email Service
 * Real SMTP integration with mail.proagrisa.co.za
 * NO MOCKS - PRODUCTION READY
 */

import nodemailer from "nodemailer";
import { CREDENTIALS } from "../config/credentials";

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
  attachments?: Array<{
    filename: string;
    content: Buffer | string;
    contentType?: string;
  }>;
}

class EmailService {
  private transporter: nodemailer.Transporter;
  private fromEmail: string;
  private fromName: string;

  constructor() {
    this.fromEmail = CREDENTIALS.email.fromEmail;
    this.fromName = CREDENTIALS.email.fromName;

    // Initialize SMTP transporter
    this.transporter = nodemailer.createTransport({
      host: CREDENTIALS.email.smtpHost,
      port: CREDENTIALS.email.smtpPort,
      secure: CREDENTIALS.email.secure,
      auth: {
        user: CREDENTIALS.email.smtpUser,
        pass: CREDENTIALS.email.smtpPassword,
      },
      tls: {
        rejectUnauthorized: CREDENTIALS.email.rejectUnauthorized,
      },
    });
  }

  /**
   * Send email
   */
  async sendEmail(options: EmailOptions): Promise<{
    success: boolean;
    messageId?: string;
    error?: string;
  }> {
    try {
      const info = await this.transporter.sendMail({
        from: `${this.fromName} <${this.fromEmail}>`,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text,
        attachments: options.attachments,
      });

      console.log(`Email sent to ${options.to}: ${info.messageId}`);

      return {
        success: true,
        messageId: info.messageId,
      };
    } catch (error) {
      console.error("Email sending error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Email sending failed",
      };
    }
  }

  /**
   * Send order confirmation email
   */
  async sendOrderConfirmation(
    customerEmail: string,
    customerName: string,
    orderId: string,
    orderTotal: number,
    items: Array<{ name: string; quantity: number; price: number }>
  ): Promise<{ success: boolean; error?: string }> {
    const itemsHtml = items
      .map(
        (item) =>
          `<tr>
        <td>${item.name}</td>
        <td>${item.quantity}</td>
        <td>R${item.price.toFixed(2)}</td>
        <td>R${(item.quantity * item.price).toFixed(2)}</td>
      </tr>`
      )
      .join("");

    const html = `
      <h2>Order Confirmation</h2>
      <p>Hi ${customerName},</p>
      <p>Thank you for your order! Here are the details:</p>
      
      <p><strong>Order ID:</strong> ${orderId}</p>
      
      <table border="1" cellpadding="10" cellspacing="0">
        <tr>
          <th>Product</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Total</th>
        </tr>
        ${itemsHtml}
      </table>
      
      <p><strong>Order Total: R${orderTotal.toFixed(2)}</strong></p>
      
      <p>You will receive a shipping notification once your order is dispatched.</p>
      
      <p>For any questions, contact us at ${CREDENTIALS.business.email}</p>
      <p>WhatsApp: ${CREDENTIALS.business.whatsapp1}</p>
      
      <p>Best regards,<br>${CREDENTIALS.business.name}</p>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: `Order Confirmation - ${orderId}`,
      html,
    });
  }

  /**
   * Send payment receipt email
   */
  async sendPaymentReceipt(
    customerEmail: string,
    customerName: string,
    orderId: string,
    amount: number,
    paymentMethod: string,
    transactionId: string
  ): Promise<{ success: boolean; error?: string }> {
    const html = `
      <h2>Payment Receipt</h2>
      <p>Hi ${customerName},</p>
      <p>Your payment has been received successfully.</p>
      
      <p><strong>Order ID:</strong> ${orderId}</p>
      <p><strong>Amount Paid:</strong> R${amount.toFixed(2)}</p>
      <p><strong>Payment Method:</strong> ${paymentMethod}</p>
      <p><strong>Transaction ID:</strong> ${transactionId}</p>
      <p><strong>Date:</strong> ${new Date().toLocaleDateString()}</p>
      
      <p>Your order will be processed and shipped shortly.</p>
      
      <p>For any questions, contact us at ${CREDENTIALS.business.email}</p>
      
      <p>Best regards,<br>${CREDENTIALS.business.name}</p>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: `Payment Receipt - ${orderId}`,
      html,
    });
  }

  /**
   * Send shipping notification
   */
  async sendShippingNotification(
    customerEmail: string,
    customerName: string,
    orderId: string,
    trackingNumber: string,
    carrier: string,
    estimatedDelivery: string
  ): Promise<{ success: boolean; error?: string }> {
    const html = `
      <h2>Your Order Has Been Shipped!</h2>
      <p>Hi ${customerName},</p>
      <p>Great news! Your order has been dispatched.</p>
      
      <p><strong>Order ID:</strong> ${orderId}</p>
      <p><strong>Tracking Number:</strong> ${trackingNumber}</p>
      <p><strong>Carrier:</strong> ${carrier}</p>
      <p><strong>Estimated Delivery:</strong> ${estimatedDelivery}</p>
      
      <p>You can track your shipment using the tracking number above on the ${carrier} website.</p>
      
      <p>For any questions, contact us at ${CREDENTIALS.business.email}</p>
      <p>WhatsApp: ${CREDENTIALS.business.whatsapp1}</p>
      
      <p>Best regards,<br>${CREDENTIALS.business.name}</p>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: `Shipping Notification - Order ${orderId}`,
      html,
    });
  }

  /**
   * Send delivery confirmation
   */
  async sendDeliveryConfirmation(
    customerEmail: string,
    customerName: string,
    orderId: string,
    trackingNumber: string
  ): Promise<{ success: boolean; error?: string }> {
    const html = `
      <h2>Your Order Has Been Delivered!</h2>
      <p>Hi ${customerName},</p>
      <p>Your order has been successfully delivered.</p>
      
      <p><strong>Order ID:</strong> ${orderId}</p>
      <p><strong>Tracking Number:</strong> ${trackingNumber}</p>
      <p><strong>Delivery Date:</strong> ${new Date().toLocaleDateString()}</p>
      
      <p>We hope you're satisfied with your purchase. If you have any issues or questions, please don't hesitate to contact us.</p>
      
      <p>Contact us at ${CREDENTIALS.business.email}</p>
      <p>WhatsApp: ${CREDENTIALS.business.whatsapp1}</p>
      
      <p>Best regards,<br>${CREDENTIALS.business.name}</p>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: `Delivery Confirmation - Order ${orderId}`,
      html,
    });
  }

  /**
   * Send contact form response
   */
  async sendContactFormResponse(
    customerEmail: string,
    customerName: string,
    message: string
  ): Promise<{ success: boolean; error?: string }> {
    const html = `
      <h2>We Received Your Message</h2>
      <p>Hi ${customerName},</p>
      <p>Thank you for contacting us. We have received your message and will get back to you shortly.</p>
      
      <p><strong>Your Message:</strong></p>
      <p>${message.replace(/\n/g, "<br>")}</p>
      
      <p>In the meantime, if you have any urgent questions, feel free to call us:</p>
      <p>Phone: ${CREDENTIALS.business.phone}</p>
      <p>WhatsApp: ${CREDENTIALS.business.whatsapp1}</p>
      
      <p>Best regards,<br>${CREDENTIALS.business.name}</p>
    `;

    return this.sendEmail({
      to: customerEmail,
      subject: "We Received Your Message",
      html,
    });
  }

  /**
   * Test email connection
   */
  async testConnection(): Promise<{ success: boolean; error?: string }> {
    try {
      await this.transporter.verify();
      console.log("✅ Email service connected successfully");
      return { success: true };
    } catch (error) {
      console.error("❌ Email service connection failed:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Connection failed",
      };
    }
  }
}

export const emailService = new EmailService();
