import { useState, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
// Toast notifications handled via state
import { Key, Bot, Loader2, CheckCircle, AlertCircle, Send, Sparkles } from "lucide-react";

interface ApiKey {
  id: number;
  name: string;
  provider: string;
  isActive: boolean;
}

interface ModelConfig {
  taskType: string;
  modelId: string;
  modelName: string;
  apiKeyId?: number;
  isDefault: boolean;
}

const TASK_TYPES = [
  { value: "image_generation", label: "Image Generation", description: "Generate product images and visuals", icon: Sparkles },
  { value: "content_creation", label: "Content Creation", description: "Write descriptions, blogs, and pages", icon: Bot },
  { value: "page_creation", label: "Page Creation", description: "Generate dynamic page content", icon: Bot },
  { value: "chat", label: "Chat & Assistance", description: "AI chat for app support and fixes", icon: Bot },
  { value: "seo", label: "SEO Optimization", description: "Generate SEO metadata and keywords", icon: Bot },
  { value: "description", label: "Product Descriptions", description: "Auto-generate product descriptions", icon: Bot },
];

export default function AIConfiguration() {
  // Toast notifications via state
  const [activeTab, setActiveTab] = useState("api-keys");
  const [newApiKey, setNewApiKey] = useState({ name: "", apiKey: "" });
  const [modelConfigs, setModelConfigs] = useState<Record<string, { modelId: string; customModel: string; apiKeyId: string }>>({});
  const [showApiKeys, setShowApiKeys] = useState<Record<number, boolean>>({});
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiResponse, setAiResponse] = useState("");
  const [availableModels, setAvailableModels] = useState<string[]>([]);
  const [loadingModels, setLoadingModels] = useState(false);

  // Queries
  const { data: apiKeys } = trpc.apiKeys.list.useQuery();
  const { data: existingModelConfigs } = trpc.aiModels.configs.useQuery();

  // Mutations
  const createApiKeyMutation = trpc.apiKeys.create.useMutation({
    onSuccess: () => {
      setNewApiKey({ name: "", apiKey: "" });
      toast.success("API key added successfully");
    },
    onError: (error: { message: string }) => toast.error(error.message),
  });

  const saveModelConfigMutation = trpc.aiModels.setConfig.useMutation({
    onSuccess: () => {
      toast.success("Model configuration saved");
    },
    onError: (error: { message: string }) => toast.error(error.message),
  });

  const aiAssistanceMutation = trpc.ai.assist.useMutation({
    onSuccess: (response) => {
      setAiResponse(response.content || "");
      toast.success("AI response received");
    },
    onError: (error: { message: string }) => toast.error(error.message),
  });

  // Initialize model configs
  useEffect(() => {
    if (existingModelConfigs) {
      const configs: Record<string, { modelId: string; customModel: string; apiKeyId: string }> = {};
      existingModelConfigs.forEach((config: ModelConfig) => {
        configs[config.taskType] = {
          modelId: config.modelId,
          customModel: config.modelId,
          apiKeyId: config.apiKeyId ? String(config.apiKeyId) : "",
        };
      });
      setModelConfigs(configs);
    }
  }, [existingModelConfigs]);

  // Fetch available models from OpenRouter
  const fetchAvailableModels = async (apiKeyId: string) => {
    if (!apiKeyId) {
      toast.error("Please select an API key first");
      return;
    }

    setLoadingModels(true);
    try {
      const response = await fetch("https://openrouter.ai/api/v1/models", {
        headers: {
          "Authorization": `Bearer ${apiKeys?.find((k: ApiKey) => String(k.id) === apiKeyId)?.provider}`,
        },
      });

      if (!response.ok) throw new Error("Failed to fetch models");

      const data = await response.json();
      const modelIds = data.data.map((m: { id: string }) => m.id).slice(0, 50); // Top 50 models
      setAvailableModels(modelIds);
      toast.success(`Loaded ${modelIds.length} available models`);
    } catch (error) {
      console.error("Error fetching models:", error);
      toast.error("Failed to fetch available models");
    } finally {
      setLoadingModels(false);
    }
  };

  const handleAddApiKey = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newApiKey.name || !newApiKey.apiKey) {
      toast.error("Please fill in all fields");
      return;
    }
    createApiKeyMutation.mutate({
      name: newApiKey.name,
      apiKey: newApiKey.apiKey,
      provider: "openrouter",
    });
  };

  const handleSaveModelConfig = (taskType: string) => {
    const config = modelConfigs[taskType];
    const modelId = config?.customModel || config?.modelId;

    if (!modelId) {
      toast.error("Please enter or select a model");
      return;
    }

    saveModelConfigMutation.mutate({
      taskType: taskType as any,
      modelId,
      modelName: modelId.split("/").pop() || modelId,
      apiKeyId: config.apiKeyId ? parseInt(config.apiKeyId) : undefined,
      isDefault: true,
    });
  };

  const handleAiAssistance = async () => {
    if (!aiPrompt.trim()) {
      toast.error("Please enter a prompt");
      return;
    }

    // Find the chat model config
    const chatConfig = modelConfigs["chat"];
    if (!chatConfig?.modelId && !chatConfig?.customModel) {
      toast.error("Please configure a chat model first");
      return;
    }

    const modelId = chatConfig.customModel || chatConfig.modelId;
    const apiKeyId = chatConfig.apiKeyId ? parseInt(chatConfig.apiKeyId) : undefined;

    aiAssistanceMutation.mutate({
      prompt: aiPrompt,
      modelId,
      apiKeyId,
    });
  };

  const maskApiKey = (key: string) => {
    if (key.length <= 12) return "••••••••";
    return key.substring(0, 8) + "••••••••" + key.slice(-4);
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-foreground">AI Configuration</h1>
        <p className="text-muted-foreground mt-1">Manage OpenRouter API keys, custom models, and AI assistance</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-2xl grid-cols-3">
          <TabsTrigger value="api-keys" className="flex items-center gap-2">
            <Key className="w-4 h-4" />
            API Keys
          </TabsTrigger>
          <TabsTrigger value="models" className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            Models
          </TabsTrigger>
          <TabsTrigger value="assistance" className="flex items-center gap-2">
            <Sparkles className="w-4 h-4" />
            AI Assistance
          </TabsTrigger>
        </TabsList>

        {/* API Keys Tab */}
        <TabsContent value="api-keys" className="space-y-6 mt-6">
          <Card className="border-0 shadow-soft">
            <CardHeader>
              <CardTitle className="font-display text-lg">Add OpenRouter API Key</CardTitle>
              <CardDescription>
                Add API keys from your OpenRouter account. Get your API key at{" "}
                <a href="https://openrouter.ai/keys" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                  openrouter.ai/keys
                </a>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleAddApiKey} className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="keyName">Key Name</Label>
                    <Input
                      id="keyName"
                      placeholder="e.g., Production Key"
                      value={newApiKey.name}
                      onChange={(e) => setNewApiKey({ ...newApiKey, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="apiKey">API Key</Label>
                    <Input
                      id="apiKey"
                      type="password"
                      placeholder="sk-or-..."
                      value={newApiKey.apiKey}
                      onChange={(e) => setNewApiKey({ ...newApiKey, apiKey: e.target.value })}
                    />
                  </div>
                </div>
                <Button type="submit" disabled={createApiKeyMutation.isPending}>
                  {createApiKeyMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Add API Key
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Existing API Keys */}
          {apiKeys && apiKeys.length > 0 && (
            <Card className="border-0 shadow-soft">
              <CardHeader>
                <CardTitle className="font-display text-lg">Your API Keys</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {apiKeys.map((key: ApiKey) => (
                    <div key={key.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium">{key.name}</p>
                        <p className="text-sm text-muted-foreground">{maskApiKey(key.provider)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {key.isActive && <CheckCircle className="w-4 h-4 text-tropical-green" />}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* Models Tab */}
        <TabsContent value="models" className="space-y-6 mt-6">
          {TASK_TYPES.map((task) => {
            const config = modelConfigs[task.value] || { modelId: "", customModel: "", apiKeyId: "" };

            return (
              <Card key={task.value} className="border-0 shadow-soft">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <task.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="font-display text-lg">{task.label}</CardTitle>
                      <CardDescription>{task.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid sm:grid-cols-3 gap-4">
                    <div>
                      <Label>API Key</Label>
                      <Select
                        value={config.apiKeyId}
                        onValueChange={(value) => {
                          setModelConfigs((prev) => ({
                            ...prev,
                            [task.value]: { ...prev[task.value], apiKeyId: value },
                          }));
                        }}
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select API key" />
                        </SelectTrigger>
                        <SelectContent>
                          {apiKeys?.filter((k: ApiKey) => k.isActive).map((key: ApiKey) => (
                            <SelectItem key={key.id} value={String(key.id)}>
                              {key.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Model ID or Custom Model</Label>
                      <Input
                        placeholder="e.g., mistralai/mistral-7b or deepseek/deepseek-coder"
                        value={config.customModel}
                        onChange={(e) =>
                          setModelConfigs((prev) => ({
                            ...prev,
                            [task.value]: { ...prev[task.value], customModel: e.target.value },
                          }))
                        }
                      />
                      <p className="text-xs text-muted-foreground mt-1">
                        Paste any OpenRouter model ID (e.g., mistralai/mistral-large, deepseek/deepseek-coder-33b)
                      </p>
                    </div>

                    <div className="flex items-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => fetchAvailableModels(config.apiKeyId)}
                        disabled={loadingModels || !config.apiKeyId}
                      >
                        {loadingModels ? <Loader2 className="w-4 h-4 animate-spin" /> : "Browse Models"}
                      </Button>
                      <Button
                        onClick={() => handleSaveModelConfig(task.value)}
                        disabled={saveModelConfigMutation.isPending || !config.customModel}
                      >
                        Save
                      </Button>
                    </div>
                  </div>

                  {availableModels.length > 0 && (
                    <div className="mt-4 p-3 bg-muted rounded-lg max-h-40 overflow-y-auto">
                      <p className="text-sm font-medium mb-2">Available Models:</p>
                      <div className="space-y-1">
                        {availableModels.slice(0, 10).map((model) => (
                          <button
                            key={model}
                            onClick={() =>
                              setModelConfigs((prev) => ({
                                ...prev,
                                [task.value]: { ...prev[task.value], customModel: model },
                              }))
                            }
                            className="text-xs text-primary hover:underline block text-left"
                          >
                            {model}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </TabsContent>

        {/* AI Assistance Tab */}
        <TabsContent value="assistance" className="space-y-6 mt-6">
          <Card className="border-0 shadow-soft">
            <CardHeader>
              <CardTitle className="font-display text-lg">AI Assistance</CardTitle>
              <CardDescription>
                Ask AI for help with fixing issues, adding features, or generating code for your app
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="aiPrompt">Your Question or Request</Label>
                <Textarea
                  id="aiPrompt"
                  placeholder="e.g., 'Fix the error on the products page' or 'Add a new feature to show customer reviews' or 'Generate code to integrate Stripe payments'"
                  value={aiPrompt}
                  onChange={(e) => setAiPrompt(e.target.value)}
                  rows={5}
                  className="mt-2"
                />
              </div>

              <Button
                onClick={handleAiAssistance}
                disabled={aiAssistanceMutation.isPending || !aiPrompt.trim()}
                className="w-full"
              >
                {aiAssistanceMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : (
                  <Send className="w-4 h-4 mr-2" />
                )}
                Get AI Assistance
              </Button>

              {aiResponse && (
                <div className="p-4 bg-muted rounded-lg border border-border">
                  <div className="flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-primary" />
                    <p className="font-medium">AI Response:</p>
                  </div>
                  <div className="prose prose-sm max-w-none text-foreground whitespace-pre-wrap">
                    {aiResponse}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      navigator.clipboard.writeText(aiResponse);
                      toast.success("Response copied to clipboard");
                    }}
                    className="mt-3"
                  >
                    Copy Response
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="border-0 shadow-soft bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">
            <CardHeader>
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <CardTitle className="font-display text-lg text-blue-900 dark:text-blue-100">Tips</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-sm text-blue-800 dark:text-blue-200 space-y-2">
              <p>• Be specific about what you need - describe the problem or feature clearly</p>
              <p>• Include error messages if you're reporting a bug</p>
              <p>• Ask for code, fixes, or feature implementations</p>
              <p>• You can copy the AI response and apply it directly to your app</p>
              <p>• Use popular models like Mistral Large, DeepSeek Coder, or Claude for best results</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
