/**
 * Courier Guy Shipping Service
 * Real integration with Courier Guy logistics API
 * NO MOCKS - PRODUCTION READY
 */

import { CREDENTIALS } from "../config/credentials";

interface ShippingQuote {
  from: {
    address: string;
    city: string;
    province: string;
    postalCode: string;
  };
  to: {
    address: string;
    city: string;
    province: string;
    postalCode: string;
  };
  weight: number; // kg
  dimensions?: {
    length: number;
    width: number;
    height: number;
  };
  serviceType?: string; // e.g., "standard", "express"
}

interface ShippingRate {
  serviceType: string;
  cost: number;
  currency: string;
  estimatedDays: number;
  description: string;
}

interface Shipment {
  trackingNumber: string;
  status: string;
  estimatedDelivery: string;
  lastUpdate: string;
  location?: string;
}

class CourierGuyService {
  private apiKey: string;
  private baseURL: string;

  constructor() {
    this.apiKey = CREDENTIALS.courierGuy.apiKey;
    this.baseURL = CREDENTIALS.courierGuy.baseURL;
  }

  /**
   * Get shipping quotes
   */
  async getQuotes(quote: ShippingQuote): Promise<ShippingRate[]> {
    try {
      const response = await fetch(`${this.baseURL}/quote`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from: quote.from,
          to: quote.to,
          weight: quote.weight,
          dimensions: quote.dimensions,
          serviceType: quote.serviceType,
        }),
      });

      if (!response.ok) {
        throw new Error(`Courier Guy API error: ${response.statusText}`);
      }

      const quotes = await response.json();

      return quotes.map((q: any) => ({
        serviceType: q.service_type,
        cost: q.cost,
        currency: "ZAR",
        estimatedDays: q.estimated_days,
        description: q.description,
      }));
    } catch (error) {
      console.error("Courier Guy quote error:", error);
      throw error;
    }
  }

  /**
   * Create shipment
   */
  async createShipment(
    from: ShippingQuote["from"],
    to: ShippingQuote["to"],
    weight: number,
    serviceType: string,
    reference: string
  ): Promise<{ trackingNumber: string; status: string }> {
    try {
      const response = await fetch(`${this.baseURL}/shipments`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${this.apiKey}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          from,
          to,
          weight,
          service_type: serviceType,
          reference,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(`Shipment creation error: ${error.message}`);
      }

      const shipment = await response.json();

      return {
        trackingNumber: shipment.tracking_number,
        status: shipment.status,
      };
    } catch (error) {
      console.error("Shipment creation error:", error);
      throw error;
    }
  }

  /**
   * Track shipment
   */
  async trackShipment(trackingNumber: string): Promise<Shipment> {
    try {
      const response = await fetch(
        `${this.baseURL}/shipments/${trackingNumber}/tracking`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Tracking information not found");
      }

      const tracking = await response.json();

      return {
        trackingNumber: tracking.tracking_number,
        status: tracking.status,
        estimatedDelivery: tracking.estimated_delivery,
        lastUpdate: tracking.last_update,
        location: tracking.current_location,
      };
    } catch (error) {
      console.error("Tracking error:", error);
      throw error;
    }
  }

  /**
   * Cancel shipment
   */
  async cancelShipment(trackingNumber: string): Promise<{
    success: boolean;
    message: string;
  }> {
    try {
      const response = await fetch(
        `${this.baseURL}/shipments/${trackingNumber}/cancel`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to cancel shipment");
      }

      return {
        success: true,
        message: "Shipment cancelled successfully",
      };
    } catch (error) {
      console.error("Cancellation error:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Cancellation failed",
      };
    }
  }

  /**
   * Get shipping label
   */
  async getShippingLabel(trackingNumber: string): Promise<{
    url: string;
    format: string;
  }> {
    try {
      const response = await fetch(
        `${this.baseURL}/shipments/${trackingNumber}/label`,
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${this.apiKey}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Failed to get shipping label");
      }

      const label = await response.json();

      return {
        url: label.label_url,
        format: label.format || "pdf",
      };
    } catch (error) {
      console.error("Label retrieval error:", error);
      throw error;
    }
  }
}

export const courierGuyService = new CourierGuyService();
