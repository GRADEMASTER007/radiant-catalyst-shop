/**
 * AI Configuration - Complete 19 Provider Setup
 * Defines all AI service providers with chat and feature routing
 * Supports intelligent fallback chains and cost optimization
 */

export interface AIProvider {
  name: string;
  type: 'chat' | 'feature' | 'search' | 'code' | 'image';
  baseURL: string;
  apiKey: string;
  models: {
    chat?: string[];
    feature?: string[];
    default?: string;
  };
  enabled: boolean;
  priority: number;
  costPerKToken?: number; // Cost per 1000 tokens
  rateLimit?: number; // Requests per minute
  freeLimit?: number; // Free tier limit per month
}

export interface AIConfig {
  providers: Record<string, AIProvider>;
  chatProviders: string[]; // Ordered list for chat fallback
  featureProviders: string[]; // Ordered list for feature fallback
  defaultChatProvider: string;
  defaultFeatureProvider: string;
  timeout: number;
  maxRetries: number;
}

const aiConfig: AIConfig = {
  providers: {
    // 1. OpenRouter - Primary provider with 11 free models
    openrouter: {
      name: 'OpenRouter',
      type: 'chat',
      baseURL: 'https://openrouter.ai/api/v1',
      apiKey: process.env.OPENROUTER_API_KEY || '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',
      models: {
        chat: [
          'mistralai/devstral-2512:free', // Primary free model
          'qwen/qwen3-next-80b-a3b-instruct:free',
          'deepseek/deepseek-r1-0528:free',
          'meta-llama/llama-3.2-3b-instruct:free',
          'nvidia/nemotron-3-nano-30b-a3b:free',
          'qwen/qwen-2.5-vl-7b-instruct:free',
          'openai/gpt-oss-120b:free',
          'moonshotai/kimi-k2:free',
          'tngtech/deepseek-r1t2-chimera:free',
          'qwen/qwen3-4b:free',
          'mistralai/mistral-7b-instruct',
        ],
        feature: [
          'mistralai/devstral-2512:free',
          'qwen/qwen3-next-80b-a3b-instruct:free',
        ],
        default: 'mistralai/devstral-2512:free',
      },
      enabled: true,
      priority: 1,
      costPerKToken: 0.0,
      rateLimit: 100,
      freeLimit: 100000,
    },

    // 2. Groq - Fast inference
    groq: {
      name: 'Groq',
      type: 'chat',
      baseURL: 'https://api.groq.com/openai/v1',
      apiKey: process.env.GROQ_API_KEY || '',
      models: {
        chat: [
          'mixtral-8x7b-32768',
          'llama2-70b-4096',
          'gemma-7b-it',
        ],
        default: 'mixtral-8x7b-32768',
      },
      enabled: true,
      priority: 2,
      costPerKToken: 0.0,
      rateLimit: 30,
      freeLimit: 14400,
    },

    // 3. Qwen (Alibaba) - Multilingual
    qwen: {
      name: 'Qwen',
      type: 'chat',
      baseURL: 'https://dashscope.aliyuncs.com/api/v1',
      apiKey: process.env.QWEN_API_KEY || '',
      models: {
        chat: [
          'qwen-turbo',
          'qwen-plus',
          'qwen-long',
        ],
        default: 'qwen-turbo',
      },
      enabled: true,
      priority: 3,
      costPerKToken: 0.002,
      rateLimit: 50,
    },

    // 4. Perplexity - Real-time search
    perplexity: {
      name: 'Perplexity',
      type: 'chat',
      baseURL: 'https://api.perplexity.ai',
      apiKey: process.env.PERPLEXITY_API_KEY || '',
      models: {
        chat: [
          'pplx-7b-online',
          'pplx-70b-online',
          'pplx-8x7b-online',
        ],
        default: 'pplx-7b-online',
      },
      enabled: true,
      priority: 4,
      costPerKToken: 0.005,
      rateLimit: 20,
    },

    // 5. ApiFree - Free tier provider
    apifree: {
      name: 'ApiFree',
      type: 'chat',
      baseURL: 'https://api.apifree.com/v1',
      apiKey: process.env.APIFREE_API_KEY || '',
      models: {
        chat: [
          'gpt-3.5-turbo',
          'claude-2',
          'llama-2-70b',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 5,
      costPerKToken: 0.0,
      rateLimit: 10,
      freeLimit: 5000,
    },

    // 6. Hugging Face - Open source models
    huggingface: {
      name: 'Hugging Face',
      type: 'feature',
      baseURL: 'https://api-inference.huggingface.co',
      apiKey: process.env.HUGGINGFACE_API_KEY || '',
      models: {
        feature: [
          'mistralai/Mistral-7B-Instruct-v0.1',
          'meta-llama/Llama-2-7b-chat-hf',
          'tiiuae/falcon-7b-instruct',
        ],
        default: 'mistralai/Mistral-7B-Instruct-v0.1',
      },
      enabled: true,
      priority: 6,
      costPerKToken: 0.0,
      rateLimit: 50,
    },

    // 7. Google Gemini - Multimodal
    gemini: {
      name: 'Google Gemini',
      type: 'chat',
      baseURL: 'https://generativelanguage.googleapis.com/v1beta',
      apiKey: process.env.GOOGLE_GEMINI_API_KEY || '',
      models: {
        chat: [
          'gemini-pro',
          'gemini-pro-vision',
          'gemini-1.5-pro',
        ],
        feature: [
          'gemini-pro',
        ],
        default: 'gemini-pro',
      },
      enabled: true,
      priority: 7,
      costPerKToken: 0.0005,
      rateLimit: 60,
    },

    // 8. AI.CC - Chinese AI provider
    aicc: {
      name: 'AI.CC',
      type: 'chat',
      baseURL: 'https://api.ai.cc/v1',
      apiKey: process.env.AICC_API_KEY || '',
      models: {
        chat: [
          'gpt-3.5-turbo',
          'gpt-4',
          'claude-2',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 8,
      costPerKToken: 0.001,
      rateLimit: 30,
    },

    // 9. Requesty - API aggregator
    requesty: {
      name: 'Requesty',
      type: 'chat',
      baseURL: 'https://api.requesty.com/v1',
      apiKey: process.env.REQUESTY_API_KEY || '',
      models: {
        chat: [
          'gpt-3.5-turbo',
          'claude-instant',
          'palm-2',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 9,
      costPerKToken: 0.0015,
      rateLimit: 40,
    },

    // 10. Ollama Cloud - Hosted Ollama
    ollamaCloud: {
      name: 'Ollama Cloud',
      type: 'chat',
      baseURL: 'https://ollama.com/api',
      apiKey: process.env.OLLAMA_CLOUD_API_KEY || 'cebbc97e307d4e4d9b8a28d8e7b4d32d.SHRF1ZEiQEeRGK6vU4rLMvC4',
      models: {
        chat: [
          'mistral',
          'neural-chat',
          'orca-mini',
          'llama2',
        ],
        feature: [
          'mistral',
        ],
        default: 'mistral',
      },
      enabled: true,
      priority: 10,
      costPerKToken: 0.0,
      rateLimit: 50,
    },

    // 11. Straico - Multi-provider aggregator
    straico: {
      name: 'Straico',
      type: 'chat',
      baseURL: 'https://api.straico.com/v1',
      apiKey: process.env.STRAICO_API_KEY || '',
      models: {
        chat: [
          'gpt-4',
          'gpt-3.5-turbo',
          'claude-3-opus',
          'claude-3-sonnet',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 11,
      costPerKToken: 0.002,
      rateLimit: 60,
    },

    // 12. Mistral - Native Mistral API
    mistral: {
      name: 'Mistral',
      type: 'chat',
      baseURL: 'https://api.mistral.ai/v1',
      apiKey: process.env.MISTRAL_API_KEY || '',
      models: {
        chat: [
          'mistral-small',
          'mistral-medium',
          'mistral-large',
        ],
        feature: [
          'mistral-small',
        ],
        default: 'mistral-small',
      },
      enabled: true,
      priority: 12,
      costPerKToken: 0.0002,
      rateLimit: 100,
    },

    // 13. Anthropic - Claude models
    anthropic: {
      name: 'Anthropic',
      type: 'chat',
      baseURL: 'https://api.anthropic.com/v1',
      apiKey: process.env.ANTHROPIC_API_KEY || '',
      models: {
        chat: [
          'claude-3-opus-20240229',
          'claude-3-sonnet-20240229',
          'claude-3-haiku-20240307',
        ],
        feature: [
          'claude-3-sonnet-20240229',
        ],
        default: 'claude-3-sonnet-20240229',
      },
      enabled: true,
      priority: 13,
      costPerKToken: 0.003,
      rateLimit: 50,
    },

    // 14. Together AI - Open source models
    togetherai: {
      name: 'Together AI',
      type: 'chat',
      baseURL: 'https://api.together.xyz/v1',
      apiKey: process.env.TOGETHER_API_KEY || '',
      models: {
        chat: [
          'meta-llama/Llama-2-70b-chat-hf',
          'mistralai/Mistral-7B-Instruct-v0.1',
          'NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO',
        ],
        feature: [
          'meta-llama/Llama-2-70b-chat-hf',
        ],
        default: 'meta-llama/Llama-2-70b-chat-hf',
      },
      enabled: true,
      priority: 14,
      costPerKToken: 0.0008,
      rateLimit: 50,
    },

    // 15. xAI - Grok models
    xai: {
      name: 'xAI',
      type: 'chat',
      baseURL: 'https://api.x.ai/v1',
      apiKey: process.env.XAI_API_KEY || '',
      models: {
        chat: [
          'grok-beta',
        ],
        default: 'grok-beta',
      },
      enabled: true,
      priority: 15,
      costPerKToken: 0.005,
      rateLimit: 20,
    },

    // 16. OpenAI - GPT models
    openai: {
      name: 'OpenAI',
      type: 'chat',
      baseURL: 'https://api.openai.com/v1',
      apiKey: process.env.OPENAI_API_KEY || '',
      models: {
        chat: [
          'gpt-4-turbo-preview',
          'gpt-4',
          'gpt-3.5-turbo',
        ],
        feature: [
          'gpt-3.5-turbo',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 16,
      costPerKToken: 0.0015,
      rateLimit: 60,
    },

    // 17. Freeplay.ai - Free tier aggregator
    freeplayai: {
      name: 'Freeplay.ai',
      type: 'chat',
      baseURL: 'https://api.freeplay.ai/v1',
      apiKey: process.env.FREEPLAY_API_KEY || '',
      models: {
        chat: [
          'gpt-3.5-turbo',
          'claude-instant',
          'palm-2',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 17,
      costPerKToken: 0.0,
      rateLimit: 10,
      freeLimit: 5000,
    },

    // 18. Clarifai - Vision and NLP
    clarifai: {
      name: 'Clarifai',
      type: 'feature',
      baseURL: 'https://api.clarifai.com/v2',
      apiKey: process.env.CLARIFAI_API_KEY || '',
      models: {
        feature: [
          'general-image-recognition',
          'text-understanding',
          'nlp-models',
        ],
        default: 'general-image-recognition',
      },
      enabled: true,
      priority: 18,
      costPerKToken: 0.001,
      rateLimit: 30,
    },

    // 19. Cerebras - Fast inference
    cerebras: {
      name: 'Cerebras',
      type: 'chat',
      baseURL: 'https://api.cerebras.ai/v1',
      apiKey: process.env.CEREBRAS_API_KEY || '',
      models: {
        chat: [
          'llama-2-70b',
          'mistral-7b',
        ],
        default: 'llama-2-70b',
      },
      enabled: true,
      priority: 19,
      costPerKToken: 0.0003,
      rateLimit: 100,
    },

    // 20. 1min.ai - Quick responses
    oneminai: {
      name: '1min.ai',
      type: 'chat',
      baseURL: 'https://api.1min.ai/v1',
      apiKey: process.env.ONEMIN_API_KEY || '',
      models: {
        chat: [
          'gpt-3.5-turbo',
          'claude-instant',
        ],
        default: 'gpt-3.5-turbo',
      },
      enabled: true,
      priority: 20,
      costPerKToken: 0.0,
      rateLimit: 20,
      freeLimit: 10000,
    },

    // Local Ollama fallback
    ollamaLocal: {
      name: 'Ollama Local',
      type: 'chat',
      baseURL: 'http://localhost:11434/api',
      apiKey: '',
      models: {
        chat: [
          'mistral',
          'neural-chat',
          'orca-mini',
        ],
        default: 'mistral',
      },
      enabled: false, // Only enable if Ollama is running locally
      priority: 99,
      costPerKToken: 0.0,
      rateLimit: 100,
    },

    // SerpAPI for search
    serpapi: {
      name: 'SerpAPI',
      type: 'search',
      baseURL: 'https://serpapi.com',
      apiKey: process.env.SERPAPI_API_KEY || 'c1ff1791c17d28baf2c8d4dde29b12ef6064a3f19a3c55dee939f6512378aa04',
      models: {
        feature: [
          'google',
          'bing',
          'baidu',
        ],
        default: 'google',
      },
      enabled: true,
      priority: 21,
      costPerKToken: 0.01,
      rateLimit: 100,
    },

    // Kilo Code for code generation
    kiloCode: {
      name: 'Kilo Code',
      type: 'code',
      baseURL: 'https://api.kilo.dev',
      apiKey: process.env.KILO_CODE_JWT || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
      models: {
        feature: [
          'code-generator',
          'code-reviewer',
          'code-optimizer',
        ],
        default: 'code-generator',
      },
      enabled: true,
      priority: 22,
      costPerKToken: 0.002,
      rateLimit: 50,
    },
  },

  // Chat fallback chain - ordered by priority
  chatProviders: [
    'openrouter', // Primary: 11 free models
    'groq', // Fast inference
    'qwen', // Multilingual
    'perplexity', // Real-time search
    'apifree', // Free tier
    'gemini', // Multimodal
    'aicc', // Chinese provider
    'requesty', // Aggregator
    'ollamaCloud', // Hosted
    'straico', // Multi-provider
    'mistral', // Native API
    'anthropic', // Claude
    'togetherai', // Open source
    'xai', // Grok
    'openai', // GPT
    'freeplayai', // Free aggregator
    'cerebras', // Fast
    'oneminai', // Quick
    'ollamaLocal', // Local fallback
  ],

  // Feature fallback chain - for specialized tasks
  featureProviders: [
    'openrouter', // Primary
    'groq', // Fast
    'huggingface', // Open source
    'gemini', // Multimodal
    'mistral', // Native
    'anthropic', // Claude
    'togetherai', // Open source
    'clarifai', // Vision
    'serpapi', // Search
    'kiloCode', // Code
  ],

  defaultChatProvider: 'openrouter',
  defaultFeatureProvider: 'openrouter',
  timeout: 30000, // 30 seconds
  maxRetries: 3,
};

export default aiConfig;
