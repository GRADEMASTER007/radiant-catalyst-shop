/**
 * AI tRPC Router
 * Exposes AI operations as tRPC procedures
 */

import { router, publicProcedure } from '../backend/trpc';
import { z } from 'zod';
import aiRouter from './ai-enhanced';

export const aiProcedureRouter = router({
  /**
   * Query AI with specified provider and model
   */
  query: publicProcedure
    .input(
      z.object({
        prompt: z.string().max(5000),
        model: z.string().optional(),
        service: z.string().optional(),
        temperature: z.number().min(0).max(2).optional(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const response = await aiRouter.routeQuery({
          prompt: input.prompt,
          model: input.model,
          service: input.service,
          temperature: input.temperature,
        });

        return {
          success: true,
          response: response.content,
          model: response.model,
          provider: response.provider,
          tokensUsed: response.tokensUsed,
          costUSD: response.costUSD,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }),

  /**
   * Get AI query history
   */
  getHistory: publicProcedure
    .input(z.object({ limit: z.number().optional() }))
    .query(({ input }) => {
      return aiRouter.getHistory(input.limit);
    }),

  /**
   * Get cost statistics
   */
  getCostStats: publicProcedure.query(() => {
    return aiRouter.getCostStats();
  }),

  /**
   * Clear history
   */
  clearHistory: publicProcedure.mutation(() => {
    aiRouter.clearHistory();
    return { success: true };
  }),
});

export default aiProcedureRouter;
