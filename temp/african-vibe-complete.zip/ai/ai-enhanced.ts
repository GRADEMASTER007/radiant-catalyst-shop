/**
 * Enhanced AI Router - Complete Implementation
 * Handles intelligent routing between 19+ AI providers
 * Supports separate chat vs feature routing with fallback chains
 * Includes cost tracking, rate limiting, and free tier management
 */

import axios from 'axios';
import aiConfig from './ai-config';

export interface AIQuery {
  prompt: string;
  type: 'chat' | 'feature' | 'search' | 'code' | 'image'; // Task type
  model?: string;
  service?: string;
  temperature?: number;
  maxTokens?: number;
  userId?: string;
}

export interface AIResponse {
  content: string;
  model: string;
  provider: string;
  tokensUsed: number;
  costUSD: number;
  timestamp: Date;
  fallbackAttempts?: number;
}

export interface ProviderStats {
  provider: string;
  totalCost: number;
  totalTokens: number;
  totalRequests: number;
  failureCount: number;
  lastUsed: Date;
}

class AIRouter {
  private queryHistory: AIQuery[] = [];
  private responseHistory: AIResponse[] = [];
  private costTracker: Record<string, ProviderStats> = {};
  private rateLimitTracker: Record<string, { count: number; resetTime: number }> = {};
  private freeTierTracker: Record<string, { used: number; limit: number; resetDate: Date }> = {};

  constructor() {
    this.initializeTrackers();
  }

  /**
   * Initialize cost and rate limit trackers for all providers
   */
  private initializeTrackers(): void {
    Object.entries(aiConfig.providers).forEach(([key, provider]) => {
      this.costTracker[key] = {
        provider: provider.name,
        totalCost: 0,
        totalTokens: 0,
        totalRequests: 0,
        failureCount: 0,
        lastUsed: new Date(),
      };

      if (provider.rateLimit) {
        this.rateLimitTracker[key] = {
          count: 0,
          resetTime: Date.now() + 60000, // Reset every minute
        };
      }

      if (provider.freeLimit) {
        this.freeTierTracker[key] = {
          used: 0,
          limit: provider.freeLimit,
          resetDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // Monthly reset
        };
      }
    });
  }

  /**
   * Check if provider is available (rate limit, free tier, enabled)
   */
  private isProviderAvailable(providerKey: string): boolean {
    const provider = aiConfig.providers[providerKey];

    if (!provider.enabled || !provider.apiKey) {
      return false;
    }

    // Check rate limit
    const rateLimitData = this.rateLimitTracker[providerKey];
    if (rateLimitData) {
      if (Date.now() > rateLimitData.resetTime) {
        rateLimitData.count = 0;
        rateLimitData.resetTime = Date.now() + 60000;
      }
      if (provider.rateLimit && rateLimitData.count >= provider.rateLimit) {
        return false;
      }
    }

    // Check free tier
    const freeTierData = this.freeTierTracker[providerKey];
    if (freeTierData) {
      if (new Date() > freeTierData.resetDate) {
        freeTierData.used = 0;
        freeTierData.resetDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
      }
      if (freeTierData.used >= freeTierData.limit) {
        return false;
      }
    }

    return true;
  }

  /**
   * Route query to best provider based on task type and availability
   */
  async routeQuery(query: AIQuery): Promise<AIResponse> {
    const taskType = query.type || 'chat';
    const fallbackChain = taskType === 'chat' ? aiConfig.chatProviders : aiConfig.featureProviders;

    let lastError: Error | null = null;
    let fallbackAttempts = 0;

    // Try each provider in fallback chain
    for (const providerKey of fallbackChain) {
      if (!this.isProviderAvailable(providerKey)) {
        continue;
      }

      try {
        const provider = aiConfig.providers[providerKey];
        const model = query.model || provider.models.default || provider.models.chat?.[0] || provider.models.feature?.[0];

        let response: AIResponse;

        // Route to appropriate provider handler
        switch (providerKey) {
          case 'openrouter':
            response = await this.queryOpenRouter(query.prompt, model, query.temperature);
            break;
          case 'groq':
            response = await this.queryGroq(query.prompt, model, query.temperature);
            break;
          case 'qwen':
            response = await this.queryQwen(query.prompt, model, query.temperature);
            break;
          case 'perplexity':
            response = await this.queryPerplexity(query.prompt, model, query.temperature);
            break;
          case 'apifree':
            response = await this.queryApiFree(query.prompt, model, query.temperature);
            break;
          case 'huggingface':
            response = await this.queryHuggingFace(query.prompt, model);
            break;
          case 'gemini':
            response = await this.queryGemini(query.prompt, model, query.temperature);
            break;
          case 'aicc':
            response = await this.queryAICC(query.prompt, model, query.temperature);
            break;
          case 'requesty':
            response = await this.queryRequesty(query.prompt, model, query.temperature);
            break;
          case 'ollamaCloud':
            response = await this.queryOllamaCloud(query.prompt, model, query.temperature);
            break;
          case 'straico':
            response = await this.queryStraico(query.prompt, model, query.temperature);
            break;
          case 'mistral':
            response = await this.queryMistral(query.prompt, model, query.temperature);
            break;
          case 'anthropic':
            response = await this.queryAnthropic(query.prompt, model, query.temperature);
            break;
          case 'togetherai':
            response = await this.queryTogetherAI(query.prompt, model, query.temperature);
            break;
          case 'xai':
            response = await this.queryXAI(query.prompt, model, query.temperature);
            break;
          case 'openai':
            response = await this.queryOpenAI(query.prompt, model, query.temperature);
            break;
          case 'freeplayai':
            response = await this.queryFreeplayAI(query.prompt, model, query.temperature);
            break;
          case 'clarifai':
            response = await this.queryClarifai(query.prompt, model);
            break;
          case 'cerebras':
            response = await this.queryCerebras(query.prompt, model, query.temperature);
            break;
          case 'oneminai':
            response = await this.queryOneMinAI(query.prompt, model, query.temperature);
            break;
          case 'ollamaLocal':
            response = await this.queryOllamaLocal(query.prompt, model, query.temperature);
            break;
          case 'serpapi':
            response = await this.querySerpAPI(query.prompt);
            break;
          case 'kiloCode':
            response = await this.queryKiloCode(query.prompt, model);
            break;
          default:
            throw new Error(`Unknown provider: ${providerKey}`);
        }

        // Update trackers
        this.updateProviderStats(providerKey, response);
        response.fallbackAttempts = fallbackAttempts;

        // Store in history
        this.queryHistory.push(query);
        this.responseHistory.push(response);

        return response;
      } catch (error) {
        lastError = error as Error;
        fallbackAttempts++;
        this.costTracker[providerKey].failureCount++;
        console.warn(`Provider ${providerKey} failed: ${lastError.message}`);
        continue; // Try next provider
      }
    }

    // All providers failed
    throw new Error(
      `All AI providers failed. Last error: ${lastError?.message || 'Unknown error'}. ` +
      `Attempted ${fallbackAttempts} providers.`
    );
  }

  /**
   * Update provider statistics after successful query
   */
  private updateProviderStats(providerKey: string, response: AIResponse): void {
    const stats = this.costTracker[providerKey];
    stats.totalCost += response.costUSD;
    stats.totalTokens += response.tokensUsed;
    stats.totalRequests++;
    stats.lastUsed = new Date();

    // Update rate limit
    if (this.rateLimitTracker[providerKey]) {
      this.rateLimitTracker[providerKey].count++;
    }

    // Update free tier
    if (this.freeTierTracker[providerKey]) {
      this.freeTierTracker[providerKey].used += response.tokensUsed;
    }
  }

  /**
   * Query OpenRouter API (Primary provider with 11 free models)
   */
  private async queryOpenRouter(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.openrouter;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://dragon-fruit-sa.com',
          'X-Title': 'Dragon Fruit SA',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = model.includes(':free') ? 0 : (tokensUsed / 1000) * 0.001;

    return {
      content,
      model,
      provider: 'openrouter',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Groq API (Fast inference)
   */
  private async queryGroq(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.groq;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = 0; // Groq free tier

    return {
      content,
      model,
      provider: 'groq',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Qwen API (Alibaba, multilingual)
   */
  private async queryQwen(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.qwen;

    const response = await axios.post(
      `${config.baseURL}/services/aigc/text-generation/generation`,
      {
        model,
        input: { messages: [{ role: 'user', content: prompt }] },
        parameters: { temperature, max_tokens: 2000 },
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.output.text;
    const tokensUsed = response.data.usage.output_tokens + response.data.usage.input_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.qwen.costPerKToken || 0.002);

    return {
      content,
      model,
      provider: 'qwen',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Perplexity API (Real-time search)
   */
  private async queryPerplexity(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.perplexity;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.perplexity.costPerKToken || 0.005);

    return {
      content,
      model,
      provider: 'perplexity',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query ApiFree (Free tier provider)
   */
  private async queryApiFree(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.apifree;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = 0; // Free tier

    return {
      content,
      model,
      provider: 'apifree',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Hugging Face (Open source models)
   */
  private async queryHuggingFace(prompt: string, model: string): Promise<AIResponse> {
    const config = aiConfig.providers.huggingface;

    const response = await axios.post(
      `${config.baseURL}/models/${model}`,
      { inputs: prompt },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = Array.isArray(response.data)
      ? response.data[0]?.generated_text || response.data[0]?.text || ''
      : response.data.generated_text || response.data.text || '';

    return {
      content,
      model,
      provider: 'huggingface',
      tokensUsed: 0,
      costUSD: 0,
      timestamp: new Date(),
    };
  }

  /**
   * Query Google Gemini (Multimodal)
   */
  private async queryGemini(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.gemini;

    const response = await axios.post(
      `${config.baseURL}/models/${model}:generateContent`,
      {
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: { temperature, maxOutputTokens: 2000 },
      },
      {
        headers: {
          'x-goog-api-key': config.apiKey,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.candidates[0].content.parts[0].text;
    const tokensUsed = response.data.usageMetadata.totalTokenCount;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.gemini.costPerKToken || 0.0005);

    return {
      content,
      model,
      provider: 'gemini',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query AI.CC (Chinese provider)
   */
  private async queryAICC(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.aicc;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.aicc.costPerKToken || 0.001);

    return {
      content,
      model,
      provider: 'aicc',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Requesty (API aggregator)
   */
  private async queryRequesty(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.requesty;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.requesty.costPerKToken || 0.0015);

    return {
      content,
      model,
      provider: 'requesty',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Ollama Cloud (Hosted Ollama)
   */
  private async queryOllamaCloud(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.ollamaCloud;

    const response = await axios.post(
      `${config.baseURL}/generate`,
      {
        model,
        prompt,
        temperature,
        stream: false,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.response;
    const tokensUsed = response.data.eval_count || 0;
    const costUSD = 0;

    return {
      content,
      model,
      provider: 'ollama-cloud',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Straico (Multi-provider aggregator)
   */
  private async queryStraico(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.straico;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.straico.costPerKToken || 0.002);

    return {
      content,
      model,
      provider: 'straico',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Mistral (Native Mistral API)
   */
  private async queryMistral(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.mistral;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.mistral.costPerKToken || 0.0002);

    return {
      content,
      model,
      provider: 'mistral',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Anthropic (Claude models)
   */
  private async queryAnthropic(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.anthropic;

    const response = await axios.post(
      `${config.baseURL}/messages`,
      {
        model,
        max_tokens: 2000,
        temperature,
        messages: [{ role: 'user', content: prompt }],
      },
      {
        headers: {
          'x-api-key': config.apiKey,
          'anthropic-version': '2023-06-01',
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.content[0].text;
    const tokensUsed = response.data.usage.output_tokens + response.data.usage.input_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.anthropic.costPerKToken || 0.003);

    return {
      content,
      model,
      provider: 'anthropic',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Together AI (Open source models)
   */
  private async queryTogetherAI(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.togetherai;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.togetherai.costPerKToken || 0.0008);

    return {
      content,
      model,
      provider: 'togetherai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query xAI (Grok models)
   */
  private async queryXAI(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.xai;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.xai.costPerKToken || 0.005);

    return {
      content,
      model,
      provider: 'xai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query OpenAI (GPT models)
   */
  private async queryOpenAI(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.openai;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.openai.costPerKToken || 0.0015);

    return {
      content,
      model,
      provider: 'openai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Freeplay.ai (Free tier aggregator)
   */
  private async queryFreeplayAI(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.freeplayai;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = 0; // Free tier

    return {
      content,
      model,
      provider: 'freeplayai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Clarifai (Vision and NLP)
   */
  private async queryClarifai(prompt: string, model: string): Promise<AIResponse> {
    const config = aiConfig.providers.clarifai;

    const response = await axios.post(
      `${config.baseURL}/users/clarifai/apps/main/models/${model}/outputs`,
      {
        inputs: [{ data: { text: { raw: prompt } } }],
      },
      {
        headers: {
          'Authorization': `Key ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.outputs[0].data.text.raw;
    const tokensUsed = 0;
    const costUSD = (aiConfig.providers.clarifai.costPerKToken || 0.001) * 0.1;

    return {
      content,
      model,
      provider: 'clarifai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Cerebras (Fast inference)
   */
  private async queryCerebras(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.cerebras;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = (tokensUsed / 1000) * (aiConfig.providers.cerebras.costPerKToken || 0.0003);

    return {
      content,
      model,
      provider: 'cerebras',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query 1min.ai (Quick responses)
   */
  private async queryOneMinAI(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.oneminai;

    const response = await axios.post(
      `${config.baseURL}/chat/completions`,
      {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature,
        max_tokens: 2000,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.choices[0].message.content;
    const tokensUsed = response.data.usage.total_tokens;
    const costUSD = 0; // Free tier

    return {
      content,
      model,
      provider: 'oneminai',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query Ollama Local (Free, runs on localhost)
   */
  private async queryOllamaLocal(
    prompt: string,
    model: string,
    temperature: number = 0.7
  ): Promise<AIResponse> {
    const config = aiConfig.providers.ollamaLocal;

    const response = await axios.post(
      `${config.baseURL}/generate`,
      {
        model,
        prompt,
        temperature,
        stream: false,
      },
      {
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.response;
    const tokensUsed = response.data.eval_count || 0;
    const costUSD = 0;

    return {
      content,
      model,
      provider: 'ollama-local',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Query SerpAPI (For search)
   */
  private async querySerpAPI(prompt: string): Promise<AIResponse> {
    const config = aiConfig.providers.serpapi;

    const response = await axios.get('https://serpapi.com/search', {
      params: {
        q: prompt,
        api_key: config.apiKey,
      },
      timeout: aiConfig.timeout,
    });

    const results = response.data.organic_results || [];
    const content = results
      .slice(0, 5)
      .map((r: any) => `**${r.title}**\n${r.snippet}\n${r.link}`)
      .join('\n\n');

    return {
      content,
      model: 'google-search',
      provider: 'serpapi',
      tokensUsed: 0,
      costUSD: aiConfig.providers.serpapi.costPerKToken || 0.01,
      timestamp: new Date(),
    };
  }

  /**
   * Query Kilo Code (For code generation)
   */
  private async queryKiloCode(prompt: string, model: string): Promise<AIResponse> {
    const config = aiConfig.providers.kiloCode;

    const response = await axios.post(
      `${config.baseURL}/v1/code/generate`,
      {
        model,
        prompt,
      },
      {
        headers: {
          'Authorization': `Bearer ${config.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: aiConfig.timeout,
      }
    );

    const content = response.data.code || response.data.response;
    const tokensUsed = response.data.tokens_used || 0;
    const costUSD = response.data.cost_usd || (tokensUsed / 1000) * (aiConfig.providers.kiloCode.costPerKToken || 0.002);

    return {
      content,
      model,
      provider: 'kilo-code',
      tokensUsed,
      costUSD,
      timestamp: new Date(),
    };
  }

  /**
   * Get cost statistics for all providers
   */
  getCostStats(): Record<string, ProviderStats> {
    return this.costTracker;
  }

  /**
   * Get query history
   */
  getHistory(limit: number = 50): AIResponse[] {
    return this.responseHistory.slice(-limit);
  }

  /**
   * Clear history
   */
  clearHistory(): void {
    this.queryHistory = [];
    this.responseHistory = [];
  }

  /**
   * Get provider availability status
   */
  getProviderStatus(): Record<string, boolean> {
    const status: Record<string, boolean> = {};
    Object.keys(aiConfig.providers).forEach((key) => {
      status[key] = this.isProviderAvailable(key);
    });
    return status;
  }

  /**
   * Get rate limit status for all providers
   */
  getRateLimitStatus(): Record<string, { remaining: number; resetTime: number }> {
    const status: Record<string, { remaining: number; resetTime: number }> = {};
    Object.entries(this.rateLimitTracker).forEach(([key, data]) => {
      const provider = aiConfig.providers[key];
      const limit = provider.rateLimit || 100;
      status[key] = {
        remaining: Math.max(0, limit - data.count),
        resetTime: data.resetTime,
      };
    });
    return status;
  }

  /**
   * Get free tier usage status
   */
  getFreeTierStatus(): Record<string, { used: number; limit: number; remaining: number }> {
    const status: Record<string, { used: number; limit: number; remaining: number }> = {};
    Object.entries(this.freeTierTracker).forEach(([key, data]) => {
      status[key] = {
        used: data.used,
        limit: data.limit,
        remaining: Math.max(0, data.limit - data.used),
      };
    });
    return status;
  }
}

export default new AIRouter();
