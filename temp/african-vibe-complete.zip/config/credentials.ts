/**
 * Credentials Configuration
 * All API keys and credentials are loaded from environment variables
 */

export const credentials = {
  // Database
  database: {
    url: process.env.DATABASE_URL || '',
  },

  // Admin
  admin: {
    username: process.env.ADMIN_USERNAME || 'admin',
    password: process.env.ADMIN_PASSWORD || 'Kyknet.01',
  },

  // AI Services
  ai: {
    openrouter: {
      apiKey: process.env.OPENROUTER_API_KEY || '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',
      baseUrl: 'https://openrouter.ai/api/v1',
    },
    ollamaCloud: {
      apiKey: process.env.OLLAMA_CLOUD_API_KEY || 'cebbc97e307d4e4d9b8a28d8e7b4d32d.SHRF1ZEiQEeRGK6vU4rLMvC4',
      baseUrl: 'https://ollama.com/api',
    },
    ollamaLocal: {
      baseUrl: process.env.OLLAMA_LOCAL_URL || 'http://localhost:11434/api',
    },
    kiloCode: {
      jwt: process.env.KILO_CODE_JWT || '',
      baseUrl: 'https://api.kilo.dev',
    },
    serpapi: {
      apiKey: process.env.SERPAPI_API_KEY || 'c1ff1791c17d28baf2c8d4dde29b12ef6064a3f19a3c55dee939f6512378aa04',
      baseUrl: 'https://serpapi.com',
    },
    github: {
      token: process.env.GITHUB_TOKEN || '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',
    },
  },

  // Payment Gateways
  payment: {
    payfast: {
      merchantId: process.env.PAYFAST_MERCHANT_ID || '11071120',
      merchantKey: process.env.PAYFAST_MERCHANT_KEY || 'p6fi9ewdjk1js',
      passphrase: process.env.PAYFAST_PASSPHRASE || 'abCd15ab92g12',
      debugEmail: process.env.PAYFAST_DEBUG_EMAIL || 'waterkefirsa@gmail.com',
      baseUrl: 'https://www.payfast.co.za',
    },
    yoco: {
      publicKey: process.env.YOCO_PUBLIC_KEY || 'pk_live_b21ac3bd1WM6WRY3f9f4',
      secretKey: process.env.YOCO_SECRET_KEY || 'sk_live_87380fcbgEgAEJa48704613a39ec',
      baseUrl: 'https://api.yoco.com/v1',
    },
  },

  // Shipping Providers
  shipping: {
    courierGuy: {
      apiKey: process.env.COURIER_GUY_API_KEY || 'e28f9909fa734d0a8ce9641c8db68c9f',
      alternateKey: process.env.COURIER_GUY_ALTERNATE_KEY || 'c720aa50a628477e83bd74a0cb46cf9e',
      baseUrl: 'https://api.courierguycorp.com',
    },
    pudo: {
      apiKey: process.env.PUDO_API_KEY || '51577192|tCQuvbHTuSMgUYgb1Bqh5IEG48DbXXkHF6yBGQYN02422ea5',
      baseUrl: 'https://api.pudo.co.za',
    },
  },

  // Email Configuration
  email: {
    smtp: {
      host: process.env.EMAIL_SMTP_HOST || 'mail.proagrisa.co.za',
      port: parseInt(process.env.EMAIL_SMTP_PORT || '465'),
      user: process.env.EMAIL_SMTP_USER || 'orders@proagrisa.co.za',
      password: process.env.EMAIL_SMTP_PASSWORD || 'Kyknet.01',
    },
    from: process.env.EMAIL_FROM || 'orders@proagrisa.co.za',
    fromName: process.env.EMAIL_FROM_NAME || 'Dragon Fruit SA',
  },

  // Business Information
  business: {
    name: process.env.BUSINESS_NAME || 'Dragon Fruit SA',
    email: process.env.BUSINESS_EMAIL || 'admin@proagrisa.co.za',
    phone: process.env.BUSINESS_PHONE || '+1 351 777 2848',
    phoneAfterHours: process.env.BUSINESS_PHONE_AFTER_HOURS || '083 447 4639',
    whatsapp1: process.env.BUSINESS_WHATSAPP_1 || '+27 83 447 4639',
    whatsapp2: process.env.BUSINESS_WHATSAPP_2 || '+1 555 708 3482',
  },

  // Currency Settings
  currency: {
    default: process.env.DEFAULT_CURRENCY || 'ZAR',
    secondary: process.env.SECONDARY_CURRENCY || 'USD',
  },

  // Application Settings
  app: {
    environment: process.env.NODE_ENV || 'production',
    port: parseInt(process.env.PORT || '3000'),
    logLevel: process.env.LOG_LEVEL || 'info',
  },
};

export default credentials;
