import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Send, Loader2, LogOut } from "lucide-react";
import { trpc } from "@/lib/trpc";

const OPENROUTER_MODELS = [
  { id: "nvidia/nemotron-3-nano-30b-a3b:free", name: "Nvidia Nemotron 3 Nano" },
  { id: "mistralai/devstral-2512:free", name: "Mistral Devstral 2512" },
  { id: "qwen/qwen3-next-80b-a3b-instruct:free", name: "Qwen 3 Next 80B" },
  { id: "openai/gpt-oss-120b:free", name: "OpenAI GPT OSS 120B" },
  { id: "qwen/qwen3-coder:free", name: "Qwen 3 Coder" },
  { id: "moonshotai/kimi-k2:free", name: "Kimi K2" },
  { id: "tngtech/deepseek-r1t2-chimera:free", name: "DeepSeek R1T2 Chimera" },
  { id: "deepseek/deepseek-r1-0528:free", name: "DeepSeek R1 0528" },
  { id: "qwen/qwen3-4b:free", name: "Qwen 3 4B" },
  { id: "meta-llama/llama-3.2-3b-instruct:free", name: "Llama 3.2 3B" },
  { id: "qwen/qwen-2.5-vl-7b-instruct:free", name: "Qwen 2.5 VL 7B" },
];

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const [selectedModel, setSelectedModel] = useState(OPENROUTER_MODELS[0].id);
  const [prompt, setPrompt] = useState("");
  const [response, setResponse] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  // Check admin auth
  const { data: adminUser, isLoading: isCheckingAuth } = trpc.admin.me.useQuery();

  useEffect(() => {
    if (!isCheckingAuth && !adminUser) {
      navigate("/admin/login");
    }
  }, [adminUser, isCheckingAuth, navigate]);

  const logoutMutation = trpc.admin.logout.useMutation({
    onSuccess: () => {
      navigate("/admin/login");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleSendPrompt = async () => {
    if (!prompt.trim()) {
      setError("Please enter a prompt");
      return;
    }

    setIsLoading(true);
    setError("");
    setResponse("");

    try {
      // Call OpenRouter API directly
      const apiResponse = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${import.meta.env.VITE_OPENROUTER_API_KEY || "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"}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          messages: [
            {
              role: "system",
              content: "You are an expert AI assistant for e-commerce platforms. Help with content creation, code generation, SEO optimization, and business improvements. Provide clear, actionable responses.",
            },
            {
              role: "user",
              content: prompt,
            },
          ],
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!apiResponse.ok) {
        const errorData = await apiResponse.json();
        throw new Error(errorData.error?.message || "API request failed");
      }

      const data = await apiResponse.json();
      const aiResponse = data.choices?.[0]?.message?.content || "No response received";
      setResponse(aiResponse);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to get AI response");
    } finally {
      setIsLoading(false);
    }
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-sm text-gray-600">Welcome, {adminUser?.username}</p>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="flex items-center gap-2"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto p-4">
        <Tabs defaultValue="ai-assistant" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="ai-assistant">AI Assistant</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* AI Assistant Tab */}
          <TabsContent value="ai-assistant" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>AI Prompt Interface</CardTitle>
                <CardDescription>
                  Use AI to generate content, code, SEO metadata, product descriptions, and more
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Model Selector */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Select AI Model</label>
                  <Select value={selectedModel} onValueChange={setSelectedModel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {OPENROUTER_MODELS.map((model) => (
                        <SelectItem key={model.id} value={model.id}>
                          {model.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Prompt Input */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Your Prompt (up to 1000 words)</label>
                  <Textarea
                    placeholder="Enter your prompt here. Examples:
- Generate 5 product descriptions for dragon fruit
- Create SEO metadata for our homepage
- Write a blog post about the health benefits of dragon fruit
- Generate code to add a new feature
- Create a movie banner design description
- List all biological uses of dragon fruit
- Write food industry applications"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value.slice(0, 5000))}
                    className="min-h-[300px] font-mono text-sm"
                    disabled={isLoading}
                  />
                  <p className="text-xs text-gray-500">
                    {prompt.length} / 5000 characters
                  </p>
                </div>

                {/* Error Message */}
                {error && (
                  <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-md">
                    <AlertCircle className="w-4 h-4 text-red-600" />
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                )}

                {/* Send Button */}
                <Button
                  onClick={handleSendPrompt}
                  disabled={isLoading || !prompt.trim()}
                  className="w-full bg-purple-600 hover:bg-purple-700 flex items-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      Send Prompt
                    </>
                  )}
                </Button>

                {/* Response */}
                {response && (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">AI Response</label>
                    <div className="bg-gray-50 border border-gray-200 rounded-md p-4 max-h-[400px] overflow-y-auto">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{response}</p>
                    </div>
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={() => {
                        navigator.clipboard.writeText(response);
                        alert("Response copied to clipboard!");
                      }}
                    >
                      Copy Response
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products">
            <Card>
              <CardHeader>
                <CardTitle>Products</CardTitle>
                <CardDescription>Manage your product catalog</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Product management coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>Orders</CardTitle>
                <CardDescription>View and manage customer orders</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Order management coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Settings</CardTitle>
                <CardDescription>Configure your store settings</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Settings coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
