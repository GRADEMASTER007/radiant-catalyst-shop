import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import AdminLogin from '../admin/AdminLogin';
import AdminDashboard from '../admin/AdminDashboard';
import AdminAIEnhanced from '../admin/AdminAIEnhanced';

export default function App() {
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [sessionId, setSessionId] = useState<string | null>(null);

  const handleAdminLogin = (newSessionId: string) => {
    setSessionId(newSessionId);
    setIsAdminLoggedIn(true);
  };

  const handleAdminLogout = () => {
    setSessionId(null);
    setIsAdminLoggedIn(false);
  };

  return (
    <Router>
      <div className="min-h-screen bg-white">
        {/* Navigation */}
        <nav className="bg-slate-900 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <Link to="/" className="text-2xl font-bold">
              🌾 Dragon Fruit SA
            </Link>
            <div className="flex gap-4">
              <Link to="/" className="hover:text-slate-300">
                Home
              </Link>
              {isAdminLoggedIn ? (
                <>
                  <Link to="/admin/dashboard" className="hover:text-slate-300">
                    Admin Dashboard
                  </Link>
                  <button
                    onClick={handleAdminLogout}
                    className="hover:text-slate-300"
                  >
                    Logout
                  </button>
                </>
              ) : (
                <Link to="/admin/login" className="hover:text-slate-300">
                  🔐 Admin Login
                </Link>
              )}
            </div>
          </div>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/admin/login"
            element={
              <AdminLogin onLoginSuccess={handleAdminLogin} />
            }
          />
          {isAdminLoggedIn && (
            <>
              <Route
                path="/admin/dashboard"
                element={<AdminDashboard sessionId={sessionId} />}
              />
              <Route
                path="/admin/ai"
                element={<AdminAIEnhanced />}
              />
            </>
          )}
        </Routes>

        {/* Footer */}
        <footer className="bg-slate-900 text-white mt-12 py-8">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2026 Dragon Fruit SA. All rights reserved.</p>
            <p className="text-slate-400 mt-2">
              📞 +1 351 777 2848 | 📧 admin@proagrisa.co.za
            </p>
          </div>
        </footer>
      </div>
    </Router>
  );
}
