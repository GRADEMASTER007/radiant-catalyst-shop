import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* Hero Banner */}
      <div className="relative h-96 bg-gradient-to-r from-green-600 to-emerald-600 flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <video
            autoPlay
            muted
            loop
            className="w-full h-full object-cover"
            src="https://videos.pexels.com/video-files/3571899/3571899-hd_1920_1080_25fps.mp4"
          />
        </div>
        <div className="relative z-10 text-center text-white">
          <h1 className="text-5xl font-bold mb-4">🌾 Dragon Fruit SA</h1>
          <p className="text-2xl">Premium Agricultural Products & Solutions</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        {/* Welcome Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Welcome to Dragon Fruit SA</h2>
          <p className="text-lg text-slate-700 leading-relaxed mb-4">
            Dragon Fruit SA is your premier destination for high-quality agricultural products, sustainable farming solutions, and innovative bio-based innovations. We specialize in providing premium products for the food industry, scientific research, and environmental sustainability initiatives.
          </p>
          <p className="text-lg text-slate-700 leading-relaxed">
            Our commitment to excellence, quality, and sustainability has made us a trusted partner for businesses and researchers across South Africa and internationally. We offer a comprehensive range of products including organic produce, agricultural inputs, and specialized solutions for various industries.
          </p>
        </section>

        {/* Product Categories */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-8">Our Product Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Science & Research */}
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-blue-600">
              <h3 className="text-xl font-bold text-slate-900 mb-4">🔬 Science & Research</h3>
              <p className="text-slate-700">
                High-purity compounds and specialized materials for scientific research, laboratory analysis, and academic institutions. Our products meet international standards for research applications.
              </p>
            </div>

            {/* Food Industry */}
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-green-600">
              <h3 className="text-xl font-bold text-slate-900 mb-4">🍽️ Food Industry</h3>
              <p className="text-slate-700">
                Premium agricultural products for food manufacturers, processors, and distributors. We supply organic and conventional products with full traceability and quality certifications.
              </p>
            </div>

            {/* Environmental Solutions */}
            <div className="bg-white rounded-lg shadow-lg p-6 border-l-4 border-emerald-600">
              <h3 className="text-xl font-bold text-slate-900 mb-4">🌱 Environmental Solutions</h3>
              <p className="text-slate-700">
                Eco-friendly products and sustainable solutions for environmental conservation, waste reduction, and green initiatives. Supporting a healthier planet for future generations.
              </p>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="mb-12 bg-slate-50 rounded-lg p-8">
          <h2 className="text-3xl font-bold text-slate-900 mb-8">Why Choose Dragon Fruit SA?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex gap-4">
              <div className="text-3xl">✅</div>
              <div>
                <h4 className="font-bold text-slate-900 mb-2">Quality Assured</h4>
                <p className="text-slate-700">All products undergo rigorous quality testing and meet international standards.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl">🚚</div>
              <div>
                <h4 className="font-bold text-slate-900 mb-2">Fast Shipping</h4>
                <p className="text-slate-700">Reliable shipping with live tracking via Courier Guy and PUDO lockers.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl">💰</div>
              <div>
                <h4 className="font-bold text-slate-900 mb-2">Competitive Pricing</h4>
                <p className="text-slate-700">Best prices in ZAR and USD with transparent pricing and no hidden fees.</p>
              </div>
            </div>
            <div className="flex gap-4">
              <div className="text-3xl">🤝</div>
              <div>
                <h4 className="font-bold text-slate-900 mb-2">Expert Support</h4>
                <p className="text-slate-700">Dedicated customer support team available 24/7 via phone, email, and WhatsApp.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-8">Get in Touch</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Contact Info */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-bold text-slate-900 mb-6">Contact Information</h3>
              
              <div className="mb-6">
                <h4 className="font-bold text-slate-900 mb-2">📞 Reception & Assistant</h4>
                <p className="text-slate-700 mb-2">Our friendly reception and professionally trained assistant is ready to help with product information, pricing, and general enquiries.</p>
                <p className="text-lg font-semibold text-blue-600">+1 351 777 2848</p>
              </div>

              <div className="mb-6">
                <h4 className="font-bold text-slate-900 mb-2">⏰ After-Hours Support</h4>
                <p className="text-slate-700 mb-2">Urgent inquiries outside of standard business hours.</p>
                <p className="text-lg font-semibold text-blue-600">083 447 4639</p>
              </div>

              <div className="mb-6">
                <h4 className="font-bold text-slate-900 mb-2">💬 WhatsApp Support</h4>
                <p className="text-slate-700 mb-2">Quick messages and support via WhatsApp:</p>
                <div className="space-y-2">
                  <p className="text-lg font-semibold text-green-600">+27 83 447 4639</p>
                  <p className="text-lg font-semibold text-green-600">+1 555 708 3482</p>
                  <p className="text-lg font-semibold text-green-600">+1 555 708 3482</p>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="font-bold text-slate-900 mb-2">📧 Email</h4>
                <p className="text-lg font-semibold text-blue-600">admin@proagrisa.co.za</p>
              </div>
            </div>

            {/* Quick Contact Form */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h3 className="text-xl font-bold text-slate-900 mb-6">Quick Message</h3>
              <form className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Name</label>
                  <input
                    type="text"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Your name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Email</label>
                  <input
                    type="email"
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="your@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-900 mb-2">Message</label>
                  <textarea
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={4}
                    placeholder="Your message..."
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition"
                >
                  Send Message
                </button>
              </form>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
