# PayFast ITN Security & Workflow Presentation

## Slide 1: Title Slide
**Title:** PayFast ITN Webhook Implementation
**Subtitle:** Security Features & 9-Step Processing Workflow
**Date:** January 20, 2026
**Project:** Dragon Fruit SA E-Commerce Platform

---

## Slide 2: Agenda
**What We'll Cover:**
- PayFast ITN Overview
- Security Architecture
- 9-Step Processing Workflow
- MD5 Signature Verification
- Error Handling & Monitoring
- Deployment Checklist
- Q&A

---

## Slide 3: PayFast ITN Overview
**What is ITN?**
- Instant Transaction Notification
- Real-time webhook from PayFast to your server
- Notifies about payment status changes
- Supports retry mechanism (10 retries over 48 hours)

**Key Benefits:**
- Real-time payment confirmation
- Automatic order status updates
- Customer email notifications
- Fulfillment workflow triggering

---

## Slide 4: ITN Flow Diagram
**Customer Payment Journey:**

```
1. Customer clicks "Pay Now"
   ↓
2. Redirects to PayFast payment form
   ↓
3. Enters card details & completes payment
   ↓
4. PayFast processes payment
   ↓
5. PayFast sends ITN webhook to your server
   ↓
6. Your server verifies & processes payment
   ↓
7. Server responds with "PAYMENT_PROCESSED"
   ↓
8. Customer redirected to success page
```

---

## Slide 5: Security Architecture Overview
**Multi-Layer Security Approach:**

**Layer 1:** HTTPS Encryption
- All webhooks over HTTPS only
- TLS 1.2+ encryption

**Layer 2:** MD5 Signature Verification
- Cryptographic signature validation
- Proves PayFast origin
- Detects tampering

**Layer 3:** Data Validation
- Merchant ID verification
- Amount matching
- Order existence check

**Layer 4:** Rate Limiting & Timeout
- 100 requests per 15 minutes
- 25-second processing timeout
- Prevents abuse

**Layer 5:** Idempotency & Logging
- Duplicate detection
- Comprehensive audit trail
- Error tracking

---

## Slide 6: MD5 Signature Verification - Algorithm
**How Signature Verification Works:**

**Step 1:** Extract fields in alphabetical order
- amount_fee, amount_gross, amount_net
- custom_int1-5, custom_str1-5
- email_address, item_description, item_name
- m_payment_id, merchant_id, name_first, name_last
- pf_payment_id, payment_status

**Step 2:** Concatenate field values
- Only values, not keys
- In alphabetical order
- Skip null/undefined fields

**Step 3:** Append passphrase
- Add PayFast passphrase to end
- Passphrase: abCd15ab92g12

**Step 4:** Generate MD5 hash
- Create MD5 hash of concatenated string
- Result: 32-character hex string

**Step 5:** Compare signatures
- Compare calculated hash with provided signature
- Case-insensitive comparison
- Must match exactly

---

## Slide 7: Signature Example
**Real-World Example:**

**ITN Data:**
```
m_payment_id: 12345
pf_payment_id: 987654
payment_status: COMPLETE
amount_gross: 250.00
merchant_id: 11071120
name_first: John
name_last: Doe
email_address: john@example.com
```

**String to Sign (alphabetical):**
```
250.00987654250.00...john@example.com11071120JohnDoeCompleteabCd15ab92g12
```

**MD5 Hash Result:**
```
d41d8cd98f00b204e9800998ecf8427e
```

**Verification:**
```
Provided: d41d8cd98f00b204e9800998ecf8427e
Calculated: d41d8cd98f00b204e9800998ecf8427e
✅ VALID - Signature matches!
```

---

## Slide 8: 9-Step ITN Processing Workflow - Overview
**Complete Processing Pipeline:**

```
┌─────────────────────────────────────────────────────────┐
│ Step 1: Parse ITN Data                                  │
│ Extract form data from request body                     │
├─────────────────────────────────────────────────────────┤
│ Step 2: Log ITN Receipt                                 │
│ Record receipt for audit trail                          │
├─────────────────────────────────────────────────────────┤
│ Step 3: Verify MD5 Signature                            │
│ Cryptographic validation of PayFast origin              │
├─────────────────────────────────────────────────────────┤
│ Step 4: Verify Merchant ID                              │
│ Ensure payment is for correct merchant                  │
├─────────────────────────────────────────────────────────┤
│ Step 5: Verify Amount Matches Order                     │
│ Prevent payment manipulation                            │
├─────────────────────────────────────────────────────────┤
│ Step 6: Check for Duplicate Processing                  │
│ Idempotency - prevent double charging                   │
├─────────────────────────────────────────────────────────┤
│ Step 7: Process Payment Based on Status                 │
│ COMPLETE, FAILED, PENDING, CANCELLED                    │
├─────────────────────────────────────────────────────────┤
│ Step 8: Store ITN in Database                           │
│ Audit trail for compliance                              │
├─────────────────────────────────────────────────────────┤
│ Step 9: Return Success Response                         │
│ HTTP 200 to stop PayFast retries                        │
└─────────────────────────────────────────────────────────┘
```

---

## Slide 9: Step 1 - Parse ITN Data
**Objective:** Extract and structure ITN payload

**Input:**
- Raw form data from PayFast
- URL-encoded POST body

**Processing:**
```
Parse URL-encoded data
↓
Convert to key-value pairs
↓
Type conversion (numbers, decimals)
↓
Structured object
```

**Output:**
```javascript
{
  m_payment_id: "12345",
  pf_payment_id: 987654,
  payment_status: "COMPLETE",
  amount_gross: 250.00,
  merchant_id: "11071120",
  signature: "d41d8cd98f00b204e9800998ecf8427e",
  ...
}
```

**Error Handling:**
- Handle malformed data gracefully
- Log parsing errors
- Return HTTP 200 to prevent retries

---

## Slide 10: Step 2 - Log ITN Receipt
**Objective:** Create audit trail for compliance

**Information Logged:**
- Order ID
- Payment ID
- Payment status
- Amount
- Timestamp
- Request metadata

**Logging Example:**
```
[INFO] ITN received
{
  orderId: "12345",
  paymentId: "987654",
  status: "COMPLETE",
  amount: "250.00",
  timestamp: "2026-01-20T10:30:45Z"
}
```

**Purpose:**
- Audit trail for PCI DSS compliance
- Troubleshooting and debugging
- Monitoring and analytics
- Fraud detection

---

## Slide 11: Step 3 - Verify MD5 Signature
**Objective:** Prove ITN came from PayFast and wasn't tampered

**Verification Process:**
1. Extract all ITN fields
2. Sort alphabetically
3. Concatenate values
4. Append passphrase
5. Calculate MD5 hash
6. Compare with provided signature

**Security Impact:**
- ✅ Prevents spoofed webhooks
- ✅ Detects data tampering
- ✅ Cryptographically secure
- ✅ Industry standard (MD5)

**Failure Action:**
- Log signature mismatch
- Return HTTP 200 (don't retry)
- Alert admin
- Store for manual review

---

## Slide 12: Step 4 - Verify Merchant ID
**Objective:** Ensure payment is for correct merchant

**Check:**
```
Provided Merchant ID: 11071120
Expected Merchant ID: 11071120
Status: ✅ MATCH
```

**Why Important:**
- Prevents payment misrouting
- Ensures correct account receives payment
- Multi-tenant security

**Failure Action:**
- Log merchant ID mismatch
- Return HTTP 200 (don't retry)
- Alert admin
- Investigate potential fraud

---

## Slide 13: Step 5 - Verify Amount Matches Order
**Objective:** Prevent payment manipulation attacks

**Verification:**
```
ITN Amount: R250.00
Order Total: R250.00
Difference: R0.00
Status: ✅ MATCH (tolerance: ±R0.01)
```

**Why Important:**
- Prevents underpayment attacks
- Detects payment manipulation
- Ensures correct order fulfillment

**Failure Action:**
- Log amount mismatch
- Return HTTP 200 (don't retry)
- Alert admin
- Investigate potential fraud

---

## Slide 14: Step 6 - Check for Duplicate Processing
**Objective:** Implement idempotency - prevent double charging

**Mechanism:**
```
Received Payment ID: 987654
↓
Check database for existing payment
↓
Found: Already processed ✅
↓
Return success (prevent retries)
```

**Why Important:**
- PayFast retries ITN up to 10 times
- Network issues cause duplicates
- Idempotency prevents double charges

**Implementation:**
- Use payment ID as unique key
- Check database before processing
- Cache results for 24 hours

---

## Slide 15: Step 7 - Process Payment Based on Status
**Objective:** Update order and trigger workflows

**Payment Status Handlers:**

**COMPLETE** → Successful Payment
- Update order status to "paid"
- Send confirmation email
- Trigger fulfillment workflow
- Update inventory

**FAILED** → Payment Failed
- Update order status to "failed"
- Send failure notification
- Allow customer to retry
- Release inventory hold

**PENDING** → Awaiting Confirmation
- Update order status to "pending"
- Send pending notification
- Wait for confirmation
- Hold inventory

**CANCELLED** → Payment Cancelled
- Update order status to "cancelled"
- Send cancellation notification
- Release inventory
- Allow customer to retry

---

## Slide 16: Step 8 - Store ITN in Database
**Objective:** Create permanent audit trail

**Data Stored:**
```
{
  payment_method: "payfast",
  webhook_id: "987654",
  event_type: "payment.complete",
  payload: { ...full ITN data... },
  processed: true,
  processed_at: "2026-01-20T10:30:45Z"
}
```

**Why Important:**
- PCI DSS compliance requirement
- Audit trail for disputes
- Troubleshooting and debugging
- Regulatory requirements
- Fraud investigation

**Retention:**
- Keep for minimum 7 years
- Encrypted storage
- Access controlled

---

## Slide 17: Step 9 - Return Success Response
**Objective:** Signal to PayFast that webhook was processed

**Response:**
```
HTTP 200 OK
{
  success: true,
  message: "PAYMENT_PROCESSED"
}
```

**Why Important:**
- Tells PayFast to stop retrying
- Prevents duplicate processing
- Confirms receipt
- Stops retry timer

**Failure Response:**
```
HTTP 200 OK (always return 200)
{
  success: false,
  error: "Signature verification failed"
}
```

**Note:** Always return HTTP 200, even on errors
- Prevents PayFast from retrying
- Allows manual review later

---

## Slide 18: Security Features Summary
**Key Security Layers:**

**1. HTTPS Encryption**
- All webhooks over HTTPS
- TLS 1.2+ encryption
- Protects data in transit

**2. MD5 Signature Verification**
- Cryptographic validation
- Proves PayFast origin
- Detects tampering

**3. Merchant ID Verification**
- Ensures correct merchant
- Prevents misrouting
- Multi-tenant security

**4. Amount Verification**
- Prevents underpayment
- Detects manipulation
- Ensures correct fulfillment

**5. Duplicate Detection**
- Idempotency implementation
- Prevents double charging
- Handles retries safely

**6. Rate Limiting**
- 100 requests per 15 minutes
- Prevents abuse
- Protects server

**7. Timeout Protection**
- 25-second processing limit
- Prevents hanging requests
- Ensures responsiveness

**8. Comprehensive Logging**
- Audit trail creation
- Error tracking
- Compliance documentation

**9. Error Handling**
- Graceful failure
- Dead letter queue
- Manual review process

---

## Slide 19: Retry Mechanism
**PayFast Retry Schedule:**

If your server doesn't respond with HTTP 200, PayFast retries:

```
Attempt 1: Immediate
Attempt 2: 5 minutes later
Attempt 3: 15 minutes later
Attempt 4: 30 minutes later
Attempt 5: 1 hour later
Attempt 6: 2 hours later
Attempt 7: 4 hours later
Attempt 8: 8 hours later
Attempt 9: 16 hours later
Attempt 10: 24 hours later
```

**Total Window:** 48 hours
**Maximum Retries:** 10 attempts

**Why This Matters:**
- Ensures payment processing
- Handles temporary outages
- Network resilience
- Idempotency prevents duplicates

---

## Slide 20: Error Handling Strategy
**Multi-Level Error Handling:**

**Level 1: Validation Errors**
- Log error
- Return HTTP 200
- Store in database
- Alert admin

**Level 2: Processing Errors**
- Retry with exponential backoff
- 1s, 5s, 15s delays
- Maximum 3 retries
- Dead letter queue after

**Level 3: Critical Errors**
- Send admin alert immediately
- Store for manual review
- Create support ticket
- Escalate to team

**Dead Letter Queue:**
- Failed webhooks stored
- Manual processing available
- Audit trail maintained
- Recovery mechanism

---

## Slide 21: Monitoring & Alerting
**Real-Time Monitoring:**

**Metrics Tracked:**
- Total ITN received
- Successfully processed
- Failed processing
- Average processing time
- Success rate percentage

**Alert Thresholds:**
- Success rate < 95% → Warning
- Failed count > 10 → Critical
- Processing time > 20s → Warning
- Signature failures > 5 → Critical

**Monitoring Dashboard:**
- Real-time metrics
- Historical trends
- Failure analysis
- Performance graphs

---

## Slide 22: Testing Strategy
**Comprehensive Testing Approach:**

**Unit Tests:**
- Signature verification (5 tests)
- Field parsing
- Error handling
- Edge cases

**Integration Tests:**
- End-to-end workflow
- Database updates
- Email notifications
- Status transitions

**Manual Testing:**
- Valid signature ITN
- Invalid signature ITN
- Amount mismatch
- Duplicate processing
- All payment statuses
- Timeout handling
- Error scenarios

---

## Slide 23: Deployment Checklist
**Pre-Deployment Verification:**

- [ ] Webhook URL registered in PayFast
- [ ] HTTPS certificate installed
- [ ] Database migrations applied
- [ ] Environment variables configured
- [ ] Rate limiting configured
- [ ] Monitoring set up
- [ ] Logging configured
- [ ] Error handling tested
- [ ] Timeout protection implemented
- [ ] Idempotency in place
- [ ] Email templates created
- [ ] Admin alerts configured
- [ ] Backup procedures tested
- [ ] Team trained

---

## Slide 24: Troubleshooting Guide
**Common Issues & Solutions:**

**Issue 1: Signature Verification Fails**
- Check passphrase matches
- Verify field order (alphabetical)
- Exclude null fields
- Use case-insensitive comparison

**Issue 2: ITN Not Received**
- Verify webhook URL registered
- Check firewall rules
- Ensure HTTP 200 response
- Optimize processing time

**Issue 3: Duplicate Processing**
- Implement idempotency check
- Use database transaction
- Add unique constraint
- Check cache

**Issue 4: Email Not Sent**
- Verify email service running
- Check template files
- Test SMTP connection
- Review email logs

---

## Slide 25: Production Readiness Checklist
**Before Going Live:**

**Security:**
- ✅ HTTPS enforced
- ✅ Signature verification working
- ✅ Rate limiting active
- ✅ Timeout protection enabled
- ✅ Logging comprehensive

**Functionality:**
- ✅ All payment statuses handled
- ✅ Email notifications working
- ✅ Order status updates correct
- ✅ Inventory management working
- ✅ Fulfillment triggered

**Reliability:**
- ✅ Error handling tested
- ✅ Retry logic working
- ✅ Idempotency verified
- ✅ Monitoring active
- ✅ Alerts configured

**Compliance:**
- ✅ PCI DSS compliant
- ✅ Audit trail created
- ✅ Data encrypted
- ✅ Access controlled
- ✅ Backups tested

---

## Slide 26: Key Takeaways
**Summary of Critical Points:**

1. **Security First**
   - Multi-layer security approach
   - MD5 signature verification
   - Comprehensive validation

2. **9-Step Workflow**
   - Parse → Log → Verify → Process → Store → Respond
   - Each step critical
   - No shortcuts

3. **Idempotency**
   - Handle retries safely
   - Prevent double charging
   - Use payment ID as key

4. **Error Handling**
   - Always return HTTP 200
   - Log everything
   - Manual review process

5. **Monitoring**
   - Real-time metrics
   - Alert thresholds
   - Proactive monitoring

---

## Slide 27: Next Steps
**Implementation Roadmap:**

**Phase 1: Development (Week 1)**
- Implement signature verification
- Build webhook handler
- Write unit tests

**Phase 2: Integration (Week 2)**
- Integrate with payment service
- Connect to order system
- Test email notifications

**Phase 3: Testing (Week 3)**
- Unit test coverage
- Integration testing
- Manual testing
- Security audit

**Phase 4: Deployment (Week 4)**
- Staging deployment
- Register webhook URL
- Production deployment
- Monitoring setup

---

## Slide 28: Questions & Discussion
**Q&A Session**

Topics for Discussion:
- Implementation approach
- Timeline and resources
- Testing strategy
- Monitoring setup
- Deployment plan
- Risk mitigation
- Support and maintenance

**Contact Information:**
- Technical Lead: [Name]
- Project Manager: [Name]
- Support Email: support@proagrisa.co.za

---

## Slide 29: Appendix - MD5 Signature Code
**TypeScript Implementation:**

```typescript
function verifyPayFastSignature(
  itnData: Record<string, any>,
  signature: string,
  passphrase: string
): boolean {
  const signatureFields = [
    'amount_fee', 'amount_gross', 'amount_net',
    'custom_int1', 'custom_int2', 'custom_int3',
    'custom_int4', 'custom_int5', 'custom_str1',
    'custom_str2', 'custom_str3', 'custom_str4',
    'custom_str5', 'email_address', 'item_description',
    'item_name', 'm_payment_id', 'merchant_id',
    'name_first', 'name_last', 'pf_payment_id',
    'payment_status'
  ];

  let stringToSign = '';
  for (const field of signatureFields) {
    if (field in itnData && itnData[field]) {
      stringToSign += String(itnData[field]);
    }
  }
  stringToSign += passphrase;

  const crypto = require('crypto');
  const calculatedSignature = crypto
    .createHash('md5')
    .update(stringToSign)
    .digest('hex');

  return calculatedSignature.toLowerCase() === 
         signature.toLowerCase();
}
```

---

## Slide 30: Thank You
**Thank You for Your Attention**

**Project:** Dragon Fruit SA E-Commerce Platform
**Document:** PayFast ITN Security & Workflow
**Date:** January 20, 2026

**Questions?**

Contact: [Project Team]
Email: support@proagrisa.co.za
