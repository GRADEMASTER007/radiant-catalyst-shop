# Environment Configuration Guide

This document explains all environment variables required for the Dragon Fruit SA e-commerce platform.

## ⚠️ Important Security Notes

- **Never commit `.env` to version control**
- **All API keys and passwords must be kept secret**
- **Use strong, unique passwords for all services**
- **Rotate API keys regularly**
- **Use HTTPS in production**

## Database Configuration

```
DATABASE_URL=mysql://username:password@localhost:3306/dragon_fruit_db
```

- **Host:** Your MySQL/TiDB server
- **Port:** 3306 (default MySQL port)
- **Database:** Create a new database for this project
- **User:** Database user with full permissions
- **Password:** Strong, unique password

## Admin Authentication

```
ADMIN_USERNAME=admin
ADMIN_PASSWORD=change_this_password
```

- **Username:** Admin login username
- **Password:** Strong password (min 12 characters, mix of upper/lower/numbers/symbols)

## AI Providers

### OpenRouter

```
OPENROUTER_API_KEY=sk-or-v1-your-api-key-here
OPENROUTER_BASE_URL=https://openrouter.ai/api/v1
```

- Get API key from: https://openrouter.ai/keys
- Supports 11+ AI models
- Free tier available

### Ollama Cloud

```
OLLAMA_CLOUD_API_KEY=your-ollama-cloud-key
OLLAMA_CLOUD_URL=https://ollama.com/api
```

- Get API key from: https://ollama.com
- High-quality responses
- Included with account

### Ollama Local

```
OLLAMA_LOCAL_URL=http://localhost:11434/api
```

- Run locally for free responses
- No API key required
- Requires local Ollama installation

### Kilo Code

```
KILO_CODE_JWT=your-kilo-code-jwt-token
KILO_CODE_API_URL=https://api.kilo.dev
```

- Specialized code generation
- Get JWT token from: https://kilo.dev

## Search & SEO - SerpAPI

```
SERPAPI_API_KEY=your-serpapi-key
```

- Get API key from: https://serpapi.com
- Used for keyword research and SEO optimization
- Free tier: 100 searches/month

## Payment Gateways

### PayFast (South African Market)

```
PAYFAST_MERCHANT_ID=11071120
PAYFAST_MERCHANT_KEY=p6fi9ewdjk1js
PAYFAST_PASSPHRASE=abCd15ab92g12
PAYFAST_DEBUG_EMAIL=waterkefirsa@gmail.com
PAYFAST_ENVIRONMENT=live
```

- **Environment:** Set to `live` for production, `sandbox` for testing
- **Merchant ID:** Your PayFast merchant ID
- **Merchant Key:** Your PayFast merchant key
- **Passphrase:** Security passphrase (used for MD5 signatures)
- **Debug Email:** Email for test transactions

### Yoco

```
YOCO_API_KEY=yoco_live_1be907c4ffe80376_3f05d1d6503c605b73555b677b80697f
YOCO_PUBLIC_KEY=pk_live_b21ac3bd1WM6WRY3f9f4
YOCO_SECRET_KEY=sk_live_87380fcbgEgAEJa48704613a39ec
YOCO_ENVIRONMENT=live
```

- **Environment:** Set to `live` for production, `sandbox` for testing
- **API Key:** Your Yoco API key
- **Public Key:** Your Yoco public key (for frontend)
- **Secret Key:** Your Yoco secret key (backend only)

## Shipping Providers

### Courier Guy

```
COURIER_GUY_API_KEY=e28f9909fa734d0a8ce9641c8db68c9f
COURIER_GUY_ALTERNATE_KEY=c720aa50a628477e83bd74a0cb46cf9e
COURIER_GUY_BASE_URL=https://api.thecourierguy.co.za
```

- **Primary Key:** Main API key
- **Alternate Key:** Backup API key (for failover)
- **Base URL:** Courier Guy API endpoint

### PUDO

```
PUDO_API_KEY=51577192|tCQuvbHTuSMgUYgb1Bqh5IEG48DbXXkHF6yBGQYN02422ea5
PUDO_BASE_URL=https://api.pudo.co.za
```

- **API Key:** Your PUDO account key
- **Base URL:** PUDO API endpoint

## Email Configuration

### SMTP (for sending emails)

```
SMTP_HOST=mail.proagrisa.co.za
SMTP_PORT=465
SMTP_SECURE=true
SMTP_USER=orders@proagrisa.co.za
SMTP_PASSWORD=Kyknet.01
SMTP_FROM_EMAIL=orders@proagrisa.co.za
SMTP_FROM_NAME=Dragon Fruit SA
```

- **Host:** Your email server hostname
- **Port:** 465 (SSL/TLS), 587 (STARTTLS), or 25 (unencrypted)
- **Secure:** true for SSL/TLS, false for unencrypted
- **User:** Email account username
- **Password:** Email account password
- **From Email:** Email address to send from
- **From Name:** Display name for sent emails

### IMAP (for reading emails)

```
IMAP_HOST=mail.proagrisa.co.za
IMAP_PORT=993
IMAP_SECURE=true
IMAP_USER=orders@proagrisa.co.za
IMAP_PASSWORD=Kyknet.01
```

- **Host:** Your email server hostname
- **Port:** 993 (SSL/TLS) or 143 (unencrypted)
- **Secure:** true for SSL/TLS, false for unencrypted
- **User:** Email account username
- **Password:** Email account password

### POP3 (alternative for reading emails)

```
POP3_HOST=mail.proagrisa.co.za
POP3_PORT=995
POP3_SECURE=true
POP3_USER=orders@proagrisa.co.za
POP3_PASSWORD=Kyknet.01
```

- **Host:** Your email server hostname
- **Port:** 995 (SSL/TLS) or 110 (unencrypted)
- **Secure:** true for SSL/TLS, false for unencrypted
- **User:** Email account username
- **Password:** Email account password

### CalDAV (Calendar Integration)

```
CALDAV_URL=https://mail.proagrisa.co.za:2080/calendars/orders@proagrisa.co.za/calendar
CALDAV_PORT=2080
CALDAV_USER=orders@proagrisa.co.za
CALDAV_PASSWORD=Kyknet.01
```

- **URL:** Calendar endpoint URL
- **Port:** Usually 2080 or 8080
- **User:** Email account username
- **Password:** Email account password

### CardDAV (Contacts Integration)

```
CARDDAV_URL=https://mail.proagrisa.co.za:2080/addressbooks/orders@proagrisa.co.za/addressbook
CARDDAV_PORT=2080
CARDDAV_USER=orders@proagrisa.co.za
CARDDAV_PASSWORD=Kyknet.01
```

- **URL:** Contacts endpoint URL
- **Port:** Usually 2080 or 8080
- **User:** Email account username
- **Password:** Email account password

### Email Analytics

```
EMAIL_ANALYTICS_ID=b5765510-fee8-48e4-b07f-e2f892f0dc55
```

- Unique identifier for email analytics tracking
- Used to track email performance metrics

## GitHub Integration

### Fine-Grained Personal Access Token

```
GITHUB_TOKEN_FINE_GRAINED=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
```

- Get from: https://github.com/settings/tokens?type=beta
- Permissions: `repo`, `workflow`, `admin:repo_hook`
- Expiration: Set to 90 days for security

### Classic Personal Access Token

```
GITHUB_TOKEN_CLASSIC=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
```

- Get from: https://github.com/settings/tokens
- Scopes: `repo`, `workflow`, `admin:repo_hook`
- Expiration: Set to 90 days for security

## Business Configuration

```
BUSINESS_NAME=Dragon Fruit SA
BUSINESS_EMAIL=admin@proagrisa.co.za
BUSINESS_PHONE=+1 351 777 2848
BUSINESS_PHONE_AFTER_HOURS=083 447 4639
BUSINESS_WHATSAPP_1=+27 83 447 4639
BUSINESS_WHATSAPP_2=+1 555 708 3482
```

- **Name:** Your business name
- **Email:** Primary business email
- **Phone:** Main business phone number
- **After-Hours Phone:** Emergency contact number
- **WhatsApp:** WhatsApp contact numbers

## Currency Configuration

```
PRIMARY_CURRENCY=ZAR
SECONDARY_CURRENCY=USD
CURRENCY_CONVERSION_API=openexchangerates
```

- **Primary Currency:** Main currency (ZAR for South Africa)
- **Secondary Currency:** Alternative currency (USD for international)
- **Conversion API:** Service for real-time currency conversion

## Multi-Tenant Configuration

```
MULTI_TENANT_ENABLED=true
TENANT_ID=default
TENANT_NAME=Dragon Fruit SA
```

- **Enabled:** true to enable multi-tenant mode
- **Tenant ID:** Unique identifier for this tenant
- **Tenant Name:** Display name for this tenant

## Application Settings

```
NODE_ENV=production
PORT=3000
LOG_LEVEL=info
```

- **NODE_ENV:** `production`, `staging`, or `development`
- **PORT:** Server port (default 3000)
- **LOG_LEVEL:** `error`, `warn`, `info`, `debug`, or `trace`

## Security Settings

```
JWT_SECRET=your-super-secret-jwt-key-change-this
SESSION_SECRET=your-super-secret-session-key-change-this
SECURE_COOKIES=true
CORS_ORIGIN=https://yourdomain.com
```

- **JWT_SECRET:** Secret key for JWT tokens (min 32 characters)
- **SESSION_SECRET:** Secret key for session cookies (min 32 characters)
- **SECURE_COOKIES:** true for HTTPS only, false for development
- **CORS_ORIGIN:** Allowed origin for CORS requests

## Feature Flags

```
FEATURE_AI_CHATBOT=true
FEATURE_PAYMENT_PAYFAST=true
FEATURE_PAYMENT_YOCO=true
FEATURE_SHIPPING_COURIER_GUY=true
FEATURE_SHIPPING_PUDO=true
FEATURE_EMAIL_NOTIFICATIONS=true
FEATURE_SEO_OPTIMIZATION=true
```

- Set to `true` to enable, `false` to disable
- Useful for gradual rollout of features
- Can be changed without redeploying code

## Development Settings

```
# DEBUG_MODE=false
# MOCK_PAYMENTS=false
# MOCK_SHIPPING=false
```

- **DEBUG_MODE:** Enable detailed logging
- **MOCK_PAYMENTS:** Use mock payment responses (testing only)
- **MOCK_SHIPPING:** Use mock shipping responses (testing only)

---

## Setup Instructions

### 1. Create .env File

```bash
cp .env.example .env
```

### 2. Fill in Required Variables

Edit `.env` and fill in all required values:

```bash
nano .env
```

### 3. Test Database Connection

```bash
pnpm db:push
```

### 4. Initialize Admin User

```bash
node scripts/init-admin.mjs
```

### 5. Start Application

```bash
pnpm dev
```

---

## Troubleshooting

### Database Connection Failed

- Check `DATABASE_URL` is correct
- Verify database server is running
- Check username and password
- Ensure database exists

### Email Not Sending

- Check SMTP credentials
- Verify SMTP port (465 for SSL, 587 for STARTTLS)
- Check firewall allows SMTP port
- Verify email account is not locked

### Payment Gateway Errors

- Check API keys are correct
- Verify environment is set to `live` or `sandbox`
- Check IP address is whitelisted (if required)
- Verify merchant account is active

### AI Provider Errors

- Check API keys are valid
- Verify API endpoints are accessible
- Check rate limits haven't been exceeded
- Verify account has sufficient credits

---

## Security Best Practices

1. **Never commit `.env` to version control**
2. **Use strong, unique passwords**
3. **Rotate API keys every 90 days**
4. **Use HTTPS in production**
5. **Enable 2FA on all accounts**
6. **Monitor API usage for suspicious activity**
7. **Use environment-specific API keys**
8. **Restrict IP addresses where possible**
9. **Keep dependencies updated**
10. **Regular security audits**

---

## Support

For help with environment setup, refer to:

- Service documentation (PayFast, Yoco, Courier Guy, PUDO)
- Email provider documentation
- GitHub documentation
- OpenRouter documentation

---

**Last Updated:** January 21, 2026
