import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';

interface AIProvider {
  value: string;
  label: string;
  type: string;
  costPerKToken?: number;
  enabled: boolean;
}

interface AIModel {
  value: string;
  label: string;
  provider: string;
  costPerKToken?: number;
}

interface AIResponse {
  content: string;
  model: string;
  provider: string;
  tokensUsed: number;
  costUSD: number;
  timestamp: string;
  fallbackAttempts?: number;
}

interface HistoryItem {
  id: string;
  prompt: string;
  response: string;
  model: string;
  provider: string;
  tokensUsed: number;
  costUSD: number;
  timestamp: string;
}

export default function AdminAIEnhanced() {
  const [, setLocation] = useLocation();
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState('openrouter');
  const [selectedModel, setSelectedModel] = useState('mistralai/devstral-2512:free');
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(2000);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [totalCost, setTotalCost] = useState(0);
  const [totalTokens, setTotalTokens] = useState(0);
  const [providerStats, setProviderStats] = useState<Record<string, any>>({});
  const [taskType, setTaskType] = useState<'chat' | 'feature' | 'search' | 'code' | 'image'>('chat');

  // All 20 AI providers
  const aiProviders: AIProvider[] = [
    { value: 'openrouter', label: 'OpenRouter (11 Free)', type: 'chat', enabled: true },
    { value: 'groq', label: 'Groq (Fast)', type: 'chat', enabled: true },
    { value: 'qwen', label: 'Qwen (Alibaba)', type: 'chat', enabled: true },
    { value: 'perplexity', label: 'Perplexity (Search)', type: 'chat', enabled: true },
    { value: 'apifree', label: 'ApiFree (Free)', type: 'chat', enabled: true },
    { value: 'huggingface', label: 'Hugging Face', type: 'feature', enabled: true },
    { value: 'gemini', label: 'Google Gemini', type: 'chat', enabled: true },
    { value: 'aicc', label: 'AI.CC (Chinese)', type: 'chat', enabled: true },
    { value: 'requesty', label: 'Requesty', type: 'chat', enabled: true },
    { value: 'ollamaCloud', label: 'Ollama Cloud', type: 'chat', enabled: true },
    { value: 'straico', label: 'Straico', type: 'chat', enabled: true },
    { value: 'mistral', label: 'Mistral', type: 'chat', enabled: true },
    { value: 'anthropic', label: 'Anthropic Claude', type: 'chat', enabled: true },
    { value: 'togetherai', label: 'Together AI', type: 'chat', enabled: true },
    { value: 'xai', label: 'xAI Grok', type: 'chat', enabled: true },
    { value: 'openai', label: 'OpenAI GPT', type: 'chat', enabled: true },
    { value: 'freeplayai', label: 'Freeplay.ai', type: 'chat', enabled: true },
    { value: 'clarifai', label: 'Clarifai', type: 'feature', enabled: true },
    { value: 'cerebras', label: 'Cerebras', type: 'chat', enabled: true },
    { value: 'oneminai', label: '1min.ai', type: 'chat', enabled: true },
  ];

  // Models for each provider
  const modelsByProvider: Record<string, AIModel[]> = {
    openrouter: [
      { value: 'mistralai/devstral-2512:free', label: 'Mistral Devstral (Free)', provider: 'openrouter' },
      { value: 'qwen/qwen3-next-80b-a3b-instruct:free', label: 'Qwen 3 Next 80B (Free)', provider: 'openrouter' },
      { value: 'deepseek/deepseek-r1-0528:free', label: 'DeepSeek R1 (Free)', provider: 'openrouter' },
      { value: 'meta-llama/llama-3.2-3b-instruct:free', label: 'Llama 3.2 3B (Free)', provider: 'openrouter' },
      { value: 'nvidia/nemotron-3-nano-30b-a3b:free', label: 'Nvidia Nemotron (Free)', provider: 'openrouter' },
      { value: 'mistralai/mistral-7b-instruct', label: 'Mistral 7B', provider: 'openrouter' },
    ],
    groq: [
      { value: 'mixtral-8x7b-32768', label: 'Mixtral 8x7B', provider: 'groq' },
      { value: 'llama2-70b-4096', label: 'Llama 2 70B', provider: 'groq' },
      { value: 'gemma-7b-it', label: 'Gemma 7B', provider: 'groq' },
    ],
    qwen: [
      { value: 'qwen-turbo', label: 'Qwen Turbo', provider: 'qwen' },
      { value: 'qwen-plus', label: 'Qwen Plus', provider: 'qwen' },
      { value: 'qwen-long', label: 'Qwen Long', provider: 'qwen' },
    ],
    perplexity: [
      { value: 'pplx-7b-online', label: 'Perplexity 7B Online', provider: 'perplexity' },
      { value: 'pplx-70b-online', label: 'Perplexity 70B Online', provider: 'perplexity' },
      { value: 'pplx-8x7b-online', label: 'Perplexity 8x7B Online', provider: 'perplexity' },
    ],
    apifree: [
      { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo', provider: 'apifree' },
      { value: 'claude-2', label: 'Claude 2', provider: 'apifree' },
      { value: 'llama-2-70b', label: 'Llama 2 70B', provider: 'apifree' },
    ],
    huggingface: [
      { value: 'mistralai/Mistral-7B-Instruct-v0.1', label: 'Mistral 7B', provider: 'huggingface' },
      { value: 'meta-llama/Llama-2-7b-chat-hf', label: 'Llama 2 7B', provider: 'huggingface' },
      { value: 'tiiuae/falcon-7b-instruct', label: 'Falcon 7B', provider: 'huggingface' },
    ],
    gemini: [
      { value: 'gemini-pro', label: 'Gemini Pro', provider: 'gemini', costPerKToken: 0.0005 },
      { value: 'gemini-pro-vision', label: 'Gemini Pro Vision', provider: 'gemini', costPerKToken: 0.0005 },
      { value: 'gemini-1.5-pro', label: 'Gemini 1.5 Pro', provider: 'gemini', costPerKToken: 0.0005 },
    ],
    anthropic: [
      { value: 'claude-3-opus-20240229', label: 'Claude 3 Opus', provider: 'anthropic', costPerKToken: 0.003 },
      { value: 'claude-3-sonnet-20240229', label: 'Claude 3 Sonnet', provider: 'anthropic', costPerKToken: 0.003 },
      { value: 'claude-3-haiku-20240307', label: 'Claude 3 Haiku', provider: 'anthropic', costPerKToken: 0.0008 },
    ],
    openai: [
      { value: 'gpt-4-turbo-preview', label: 'GPT-4 Turbo', provider: 'openai', costPerKToken: 0.001 },
      { value: 'gpt-4', label: 'GPT-4', provider: 'openai', costPerKToken: 0.003 },
      { value: 'gpt-3.5-turbo', label: 'GPT-3.5 Turbo', provider: 'openai', costPerKToken: 0.0005 },
    ],
    mistral: [
      { value: 'mistral-small', label: 'Mistral Small', provider: 'mistral', costPerKToken: 0.0002 },
      { value: 'mistral-medium', label: 'Mistral Medium', provider: 'mistral', costPerKToken: 0.0003 },
      { value: 'mistral-large', label: 'Mistral Large', provider: 'mistral', costPerKToken: 0.0008 },
    ],
    togetherai: [
      { value: 'meta-llama/Llama-2-70b-chat-hf', label: 'Llama 2 70B', provider: 'togetherai' },
      { value: 'mistralai/Mistral-7B-Instruct-v0.1', label: 'Mistral 7B', provider: 'togetherai' },
      { value: 'NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO', label: 'Nous Hermes 2 Mixtral', provider: 'togetherai' },
    ],
  };

  const quickPrompts = [
    '📝 Write a compelling product description for an e-commerce item',
    '🔍 Generate SEO metadata and keywords for a webpage',
    '💻 Generate TypeScript code for a React component with hooks',
    '🎨 Suggest CSS improvements and modern design patterns',
    '📊 Analyze and summarize business data insights',
    '🌍 Translate content to multiple languages',
    '📧 Draft a professional email response',
    '🎯 Create a marketing campaign outline',
    '🔧 Debug and explain this code error',
    '📚 Summarize a long document or article',
  ];

  const taskTypes = [
    { value: 'chat', label: '💬 Chat', description: 'General conversation' },
    { value: 'feature', label: '⚙️ Feature', description: 'Specialized tasks' },
    { value: 'search', label: '🔍 Search', description: 'Web search' },
    { value: 'code', label: '💻 Code', description: 'Code generation' },
    { value: 'image', label: '🖼️ Image', description: 'Image generation' },
  ];

  // Get available models for selected provider
  const availableModels = modelsByProvider[selectedProvider] || [];

  // Update selected model when provider changes
  useEffect(() => {
    if (availableModels.length > 0) {
      setSelectedModel(availableModels[0].value);
    }
  }, [selectedProvider]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) {
      alert('Please enter a prompt');
      return;
    }

    if (prompt.length > 10000) {
      alert('Prompt is too long (max 10,000 characters)');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/trpc/ai.query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          type: taskType,
          model: selectedModel,
          service: selectedProvider,
          temperature,
          maxTokens,
        }),
      });

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      const data = await res.json();
      const aiResponse: AIResponse = data.result?.data || {
        content: 'No response received',
        model: selectedModel,
        provider: selectedProvider,
        tokensUsed: 0,
        costUSD: 0,
        timestamp: new Date().toISOString(),
      };

      setResponse(aiResponse.content);

      // Add to history
      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        prompt,
        response: aiResponse.content,
        model: aiResponse.model,
        provider: aiResponse.provider,
        tokensUsed: aiResponse.tokensUsed,
        costUSD: aiResponse.costUSD,
        timestamp: aiResponse.timestamp,
      };

      setHistory([historyItem, ...history.slice(0, 19)]);
      setTotalCost(totalCost + aiResponse.costUSD);
      setTotalTokens(totalTokens + aiResponse.tokensUsed);

      // Update provider stats
      setProviderStats({
        ...providerStats,
        [selectedProvider]: {
          requests: (providerStats[selectedProvider]?.requests || 0) + 1,
          totalCost: (providerStats[selectedProvider]?.totalCost || 0) + aiResponse.costUSD,
          totalTokens: (providerStats[selectedProvider]?.totalTokens || 0) + aiResponse.tokensUsed,
        },
      });
    } catch (error) {
      setResponse(`Error: ${error instanceof Error ? error.message : 'Failed to get response from AI service'}`);
    } finally {
      setLoading(false);
    }
  };

  const handleQuickPrompt = (quickPrompt: string) => {
    setPrompt(quickPrompt);
  };

  const handleCopyResponse = () => {
    if (response) {
      navigator.clipboard.writeText(response);
      alert('Response copied to clipboard!');
    }
  };

  const handleClearHistory = () => {
    if (confirm('Are you sure you want to clear all history?')) {
      setHistory([]);
      setTotalCost(0);
      setTotalTokens(0);
      setProviderStats({});
    }
  };

  const handleGoBack = () => {
    setLocation('/admin/dashboard');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={handleGoBack}
            className="mb-4 px-4 py-2 text-slate-600 hover:text-slate-900 transition flex items-center gap-2"
          >
            ← Back to Dashboard
          </button>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">🤖 AI Assistant Hub</h1>
          <p className="text-slate-600">Generate content, code, and insights with 20+ AI providers</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Main Content - Left Side (3 columns) */}
          <div className="lg:col-span-3 space-y-6">
            {/* Task Type Selection */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <label className="block text-sm font-semibold text-slate-700 mb-4">Task Type</label>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                {taskTypes.map((type) => (
                  <button
                    key={type.value}
                    onClick={() => setTaskType(type.value as any)}
                    className={`p-3 rounded-lg transition text-center text-sm font-medium ${
                      taskType === type.value
                        ? 'bg-blue-500 text-white shadow-md'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <div>{type.label.split(' ')[0]}</div>
                    <div className="text-xs opacity-75">{type.label.split(' ').slice(1).join(' ')}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Provider & Model Selection */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">AI Provider (20 options)</label>
                  <select
                    value={selectedProvider}
                    onChange={(e) => setSelectedProvider(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    {aiProviders.map((provider) => (
                      <option key={provider.value} value={provider.value}>
                        {provider.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Model</label>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
                  >
                    {availableModels.map((model) => (
                      <option key={model.value} value={model.value}>
                        {model.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Temperature & Max Tokens */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">
                    Temperature: {temperature.toFixed(2)}
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="2"
                    step="0.1"
                    value={temperature}
                    onChange={(e) => setTemperature(parseFloat(e.target.value))}
                    className="w-full"
                  />
                  <p className="text-xs text-slate-500 mt-1">0=deterministic, 2=creative</p>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-2">Max Tokens: {maxTokens}</label>
                  <input
                    type="range"
                    min="100"
                    max="4000"
                    step="100"
                    value={maxTokens}
                    onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                    className="w-full"
                  />
                  <p className="text-xs text-slate-500 mt-1">Response length limit</p>
                </div>
              </div>
            </div>

            {/* Prompt Input - Large Text Area */}
            <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-6">
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Prompt (up to 10,000 characters) - {prompt.length}/10,000
              </label>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value.slice(0, 10000))}
                placeholder="Enter your prompt here... Be as detailed as you want (up to 1000+ words)"
                className="w-full h-64 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono text-sm resize-none"
              />
              <div className="mt-4 flex gap-3">
                <button
                  type="submit"
                  disabled={loading}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white font-semibold rounded-lg hover:shadow-lg transition disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? '⏳ Processing...' : '🚀 Send Prompt'}
                </button>
                <button
                  type="button"
                  onClick={() => setPrompt('')}
                  className="px-6 py-3 bg-slate-200 text-slate-700 font-semibold rounded-lg hover:bg-slate-300 transition"
                >
                  Clear
                </button>
              </div>
            </form>

            {/* Quick Prompts */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <label className="block text-sm font-semibold text-slate-700 mb-3">Quick Prompts</label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {quickPrompts.map((quickPrompt, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleQuickPrompt(quickPrompt)}
                    className="text-left px-3 py-2 bg-slate-100 hover:bg-blue-100 rounded-lg text-sm text-slate-700 transition truncate"
                  >
                    {quickPrompt}
                  </button>
                ))}
              </div>
            </div>

            {/* Response Display */}
            {response && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">Response</h3>
                  <button
                    onClick={handleCopyResponse}
                    className="px-3 py-1 bg-slate-200 text-slate-700 text-sm rounded hover:bg-slate-300 transition"
                  >
                    📋 Copy
                  </button>
                </div>
                <div className="bg-slate-50 rounded-lg p-4 max-h-96 overflow-auto whitespace-pre-wrap text-sm text-slate-700 font-mono">
                  {response}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar - Right Side (1 column) */}
          <div className="space-y-6">
            {/* Stats Card */}
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">📊 Session Stats</h3>
              <div className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-xs text-slate-600">Total Queries</div>
                  <div className="text-2xl font-bold text-blue-600">{history.length}</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-xs text-slate-600">Total Tokens</div>
                  <div className="text-2xl font-bold text-green-600">{totalTokens.toLocaleString()}</div>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <div className="text-xs text-slate-600">Total Cost</div>
                  <div className="text-2xl font-bold text-purple-600">${totalCost.toFixed(4)}</div>
                </div>
              </div>
            </div>

            {/* Provider Stats */}
            {Object.keys(providerStats).length > 0 && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-4">🏢 Provider Usage</h3>
                <div className="space-y-2 max-h-64 overflow-auto">
                  {Object.entries(providerStats).map(([provider, stats]: [string, any]) => (
                    <div key={provider} className="p-2 bg-slate-50 rounded text-xs">
                      <div className="font-semibold text-slate-700">{provider}</div>
                      <div className="text-slate-600">
                        Requests: {stats.requests} | Cost: ${stats.totalCost.toFixed(4)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* History Toggle */}
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="w-full px-4 py-3 bg-gradient-to-r from-slate-700 to-slate-800 text-white font-semibold rounded-lg hover:shadow-lg transition"
            >
              {showHistory ? '📖 Hide History' : '📖 Show History'} ({history.length})
            </button>

            {/* History List */}
            {showHistory && (
              <div className="bg-white rounded-lg shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-slate-900">Query History</h3>
                  {history.length > 0 && (
                    <button
                      onClick={handleClearHistory}
                      className="text-xs px-2 py-1 bg-red-100 text-red-600 rounded hover:bg-red-200 transition"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <div className="space-y-2 max-h-96 overflow-auto">
                  {history.map((item) => (
                    <div key={item.id} className="p-3 bg-slate-50 rounded-lg border border-slate-200 hover:border-blue-300 transition cursor-pointer">
                      <div className="text-xs font-semibold text-slate-700 truncate">{item.prompt.slice(0, 50)}...</div>
                      <div className="text-xs text-slate-600 mt-1">
                        {item.provider} • {item.tokensUsed} tokens • ${item.costUSD.toFixed(4)}
                      </div>
                      <div className="text-xs text-slate-500 mt-1">{new Date(item.timestamp).toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
