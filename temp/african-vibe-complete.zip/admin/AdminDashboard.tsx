import React, { useState } from 'react';
import { useLocation } from 'wouter';

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem('adminSession');
    setLocation('/admin/login');
  };

  const menuItems = [
    { label: '🤖 AI Assistant Hub', path: '/admin/ai' },
    { label: '📊 Dashboard', path: '/admin/dashboard' },
    { label: '🛍️ Products', path: '/admin/products' },
    { label: '📦 Orders', path: '/admin/orders' },
    { label: '💳 Payments', path: '/admin/payments' },
    { label: '🚚 Shipping', path: '/admin/shipping' },
    { label: '📧 Email', path: '/admin/email' },
    { label: '⚙️ Settings', path: '/admin/settings' },
  ];

  return (
    <div className="flex h-screen bg-slate-100">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-slate-900 text-white transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          {sidebarOpen && <h2 className="text-xl font-bold">Admin</h2>}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1 hover:bg-slate-800 rounded">
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.path}
              onClick={() => setLocation(item.path)}
              className="w-full text-left px-4 py-2 rounded hover:bg-slate-800 transition truncate"
            >
              {sidebarOpen ? item.label : item.label.split(' ')[0]}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <button
            onClick={handleLogout}
            className="w-full px-4 py-2 bg-red-600 hover:bg-red-700 rounded transition text-sm"
          >
            {sidebarOpen ? 'Logout' : '🚪'}
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow p-6 border-b border-slate-200">
          <h1 className="text-3xl font-bold text-slate-900">Admin Dashboard</h1>
          <p className="text-slate-600 mt-1">Welcome to Dragon Fruit SA Admin Panel</p>
        </header>

        <main className="flex-1 overflow-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-slate-600 text-sm font-medium">Total Orders</div>
              <div className="text-3xl font-bold text-slate-900 mt-2">0</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-slate-600 text-sm font-medium">Revenue (ZAR)</div>
              <div className="text-3xl font-bold text-slate-900 mt-2">R0.00</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-slate-600 text-sm font-medium">Products</div>
              <div className="text-3xl font-bold text-slate-900 mt-2">0</div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="text-slate-600 text-sm font-medium">AI Queries</div>
              <div className="text-3xl font-bold text-slate-900 mt-2">0</div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <h2 className="text-xl font-bold text-slate-900 mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={() => setLocation('/admin/ai')}
                className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 text-white rounded-lg hover:shadow-lg transition"
              >
                <div className="text-2xl mb-2">🤖</div>
                <div className="font-semibold">AI Assistant</div>
                <div className="text-xs opacity-90">Generate content & code</div>
              </button>
              <button
                onClick={() => setLocation('/admin/products')}
                className="p-4 bg-gradient-to-br from-green-500 to-green-600 text-white rounded-lg hover:shadow-lg transition"
              >
                <div className="text-2xl mb-2">🛍️</div>
                <div className="font-semibold">Add Product</div>
                <div className="text-xs opacity-90">Create new product</div>
              </button>
              <button
                onClick={() => setLocation('/admin/orders')}
                className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 text-white rounded-lg hover:shadow-lg transition"
              >
                <div className="text-2xl mb-2">📦</div>
                <div className="font-semibold">View Orders</div>
                <div className="text-xs opacity-90">Manage orders</div>
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
