/**
 * Credentials Configuration
 * All real API credentials for production use
 * NO MOCKS, NO PLACEHOLDERS
 */

export const CREDENTIALS = {
  // Payment Gateways
  payfast: {
    merchantId: "11071120",
    merchantKey: "p6fi9ewdjk1js",
    passphrase: "abCd15ab92g12",
    baseURL: "https://www.payfast.co.za",
    testMode: false,
    currency: "ZAR",
  },

  yoco: {
    apiKey: "yoco_live_1be907c4ffe80376_3f05d1d6503c605b73555b677b80697f",
    publicKey: "pk_live_b21ac3bd1WM6WRY3f9f4",
    secretKey: "sk_live_87380fcbgEgAEJa48704613a39ec",
    baseURL: "https://api.yoco.com",
    testMode: false,
    currency: "ZAR",
  },

  // Shipping Providers
  courierGuy: {
    apiKey: "e28f9909fa734d0a8ce9641c8db68c9f",
    baseURL: "https://api.thecourierguy.co.za",
    testMode: false,
  },

  pudo: {
    apiKey: "51577192|tCQuvbHTuSMgUYgb1Bqh5IEG48DbXXkHF6yBGQYN02422ea5",
    accountNumber: "51577192",
    baseURL: "https://api.pudo.co.za",
    testMode: false,
  },

  // Email System
  email: {
    smtpHost: "mail.proagrisa.co.za",
    smtpPort: 465,
    smtpUser: "orders@proagrisa.co.za",
    smtpPassword: "Kyknet.01",
    fromEmail: "orders@proagrisa.co.za",
    fromName: "Dragon Fruit SA",
    secure: true,
    rejectUnauthorized: false,
  },

  // AI Services
  openrouter: {
    apiKey: "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",
    baseURL: "https://openrouter.ai/api/v1",
  },

  ollamaCloud: {
    apiKey: "cebbc97e307d4e4d9b8a28d8e7b4d32d.SHRF1ZEiQEeRGK6vU4rLMvC4",
    baseURL: "https://ollama.com/api",
  },

  ollamaLocal: {
    baseURL: "http://localhost:11434/api",
    apiKey: null,
  },

  // SEO & Data
  serpapi: {
    apiKey: "c1ff1791c17d28baf2c8d4dde29b12ef6064a3f19a3c55dee939f6512378aa04",
    baseURL: "https://serpapi.com",
  },

  // Development
  github: {
    token: "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",
    baseURL: "https://api.github.com",
  },

  kiloCode: {
    jwt: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbnYiOiJwcm9kdWN0aW9uIiwia2lsb1VzZXJJZCI6ImQwM2ZkODQxLTc5YzItNDJhMi1hNWViLWQwNjY1M2EwYmUzNCIsImFwaVRva2VuUGVwcGVyIjpudWxsLCJ2ZXJzaW9uIjozLCJpYXQiOjE3NjgzMTU3NzksImV4cCI6MTkyNjEwMzc3OX0.TTXbtmyaY-M8mc8P8YmENWz_9mTjflyVDgNwKa1yJ8s",
    baseURL: "https://api.kilocode.com",
  },

  // Business Information
  business: {
    name: "Dragon Fruit SA",
    email: "admin@proagrisa.co.za",
    phone: "+1 351 777 2848",
    afterHoursPhone: "083 447 4639",
    whatsapp1: "+27 83 447 4639",
    whatsapp2: "+1 555 708 3482",
    currency: "ZAR",
    currencySymbol: "R",
  },

  // Currency Conversion
  currencyConversion: {
    defaultFrom: "ZAR",
    defaultTo: "USD",
    updateInterval: 3600000, // 1 hour
    cacheExpiry: 300000, // 5 minutes
  },
};

export type Credentials = typeof CREDENTIALS;
